<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/dashboard/login' => [[['_route' => 'dashboard.login', '_controller' => 'App\\Controller\\Dashboard\\AdminAuthController::login'], null, null, null, false, false, null]],
        '/dashboard/logout' => [[['_route' => 'dashboard.logout', '_controller' => 'App\\Controller\\Dashboard\\AdminAuthController::logout'], null, null, null, false, false, null]],
        '/dashboard/admins/index' => [[['_route' => 'dashboard.admins.index', '_controller' => 'App\\Controller\\Dashboard\\AdminController::index'], null, null, null, false, false, null]],
        '/dashboard/admins/create' => [[['_route' => 'dashboard.admins.create', '_controller' => 'App\\Controller\\Dashboard\\AdminController::create'], null, null, null, false, false, null]],
        '/dashboard/cities/index' => [[['_route' => 'dashboard.cities.index', '_controller' => 'App\\Controller\\Dashboard\\CityController::index'], null, null, null, false, false, null]],
        '/dashboard/cities/create' => [[['_route' => 'dashboard.cities.create', '_controller' => 'App\\Controller\\Dashboard\\CityController::create'], null, null, null, false, false, null]],
        '/dashboard/colors/index' => [[['_route' => 'dashboard.colors.index', '_controller' => 'App\\Controller\\Dashboard\\ColorController::index'], null, null, null, false, false, null]],
        '/dashboard/colors/create' => [[['_route' => 'dashboard.colors.create', '_controller' => 'App\\Controller\\Dashboard\\ColorController::create'], null, null, null, false, false, null]],
        '/dashboard/countries/index' => [[['_route' => 'dashboard.countries.index', '_controller' => 'App\\Controller\\Dashboard\\CountryController::index'], null, null, null, false, false, null]],
        '/dashboard/countries/create' => [[['_route' => 'dashboard.countries.create', '_controller' => 'App\\Controller\\Dashboard\\CountryController::create'], null, null, null, false, false, null]],
        '/dashboard/departments/index' => [[['_route' => 'dashboard.departments.index', '_controller' => 'App\\Controller\\Dashboard\\DepartmentController::index'], null, null, null, false, false, null]],
        '/dashboard/departments/create' => [[['_route' => 'dashboard.departments.create', '_controller' => 'App\\Controller\\Dashboard\\DepartmentController::create'], null, null, null, false, false, null]],
        '/dashboard' => [[['_route' => 'dashboard.index', '_controller' => 'App\\Controller\\Dashboard\\HomeController::index'], null, null, null, true, false, null]],
        '/dashboard/settings' => [[['_route' => 'dashboard.settings', '_controller' => 'App\\Controller\\Dashboard\\HomeController::getSettings'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/dashboard/malls/index' => [[['_route' => 'dashboard.malls.index', '_controller' => 'App\\Controller\\Dashboard\\MallController::index'], null, null, null, false, false, null]],
        '/dashboard/malls/create' => [[['_route' => 'dashboard.malls.create', '_controller' => 'App\\Controller\\Dashboard\\MallController::create'], null, null, null, false, false, null]],
        '/dashboard/manufacts/index' => [[['_route' => 'dashboard.manufacts.index', '_controller' => 'App\\Controller\\Dashboard\\ManuFactController::index'], null, null, null, false, false, null]],
        '/dashboard/manufacts/create' => [[['_route' => 'dashboard.manufacts.create', '_controller' => 'App\\Controller\\Dashboard\\ManuFactController::create'], null, null, null, false, false, null]],
        '/dashboard/orders/index' => [[['_route' => 'dashboard.orders.index', '_controller' => 'App\\Controller\\Dashboard\\OrderController::index'], null, null, null, false, false, null]],
        '/dashboard/products/index' => [[['_route' => 'dashboard.products.index', '_controller' => 'App\\Controller\\Dashboard\\ProductController::index'], null, null, null, false, false, null]],
        '/dashboard/products/specific-state' => [[['_route' => 'dashboard.products.specific.size', '_controller' => 'App\\Controller\\Dashboard\\ProductController::specific'], null, ['POST' => 0], null, false, false, null]],
        '/dashboard/shippings/index' => [[['_route' => 'dashboard.shippings.index', '_controller' => 'App\\Controller\\Dashboard\\ShippingController::index'], null, null, null, false, false, null]],
        '/dashboard/shippings/create' => [[['_route' => 'dashboard.shippings.create', '_controller' => 'App\\Controller\\Dashboard\\ShippingController::create'], null, null, null, false, false, null]],
        '/dashboard/sizes/index' => [[['_route' => 'dashboard.sizes.index', '_controller' => 'App\\Controller\\Dashboard\\SizeController::index'], null, null, null, false, false, null]],
        '/dashboard/sizes/create' => [[['_route' => 'dashboard.sizes.create', '_controller' => 'App\\Controller\\Dashboard\\SizeController::create'], null, null, null, false, false, null]],
        '/dashboard/states/index' => [[['_route' => 'dashboard.states.index', '_controller' => 'App\\Controller\\Dashboard\\StateController::index'], null, null, null, false, false, null]],
        '/dashboard/states/create' => [[['_route' => 'dashboard.states.create', '_controller' => 'App\\Controller\\Dashboard\\StateController::create'], null, null, null, false, false, null]],
        '/dashboard/states/specific-state' => [[['_route' => 'dashboard.states.specific.state', '_controller' => 'App\\Controller\\Dashboard\\StateController::specific'], null, ['POST' => 0], null, false, false, null]],
        '/dashboard/trademarks/index' => [[['_route' => 'dashboard.trademarks.index', '_controller' => 'App\\Controller\\Dashboard\\TrademarkController::index'], null, null, null, false, false, null]],
        '/dashboard/trademarks/create' => [[['_route' => 'dashboard.trademarks.create', '_controller' => 'App\\Controller\\Dashboard\\TrademarkController::create'], null, null, null, false, false, null]],
        '/dashboard/users/index' => [[['_route' => 'dashboard.users.index', '_controller' => 'App\\Controller\\Dashboard\\UserController::index'], null, null, null, false, false, null]],
        '/dashboard/users/create' => [[['_route' => 'dashboard.users.create', '_controller' => 'App\\Controller\\Dashboard\\UserController::create'], null, null, null, false, false, null]],
        '/dashboard/weights/index' => [[['_route' => 'dashboard.weights.index', '_controller' => 'App\\Controller\\Dashboard\\WeightController::index'], null, null, null, false, false, null]],
        '/dashboard/weights/create' => [[['_route' => 'dashboard.weights.create', '_controller' => 'App\\Controller\\Dashboard\\WeightController::create'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'front.index', '_controller' => 'App\\Controller\\Front\\FrontController::index'], null, null, null, false, false, null]],
        '/cart' => [[['_route' => 'front.cart', '_controller' => 'App\\Controller\\Front\\FrontController::cart'], null, null, null, false, false, null]],
        '/orders' => [[['_route' => 'front.orders', '_controller' => 'App\\Controller\\Front\\FrontController::orders'], null, null, null, false, false, null]],
        '/profile' => [[['_route' => 'front.profile', '_controller' => 'App\\Controller\\Front\\FrontController::profile'], null, null, null, false, false, null]],
        '/api/latest/products' => [[['_route' => 'api.latest.products', '_controller' => 'App\\Controller\\Front\\FrontController::latest_products'], null, ['POST' => 0], null, false, false, null]],
        '/api/products' => [[['_route' => 'api.products', '_controller' => 'App\\Controller\\Front\\FrontController::products'], null, ['POST' => 0], null, false, false, null]],
        '/api/own/cart' => [[['_route' => 'api.own.cart', '_controller' => 'App\\Controller\\Front\\FrontController::api_own_cart'], null, null, null, false, false, null]],
        '/api/orders' => [[['_route' => 'api.get.orders', '_controller' => 'App\\Controller\\Front\\FrontController::api_get_orders'], null, ['POST' => 0], null, false, false, null]],
        '/login' => [[['_route' => 'front.login', '_controller' => 'App\\Controller\\Front\\UserAuthController::login'], null, ['POST' => 0], null, false, false, null]],
        '/register' => [[['_route' => 'front.register', '_controller' => 'App\\Controller\\Front\\UserAuthController::register'], null, ['POST' => 0], null, false, false, null]],
        '/logout' => [[['_route' => 'front.logout', '_controller' => 'App\\Controller\\Front\\UserAuthController::logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/dashboard/(?'
                    .'|admins/(?'
                        .'|edit/([^/]++)(*:206)'
                        .'|destroy/([^/]++)(*:230)'
                    .')'
                    .'|c(?'
                        .'|ities/(?'
                            .'|edit/([^/]++)(*:265)'
                            .'|destroy/([^/]++)(*:289)'
                        .')'
                        .'|o(?'
                            .'|lors/(?'
                                .'|edit/([^/]++)(*:323)'
                                .'|destroy/([^/]++)(*:347)'
                            .')'
                            .'|untries/(?'
                                .'|edit/([^/]++)(*:380)'
                                .'|destroy/([^/]++)(*:404)'
                            .')'
                        .')'
                    .')'
                    .'|departments/(?'
                        .'|edit/([^/]++)(*:443)'
                        .'|destroy/([^/]++)(*:467)'
                    .')'
                    .'|ma(?'
                        .'|lls/(?'
                            .'|edit/([^/]++)(*:501)'
                            .'|destroy/([^/]++)(*:525)'
                        .')'
                        .'|nufacts/(?'
                            .'|edit/([^/]++)(*:558)'
                            .'|destroy/([^/]++)(*:582)'
                        .')'
                    .')'
                    .'|orders/(?'
                        .'|edit/([^/]++)(*:615)'
                        .'|destroy/([^/]++)(*:639)'
                    .')'
                    .'|products/(?'
                        .'|create(?:/([^/]++))?(*:680)'
                        .'|edit/([^/]++)(*:701)'
                        .'|destroy/([^/]++)(*:725)'
                    .')'
                    .'|s(?'
                        .'|hippings/(?'
                            .'|edit/([^/]++)(*:763)'
                            .'|destroy/([^/]++)(*:787)'
                        .')'
                        .'|izes/(?'
                            .'|edit/([^/]++)(*:817)'
                            .'|destroy/([^/]++)(*:841)'
                        .')'
                        .'|tates/(?'
                            .'|edit/([^/]++)(*:872)'
                            .'|destroy/([^/]++)(*:896)'
                        .')'
                    .')'
                    .'|trademarks/(?'
                        .'|edit/([^/]++)(*:933)'
                        .'|destroy/([^/]++)(*:957)'
                    .')'
                    .'|users/(?'
                        .'|edit/([^/]++)(*:988)'
                        .'|destroy/([^/]++)(*:1012)'
                    .')'
                    .'|weights/(?'
                        .'|edit/([^/]++)(*:1046)'
                        .'|destroy/([^/]++)(*:1071)'
                    .')'
                .')'
                .'|/category/([^/]++)(?:/([^/]++))?(*:1114)'
                .'|/product/([^/]++)(?:/([^/]++))?(*:1154)'
                .'|/api/(?'
                    .'|more/(?'
                        .'|products(?:/([^/]++))?(*:1201)'
                        .'|specific/products/([^/]++)(?:/([^/]++))?(*:1250)'
                    .')'
                    .'|c(?'
                        .'|a(?'
                            .'|tegory/([^/]++)(*:1283)'
                            .'|rt/([^/]++)(*:1303)'
                        .')'
                        .'|reate/(?'
                            .'|love/([^/]++)(*:1335)'
                            .'|order/([^/]++)(*:1358)'
                        .')'
                    .')'
                    .'|product/([^/]++)(*:1385)'
                    .'|loves/([^/]++)(*:1408)'
                    .'|delete/product/([^/]++)/([^/]++)(*:1449)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        206 => [[['_route' => 'dashboard.admins.edit', '_controller' => 'App\\Controller\\Dashboard\\AdminController::edit'], ['id'], null, null, false, true, null]],
        230 => [[['_route' => 'dashboard.admins.destroy', '_controller' => 'App\\Controller\\Dashboard\\AdminController::destroy'], ['id'], null, null, false, true, null]],
        265 => [[['_route' => 'dashboard.cities.edit', '_controller' => 'App\\Controller\\Dashboard\\CityController::edit'], ['id'], null, null, false, true, null]],
        289 => [[['_route' => 'dashboard.cities.destroy', '_controller' => 'App\\Controller\\Dashboard\\CityController::destroy'], ['id'], null, null, false, true, null]],
        323 => [[['_route' => 'dashboard.colors.edit', '_controller' => 'App\\Controller\\Dashboard\\ColorController::edit'], ['id'], null, null, false, true, null]],
        347 => [[['_route' => 'dashboard.colors.destroy', '_controller' => 'App\\Controller\\Dashboard\\ColorController::destroy'], ['id'], null, null, false, true, null]],
        380 => [[['_route' => 'dashboard.countries.edit', '_controller' => 'App\\Controller\\Dashboard\\CountryController::edit'], ['id'], null, null, false, true, null]],
        404 => [[['_route' => 'dashboard.countries.destroy', '_controller' => 'App\\Controller\\Dashboard\\CountryController::destroy'], ['id'], null, null, false, true, null]],
        443 => [[['_route' => 'dashboard.departments.edit', '_controller' => 'App\\Controller\\Dashboard\\DepartmentController::edit'], ['id'], null, null, false, true, null]],
        467 => [[['_route' => 'dashboard.departments.destroy', '_controller' => 'App\\Controller\\Dashboard\\DepartmentController::destroy'], ['id'], null, null, false, true, null]],
        501 => [[['_route' => 'dashboard.malls.edit', '_controller' => 'App\\Controller\\Dashboard\\MallController::edit'], ['id'], null, null, false, true, null]],
        525 => [[['_route' => 'dashboard.malls.destroy', '_controller' => 'App\\Controller\\Dashboard\\MallController::destroy'], ['id'], null, null, false, true, null]],
        558 => [[['_route' => 'dashboard.manufacts.edit', '_controller' => 'App\\Controller\\Dashboard\\ManuFactController::edit'], ['id'], null, null, false, true, null]],
        582 => [[['_route' => 'dashboard.manufacts.destroy', '_controller' => 'App\\Controller\\Dashboard\\ManuFactController::destroy'], ['id'], null, null, false, true, null]],
        615 => [[['_route' => 'dashboard.orders.edit', '_controller' => 'App\\Controller\\Dashboard\\OrderController::edit'], ['id'], null, null, false, true, null]],
        639 => [[['_route' => 'dashboard.orders.destroy', '_controller' => 'App\\Controller\\Dashboard\\OrderController::destroy'], ['id'], null, null, false, true, null]],
        680 => [[['_route' => 'dashboard.products.create', 'copyId' => null, '_controller' => 'App\\Controller\\Dashboard\\ProductController::create'], ['copyId'], null, null, false, true, null]],
        701 => [[['_route' => 'dashboard.products.edit', '_controller' => 'App\\Controller\\Dashboard\\ProductController::edit'], ['id'], null, null, false, true, null]],
        725 => [[['_route' => 'dashboard.products.destroy', '_controller' => 'App\\Controller\\Dashboard\\ProductController::destroy'], ['id'], null, null, false, true, null]],
        763 => [[['_route' => 'dashboard.shippings.edit', '_controller' => 'App\\Controller\\Dashboard\\ShippingController::edit'], ['id'], null, null, false, true, null]],
        787 => [[['_route' => 'dashboard.shippings.destroy', '_controller' => 'App\\Controller\\Dashboard\\ShippingController::destroy'], ['id'], null, null, false, true, null]],
        817 => [[['_route' => 'dashboard.sizes.edit', '_controller' => 'App\\Controller\\Dashboard\\SizeController::edit'], ['id'], null, null, false, true, null]],
        841 => [[['_route' => 'dashboard.sizes.destroy', '_controller' => 'App\\Controller\\Dashboard\\SizeController::destroy'], ['id'], null, null, false, true, null]],
        872 => [[['_route' => 'dashboard.states.edit', '_controller' => 'App\\Controller\\Dashboard\\StateController::edit'], ['id'], null, null, false, true, null]],
        896 => [[['_route' => 'dashboard.states.destroy', '_controller' => 'App\\Controller\\Dashboard\\StateController::destroy'], ['id'], null, null, false, true, null]],
        933 => [[['_route' => 'dashboard.trademarks.edit', '_controller' => 'App\\Controller\\Dashboard\\TrademarkController::edit'], ['id'], null, null, false, true, null]],
        957 => [[['_route' => 'dashboard.trademarks.destroy', '_controller' => 'App\\Controller\\Dashboard\\TrademarkController::destroy'], ['id'], null, null, false, true, null]],
        988 => [[['_route' => 'dashboard.users.edit', '_controller' => 'App\\Controller\\Dashboard\\UserController::edit'], ['id'], null, null, false, true, null]],
        1012 => [[['_route' => 'dashboard.users.destroy', '_controller' => 'App\\Controller\\Dashboard\\UserController::destroy'], ['id'], null, null, false, true, null]],
        1046 => [[['_route' => 'dashboard.weights.edit', '_controller' => 'App\\Controller\\Dashboard\\WeightController::edit'], ['id'], null, null, false, true, null]],
        1071 => [[['_route' => 'dashboard.weights.destroy', '_controller' => 'App\\Controller\\Dashboard\\WeightController::destroy'], ['id'], null, null, false, true, null]],
        1114 => [[['_route' => 'front.category', 'title' => null, '_controller' => 'App\\Controller\\Front\\FrontController::category'], ['id', 'title'], null, null, false, true, null]],
        1154 => [[['_route' => 'front.product', 'title' => null, '_controller' => 'App\\Controller\\Front\\FrontController::product'], ['id', 'title'], null, null, false, true, null]],
        1201 => [[['_route' => 'api.more.products', 'skipNumber' => null, '_controller' => 'App\\Controller\\Front\\FrontController::more_products'], ['skipNumber'], ['POST' => 0], null, false, true, null]],
        1250 => [[['_route' => 'api.more.specific.products', 'skipNumber' => null, '_controller' => 'App\\Controller\\Front\\FrontController::more_specific_products'], ['id', 'skipNumber'], ['POST' => 0], null, false, true, null]],
        1283 => [[['_route' => 'api.category', '_controller' => 'App\\Controller\\Front\\FrontController::getCategory'], ['id'], ['POST' => 0, 'GET' => 1], null, false, true, null]],
        1303 => [[['_route' => 'api.cart', '_controller' => 'App\\Controller\\Front\\FrontController::api_cart'], ['id'], null, null, false, true, null]],
        1335 => [[['_route' => 'api.create.love', '_controller' => 'App\\Controller\\Front\\FrontController::api_create_love'], ['id'], null, null, false, true, null]],
        1358 => [[['_route' => 'api.create.order', '_controller' => 'App\\Controller\\Front\\FrontController::api_create_order'], ['id'], ['POST' => 0], null, false, true, null]],
        1385 => [[['_route' => 'api.product', '_controller' => 'App\\Controller\\Front\\FrontController::api_products'], ['id'], null, null, false, true, null]],
        1408 => [[['_route' => 'api.loves', '_controller' => 'App\\Controller\\Front\\FrontController::api_loves'], ['id'], null, null, false, true, null]],
        1449 => [
            [['_route' => 'api.delete.product', '_controller' => 'App\\Controller\\Front\\FrontController::api_delete_product'], ['cartId', 'productId'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
