<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/layouts/aside.html.twig */
class __TwigTemplate_e2f364fa541202e360f99a4de009f2de85ceb32da1e51e4727fa2e194c4b340f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<aside class=\"main-sidebar sidebar-dark-primary elevation-4\">
    <!-- Brand Logo -->
    <a href=\"";
        // line 3
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\" class=\"brand-link\">
        <img src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/img/AdminLTELogo.png\" alt=\"AdminLTE Logo\" class=\"brand-image img-circle elevation-3\"
             style=\"opacity: .8\">
        <span class=\"brand-text font-weight-light\">لوحة التحكم</span>
    </a>

    ";
        // line 9
        $context["router"] = twig_split_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 9), "attributes", [], "any", false, false, false, 9), "get", [0 => "_route"], "method", false, false, false, 9), ".");
        // line 10
        echo "
    <!-- Sidebar -->
    <div class=\"sidebar\" style=\"direction: ltr\">
        <div style=\"direction: rtl\">
            <!-- Sidebar user panel (optional) -->
            <div class=\"user-panel mt-3 pb-3 mb-3 d-flex\">
                <div class=\"image\">
                    <img src=\"https://secure.gravatar.com/avatar/5ffa2a1ffeb767c60ab7e1052e385d5c?s=52&d=mm&r=g\" class=\"img-circle elevation-2\" alt=\"User Image\">
                </div>
                <div class=\"info\">
                    <a href=\"#\" class=\"d-block\">";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 20), "name", [], "any", false, false, false, 20), "html", null, true);
        echo "</a>
                </div>
            </div>

            <!-- Sidebar Menu -->
            <nav class=\"mt-2\">
                <ul class=\"nav nav-pills nav-sidebar flex-column\" data-widget=\"treeview\" role=\"menu\" data-accordion=\"false\">
                    <!-- Add icons to the links using the .nav-icon class
                         with font-awesome or any other icon font library -->
                    <li class=\"nav-item ";
        // line 29
        echo ((0 === twig_compare((($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = ($context["router"] ?? null)) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4[1] ?? null) : null), "index")) ? ("menu-open") : (""));
        echo "\">
                        <a href=\"";
        // line 30
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-dashboard\"></i>
                            <p>
                                الرئيسية
                            </p>
                        </a>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 37
        echo ((0 === twig_compare((($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = ($context["router"] ?? null)) && is_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144) || $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 instanceof ArrayAccess ? ($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144[1] ?? null) : null), "admins")) ? ("menu-open") : (""));
        echo "\">
                        <a href=\"#\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-user-secret\"></i>
                            <p>
                                المشرفين
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 47
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.admins.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المشرفين</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 53
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.admins.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 60
        echo ((0 === twig_compare((($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b = ($context["router"] ?? null)) && is_array($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b) || $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b instanceof ArrayAccess ? ($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b[1] ?? null) : null), "users")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 61
        echo "                        <a href=\"#\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-user\"></i>
                            <p>
                                المستخدمين
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 70
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>جميع المستخدمين</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 76
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.index", ["type" => 1]);
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الاعضاء</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 82
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.index", ["type" => 2]);
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المتاجر</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 88
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.index", ["type" => 3]);
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الشركات</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 94
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 101
        echo ((0 === twig_compare((($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = ($context["router"] ?? null)) && is_array($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002) || $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 instanceof ArrayAccess ? ($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002[1] ?? null) : null), "countries")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 102
        echo "                        <a href=\"#\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-flag\"></i>
                            <p>
                                الدول
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 111
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.countries.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الدول</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 117
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.countries.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 124
        echo ((0 === twig_compare((($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 = ($context["router"] ?? null)) && is_array($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4) || $__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 instanceof ArrayAccess ? ($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4[1] ?? null) : null), "cities")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 125
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 127
        echo "                            <i class=\"nav-icon fa fa-flag-checkered\"></i>
                            <p>
                                المحافظات / المدن
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 135
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.cities.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المحافظات / المدن</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 141
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.cities.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 148
        echo ((0 === twig_compare((($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 = ($context["router"] ?? null)) && is_array($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666) || $__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 instanceof ArrayAccess ? ($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666[1] ?? null) : null), "states")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 149
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 151
        echo "                            <i class=\"nav-icon fa fa-flag\"></i>
                            <p>
                                المناطق / الاحياء
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 159
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.states.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المناطق / الاحياء</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 165
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.states.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 172
        echo ((0 === twig_compare((($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e = ($context["router"] ?? null)) && is_array($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e) || $__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e instanceof ArrayAccess ? ($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e[1] ?? null) : null), "departments")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 173
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 175
        echo "                            <i class=\"nav-icon fa fa-list-ol\"></i>
                            <p>
                                الاقسام
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 183
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.departments.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الاقسام</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 189
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.departments.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 196
        echo ((0 === twig_compare((($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 = ($context["router"] ?? null)) && is_array($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52) || $__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 instanceof ArrayAccess ? ($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52[1] ?? null) : null), "trademarks")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 197
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 199
        echo "                            <i class=\"nav-icon fa fa-trademark\"></i>
                            <p>
                                العلامات التجارية
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 207
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.trademarks.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>العلامات التجارية</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 213
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.trademarks.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 220
        echo ((0 === twig_compare((($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 = ($context["router"] ?? null)) && is_array($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136) || $__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 instanceof ArrayAccess ? ($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136[1] ?? null) : null), "manufacts")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 221
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 223
        echo "                            <i class=\"nav-icon fa fa-rocket\"></i>
                            <p>
                                المصنعين
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 231
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.manufacts.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المصنعين</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 237
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.manufacts.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 244
        echo ((0 === twig_compare((($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 = ($context["router"] ?? null)) && is_array($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386) || $__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 instanceof ArrayAccess ? ($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386[1] ?? null) : null), "shippings")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 245
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 247
        echo "                            <i class=\"nav-icon fa fa-truck\"></i>
                            <p>
                                شركات الشحن
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 255
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.shippings.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>شركات الشحن</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 261
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.shippings.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 268
        echo ((0 === twig_compare((($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 = ($context["router"] ?? null)) && is_array($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9) || $__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 instanceof ArrayAccess ? ($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9[1] ?? null) : null), "malls")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 269
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 271
        echo "                            <i class=\"nav-icon fa fa-building\"></i>
                            <p>
                                المجمعات التجارية
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 279
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.malls.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المجمعات التجارية</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 285
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.malls.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 292
        echo ((0 === twig_compare((($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae = ($context["router"] ?? null)) && is_array($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae) || $__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae instanceof ArrayAccess ? ($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae[1] ?? null) : null), "colors")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 293
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 295
        echo "                            <i class=\"nav-icon fa fa-paint-brush\"></i>
                            <p>
                                الالوان
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 303
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.colors.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الالوان</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 309
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.colors.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 316
        echo ((0 === twig_compare((($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f = ($context["router"] ?? null)) && is_array($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f) || $__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f instanceof ArrayAccess ? ($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f[1] ?? null) : null), "sizes")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 317
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 319
        echo "                            <i class=\"nav-icon fa fa-sliders\"></i>
                            <p>
                                المقاسات
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 327
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.sizes.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المقاسات</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 333
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.sizes.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 340
        echo ((0 === twig_compare((($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40 = ($context["router"] ?? null)) && is_array($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40) || $__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40 instanceof ArrayAccess ? ($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40[1] ?? null) : null), "weights")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 341
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 343
        echo "                            <i class=\"nav-icon fa fa-archive\"></i>
                            <p>
                                الاوزان
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 351
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.weights.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الاوزان</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 357
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.weights.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 364
        echo ((0 === twig_compare((($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f = ($context["router"] ?? null)) && is_array($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f) || $__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f instanceof ArrayAccess ? ($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f[1] ?? null) : null), "products")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 365
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 367
        echo "                            <i class=\"nav-icon fa fa-tag\"></i>
                            <p>
                                المنتجات
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 375
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المنتجات</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 381
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item ";
        // line 388
        echo ((0 === twig_compare((($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760 = ($context["router"] ?? null)) && is_array($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760) || $__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760 instanceof ArrayAccess ? ($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760[1] ?? null) : null), "orders")) ? ("menu-open") : (""));
        echo "\">
                        <a href=\"";
        // line 389
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.settings");
        echo "\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-cart-plus\"></i>
                            <p>
                                الطلبات
                            </p>
                        </a>
                    </li>
                    <li class=\"nav-item ";
        // line 396
        echo ((0 === twig_compare((($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce = ($context["router"] ?? null)) && is_array($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce) || $__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce instanceof ArrayAccess ? ($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce[1] ?? null) : null), "settings")) ? ("menu-open") : (""));
        echo "\">
                        <a href=\"";
        // line 397
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.settings");
        echo "\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-gears\"></i>
                            <p>
                                الاعدادات
                            </p>
                        </a>
                    </li>
                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
    </div>
    <!-- /.sidebar -->
</aside>";
    }

    public function getTemplateName()
    {
        return "dashboard/layouts/aside.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  621 => 397,  617 => 396,  607 => 389,  603 => 388,  593 => 381,  584 => 375,  574 => 367,  571 => 365,  568 => 364,  558 => 357,  549 => 351,  539 => 343,  536 => 341,  533 => 340,  523 => 333,  514 => 327,  504 => 319,  501 => 317,  498 => 316,  488 => 309,  479 => 303,  469 => 295,  466 => 293,  463 => 292,  453 => 285,  444 => 279,  434 => 271,  431 => 269,  428 => 268,  418 => 261,  409 => 255,  399 => 247,  396 => 245,  393 => 244,  383 => 237,  374 => 231,  364 => 223,  361 => 221,  358 => 220,  348 => 213,  339 => 207,  329 => 199,  326 => 197,  323 => 196,  313 => 189,  304 => 183,  294 => 175,  291 => 173,  288 => 172,  278 => 165,  269 => 159,  259 => 151,  256 => 149,  253 => 148,  243 => 141,  234 => 135,  224 => 127,  221 => 125,  218 => 124,  208 => 117,  199 => 111,  188 => 102,  185 => 101,  175 => 94,  166 => 88,  157 => 82,  148 => 76,  139 => 70,  128 => 61,  125 => 60,  115 => 53,  106 => 47,  93 => 37,  83 => 30,  79 => 29,  67 => 20,  55 => 10,  53 => 9,  45 => 4,  41 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/layouts/aside.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/layouts/aside.html.twig");
    }
}
