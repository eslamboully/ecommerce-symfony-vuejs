<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/shippings/index.html.twig */
class __TwigTemplate_8316f164a582f72693deb319482b399c40035d2561cf582dc95263dd78e3890e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/shippings/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">جدول شركات الشحن</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item active\">شركات الشحن</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <div class=\"card-header\">
";
        // line 29
        echo "                            <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.shippings.create");
        echo "\" class=\"btn btn-success btn-md\"><i class=\"fa fa-plus\"></i> اضف جديد </a>
                            <a href=\"\" class=\"btn btn-info btn-md\" onclick=\"window.print()\"><i class=\"fa fa-print\"></i> طباعة </a>
                            <a href=\"\" class=\"btn btn-primary btn-md\"><i class=\"fa fa-plus\"></i> استيراد اكسل </a>
                            <a href=\"\" class=\"btn btn-default btn-md\"><i class=\"fa fa-refresh\"></i></a>
                            <a href=\"\" class=\"btn btn-danger btn-md\"><i class=\"fa fa-trash\"></i> حذف الكل </a>
                        </div>
                        <!-- /.card-header -->
                        <div class=\"card-body\">
                            ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "flashes", [0 => "success"], "method", false, false, false, 37));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 38
            echo "                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <div class=\"card\">
                                            <div class=\"card-body label label-success\">
                                                <div style=\"font-size: 18px;\">";
            // line 42
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "
                            ";
        // line 49
        if (1 === twig_compare(twig_length_filter($this->env, ($context["shippings"] ?? null)), 0)) {
            // line 50
            echo "                                <table id=\"table-country\" class=\"table table-bordered\">
                                    <tr>
                                        <th>#</th>
                                        <th>الاسم</th>
                                        <th>المالك</th>
                                        <th>الشعار</th>
                                        <th>العمليات</th>
                                    </tr>

                                    ";
            // line 59
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["shippings"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["shipping"]) {
                // line 60
                echo "                                        <tr>
                                            <td>";
                // line 61
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["shipping"], "id", [], "any", false, false, false, 61), "html", null, true);
                echo "</td>
                                            <td>";
                // line 62
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["shipping"], "name", [], "any", false, false, false, 62), "html", null, true);
                echo "</td>
                                            <td>";
                // line 63
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["shipping"], "User", [], "any", false, false, false, 63), "name", [], "any", false, false, false, 63), "html", null, true);
                echo "</td>
                                            <td>
                                                <img src=\"";
                // line 65
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, $context["shipping"], "icon", [], "any", false, false, false, 65)), "html", null, true);
                echo "\" style=\"width: 60px;height: 60px;border-radius: 20px\">
                                            </td>
                                            <td>
                                                <a href=\"";
                // line 68
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.shippings.edit", ["id" => twig_get_attribute($this->env, $this->source, $context["shipping"], "id", [], "any", false, false, false, 68)]), "html", null, true);
                echo "\" class=\"btn btn-success btn-sm\"><i class=\"fa fa-edit\"></i> تعديل </a>
                                                <a href=\"";
                // line 69
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.shippings.destroy", ["id" => twig_get_attribute($this->env, $this->source, $context["shipping"], "id", [], "any", false, false, false, 69)]), "html", null, true);
                echo "\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i> حذف </a>
                                            </td>
                                        </tr>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['shipping'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 73
            echo "                                </table>
                            ";
        } else {
            // line 75
            echo "                                <h1>للأسف لا توجد شركات شحن حتي الان</h1>
                            ";
        }
        // line 77
        echo "                        </div>
                        <!-- /.card-body -->
";
        // line 88
        echo "                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
        </div><!-- /.container-fluid -->
    </section>

";
    }

    public function getTemplateName()
    {
        return "dashboard/shippings/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 88,  177 => 77,  173 => 75,  169 => 73,  159 => 69,  155 => 68,  149 => 65,  144 => 63,  140 => 62,  136 => 61,  133 => 60,  129 => 59,  118 => 50,  116 => 49,  113 => 48,  101 => 42,  95 => 38,  91 => 37,  79 => 29,  60 => 12,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/shippings/index.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/shippings/index.html.twig");
    }
}
