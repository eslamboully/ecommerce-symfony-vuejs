<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/products/edit.html.twig */
class __TwigTemplate_6b038dbbe5481bb65648c1e07605ccbdc27e00d43911221de44d07f525eed3d8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/products/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">تعديل المنتج</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\">المنتجات</a></li>
                        <li class=\"breadcrumb-item active\">تعديل</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"card card-primary card-outline\">
                    <div class=\"card-body\">
                        <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
                            ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "flashes", [0 => "success"], "method", false, false, false, 30));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 31
            echo "                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <div class=\"card\">
                                            <div class=\"card-body label label-success\">
                                                <div style=\"font-size: 18px;\">";
            // line 35
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "                            <div style=\"margin-bottom: 10px\">
                                <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
                                <a href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.create", ["copyId" => twig_get_attribute($this->env, $this->source, ($context["product"] ?? null), "id", [], "any", false, false, false, 44)]), "html", null, true);
        echo "\" class=\"btn btn-primary\"> نسخ المنتج <i class=\"fa fa-copy\"></i></a>
                                <a href=\"";
        // line 45
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
                                <a href=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.destroy", ["id" => twig_get_attribute($this->env, $this->source, ($context["product"] ?? null), "id", [], "any", false, false, false, 46)]), "html", null, true);
        echo "\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger\"> حذف <i class=\"fa fa-trash\"></i></a>
                            </div>
                            ";
        // line 48
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        echo "
                            ";
        // line 49
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "_token", [], "any", false, false, false, 49), 'row');
        echo "
                            <ul class=\"nav nav-tabs\" id=\"custom-content-below-tab\" role=\"tablist\">
                                <li class=\"nav-item\">
                                    <a class=\"nav-link active\" id=\"custom-content-below-info-tab\" data-toggle=\"pill\" href=\"#custom-content-below-info\" role=\"tab\" aria-controls=\"custom-content-below-home\" aria-selected=\"true\"><i class=\"fa fa-info\"></i> معلومات المنتج </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-department-tab\" data-toggle=\"pill\" href=\"#custom-content-below-department\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-list\"></i> القسم </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-settings-tab\" data-toggle=\"pill\" href=\"#custom-content-below-settings\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-gears\"></i> اعدادات المنتج </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-content-tab\" data-toggle=\"pill\" href=\"#custom-content-below-content\" role=\"tab\" aria-controls=\"custom-content-below-messages\" aria-selected=\"false\"><i class=\"fa fa-question\"></i> سبب الرفض </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-sizes-tab\" data-toggle=\"pill\" href=\"#custom-content-below-sizes\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-truck\"></i> معلومات الشحن </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-other-tab\" data-toggle=\"pill\" href=\"#custom-content-below-other\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-cart-plus\"></i> معلومات اضافية </a>
                                </li>
                            </ul>
                            <div class=\"tab-content\" id=\"custom-content-below-tabContent\">
                                <div class=\"tab-pane fade active show\" id=\"custom-content-below-info\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-info-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات المنتج</h3>
                                        <div class=\"form-group\">
                                            ";
        // line 75
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 75), 'label');
        echo "
                                            ";
        // line 76
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 76), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 77
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 77), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"form-group\">
                                            ";
        // line 80
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "content", [], "any", false, false, false, 80), 'label');
        echo "
                                            ";
        // line 81
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "content", [], "any", false, false, false, 81), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 82
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "content", [], "any", false, false, false, 82), 'errors');
        echo "</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade show\" id=\"custom-content-below-department\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-department-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>القسم</h3>
                                        <div class=\"form-group\">
                                            <input id=\"department_form_department\" type=\"hidden\" name=\"department_id\" value=\"\">
                                            ";
        // line 92
        echo "                                            <div id=\"jstree_demo_div\"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-settings\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-settings-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>اعدادات المنتج</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 101
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price", [], "any", false, false, false, 101), 'label');
        echo "
                                                ";
        // line 102
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price", [], "any", false, false, false, 102), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 103
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price", [], "any", false, false, false, 103), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 106
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "stock", [], "any", false, false, false, 106), 'label');
        echo "
                                                ";
        // line 107
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "stock", [], "any", false, false, false, 107), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 108
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "stock", [], "any", false, false, false, 108), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 111
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_at", [], "any", false, false, false, 111), 'label');
        echo "
                                                ";
        // line 112
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_at", [], "any", false, false, false, 112), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 113
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_at", [], "any", false, false, false, 113), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 116
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_at", [], "any", false, false, false, 116), 'label');
        echo "
                                                ";
        // line 117
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_at", [], "any", false, false, false, 117), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 118
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_at", [], "any", false, false, false, 118), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                        <div class=\"form-group\">
                                            ";
        // line 122
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price_offer", [], "any", false, false, false, 122), 'label');
        echo "
                                            ";
        // line 123
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price_offer", [], "any", false, false, false, 123), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 124
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price_offer", [], "any", false, false, false, 124), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 128
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_offer_at", [], "any", false, false, false, 128), 'label');
        echo "
                                                ";
        // line 129
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_offer_at", [], "any", false, false, false, 129), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 130
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_offer_at", [], "any", false, false, false, 130), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 133
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_offer_at", [], "any", false, false, false, 133), 'label');
        echo "
                                                ";
        // line 134
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_offer_at", [], "any", false, false, false, 134), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 135
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_offer_at", [], "any", false, false, false, 135), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-content\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-content-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>سبب الرفض والحالة</h3>
                                        <div class=\"form-group\">
                                            ";
        // line 144
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "status", [], "any", false, false, false, 144), 'label');
        echo "
                                            ";
        // line 145
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "status", [], "any", false, false, false, 145), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 146
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "status", [], "any", false, false, false, 146), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"form-group\">
                                            ";
        // line 149
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "reason", [], "any", false, false, false, 149), 'label');
        echo "
                                            ";
        // line 150
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "reason", [], "any", false, false, false, 150), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 151
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "reason", [], "any", false, false, false, 151), 'errors');
        echo "</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-sizes\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-sizes-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>الوزن والحجم</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 160
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight_string", [], "any", false, false, false, 160), 'label');
        echo "
                                                ";
        // line 161
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight_string", [], "any", false, false, false, 161), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 162
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight_string", [], "any", false, false, false, 162), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 165
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight", [], "any", false, false, false, 165), 'label');
        echo "
                                                ";
        // line 166
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight", [], "any", false, false, false, 166), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 167
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight", [], "any", false, false, false, 167), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 170
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Size", [], "any", false, false, false, 170), 'label');
        echo "
                                                ";
        // line 171
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Size", [], "any", false, false, false, 171), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 172
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Size", [], "any", false, false, false, 172), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 175
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "size_string", [], "any", false, false, false, 175), 'label');
        echo "
                                                ";
        // line 176
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "size_string", [], "any", false, false, false, 176), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 177
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "size_string", [], "any", false, false, false, 177), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 180
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Country", [], "any", false, false, false, 180), 'label');
        echo "
                                                ";
        // line 181
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Country", [], "any", false, false, false, 181), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 182
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Country", [], "any", false, false, false, 182), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 185
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "ManuFact", [], "any", false, false, false, 185), 'label');
        echo "
                                                ";
        // line 186
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "ManuFact", [], "any", false, false, false, 186), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 187
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "ManuFact", [], "any", false, false, false, 187), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-12 col-lg-12 col-sm-12 col-sm-12\">
                                                ";
        // line 190
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Color", [], "any", false, false, false, 190), 'label');
        echo "
                                                ";
        // line 191
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Color", [], "any", false, false, false, 191), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 192
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Color", [], "any", false, false, false, 192), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-other\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-other-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات اضافية</h3>
                                        ";
        // line 200
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "photo", [], "any", false, false, false, 200), 'label');
        echo "
                                        ";
        // line 201
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "photo", [], "any", false, false, false, 201), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 202
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "photo", [], "any", false, false, false, 202), 'errors');
        echo "</div>
                                        ";
        // line 203
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Trademark", [], "any", false, false, false, 203), 'label');
        echo "
                                        ";
        // line 204
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Trademark", [], "any", false, false, false, 204), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 205
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Trademark", [], "any", false, false, false, 205), 'errors');
        echo "</div>
                                        ";
        // line 206
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "other_data", [], "any", false, false, false, 206), 'label');
        echo "
                                        ";
        // line 207
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "other_data", [], "any", false, false, false, 207), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 208
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "other_data", [], "any", false, false, false, 208), 'errors');
        echo "</div>
                                    </div>
                                </div>
                            </div>
                            <div style=\"margin-bottom: 5px;margin-top: 10px\">
                                <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
                                <a href=\"";
        // line 215
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.create", ["copyId" => twig_get_attribute($this->env, $this->source, ($context["product"] ?? null), "id", [], "any", false, false, false, 215)]), "html", null, true);
        echo "\" class=\"btn btn-primary\"> نسخ المنتج <i class=\"fa fa-copy\"></i></a>
                                <a href=\"";
        // line 216
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
                                <a href=\"";
        // line 217
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.destroy", ["id" => twig_get_attribute($this->env, $this->source, ($context["product"] ?? null), "id", [], "any", false, false, false, 217)]), "html", null, true);
        echo "\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger\"> حذف <i class=\"fa fa-trash\"></i></a>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div><!-- /.container-fluid -->
    </section>

";
    }

    // line 231
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 232
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/themes/default/style.min.css\" />
    <link rel=\"stylesheet\" href=\"";
        // line 233
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2.min.css\">
    <link rel=\"stylesheet\" href=\"";
        // line 234
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2-bootstrap4.min.css\">

";
    }

    // line 238
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 239
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/jstree.min.js\"></script>
    <script src=\"";
        // line 240
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2.full.min.js\"></script>
    <script src=\"https://cdn.ckeditor.com/4.14.0/standard-all/ckeditor.js\"></script>

    <script>
        ";
        // line 245
        echo "        ";
        // line 246
        echo "        ";
        // line 247
        echo "
        ";
        // line 249
        echo "        ";
        // line 250
        echo "        ";
        // line 251
        echo "        ";
        // line 252
        echo "        ";
        // line 253
        echo "        ";
        // line 254
        echo "        ";
        // line 255
        echo "        ";
        // line 256
        echo "        ";
        // line 257
        echo "        ";
        // line 258
        echo "        ";
        // line 259
        echo "        ";
        // line 260
        echo "        ";
        // line 261
        echo "        ";
        // line 262
        echo "        ";
        // line 263
        echo "        ";
        // line 264
        echo "        ";
        // line 265
        echo "        ";
        // line 266
        echo "        ";
        // line 267
        echo "
        \$(function () { \$('#jstree_demo_div').jstree({ 'core' : {
                'data' : ";
        // line 269
        echo ($context["departments"] ?? null);
        echo "
            } }); });

        \$('#jstree_demo_div').on(\"changed.jstree\", function (e, data) {
            \$('#department_form_department').val(data.selected);

            \$.ajax({
                'method': 'POST',
                'url' : '";
        // line 277
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.specific.size");
        echo "',
                'type' : 'json',
                'data' : {id:data.selected},
                success : function (data_ajax) {
                    \$('#product_form_Size').html('');
                    \$.each(data_ajax, function( index, size ) {
                        \$('#product_form_Size').append(`<option value=\"\${size.id}\">\${size.name}</option>`);
                    });
                },
                beforeSend: function(){
                    \$('.card-footer button').attr('disabled' ,'disabled');
                },
                complete: function(){
                    \$('.card-footer button').removeAttr('disabled' ,'disabled');
                },
            });
        });

        \$(document).ready(function() {
            \$('.select2').select2();
            CKEDITOR.replace('product_form[content]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });

            CKEDITOR.replace('product_form[other_data]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });
        });
    </script>
";
    }

    public function getTemplateName()
    {
        return "dashboard/products/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  608 => 277,  597 => 269,  593 => 267,  591 => 266,  589 => 265,  587 => 264,  585 => 263,  583 => 262,  581 => 261,  579 => 260,  577 => 259,  575 => 258,  573 => 257,  571 => 256,  569 => 255,  567 => 254,  565 => 253,  563 => 252,  561 => 251,  559 => 250,  557 => 249,  554 => 247,  552 => 246,  550 => 245,  543 => 240,  538 => 239,  534 => 238,  527 => 234,  523 => 233,  518 => 232,  514 => 231,  497 => 217,  493 => 216,  489 => 215,  479 => 208,  475 => 207,  471 => 206,  467 => 205,  463 => 204,  459 => 203,  455 => 202,  451 => 201,  447 => 200,  436 => 192,  432 => 191,  428 => 190,  422 => 187,  418 => 186,  414 => 185,  408 => 182,  404 => 181,  400 => 180,  394 => 177,  390 => 176,  386 => 175,  380 => 172,  376 => 171,  372 => 170,  366 => 167,  362 => 166,  358 => 165,  352 => 162,  348 => 161,  344 => 160,  332 => 151,  328 => 150,  324 => 149,  318 => 146,  314 => 145,  310 => 144,  298 => 135,  294 => 134,  290 => 133,  284 => 130,  280 => 129,  276 => 128,  269 => 124,  265 => 123,  261 => 122,  254 => 118,  250 => 117,  246 => 116,  240 => 113,  236 => 112,  232 => 111,  226 => 108,  222 => 107,  218 => 106,  212 => 103,  208 => 102,  204 => 101,  193 => 92,  181 => 82,  177 => 81,  173 => 80,  167 => 77,  163 => 76,  159 => 75,  130 => 49,  126 => 48,  121 => 46,  117 => 45,  113 => 44,  108 => 41,  96 => 35,  90 => 31,  86 => 30,  66 => 13,  62 => 12,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/products/edit.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/products/edit.html.twig");
    }
}
