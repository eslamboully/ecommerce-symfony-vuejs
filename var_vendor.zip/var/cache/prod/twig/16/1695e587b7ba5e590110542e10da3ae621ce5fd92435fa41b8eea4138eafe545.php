<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/manufacts/create.html.twig */
class __TwigTemplate_89a164785528df208ecd270c45c78d52c22b3d305994c03e289f42513b9d9a5d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/manufacts/create.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">اضف مصنع</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.trademarks.index");
        echo "\">المصنعين</a></li>
                        <li class=\"breadcrumb-item active\">اضف</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                            <form role=\"form\" method=\"post\" enctype=\"multipart/form-data\">
                                ";
        // line 29
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        echo "
                                ";
        // line 30
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "_token", [], "any", false, false, false, 30), 'row');
        echo "
                                <div class=\"card-body\">
                                    <div class=\"form-group\">
                                        ";
        // line 33
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 33), 'label');
        echo "
                                        ";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 34), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 35
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 35), 'errors');
        echo "</div>
                                    </div>
                                    <div class=\"form-group\">
                                        ";
        // line 38
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "contact_name", [], "any", false, false, false, 38), 'label');
        echo "
                                        ";
        // line 39
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "contact_name", [], "any", false, false, false, 39), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 40
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "contact_name", [], "any", false, false, false, 40), 'errors');
        echo "</div>
                                    </div>
                                    <div class=\"form-group\">
                                        ";
        // line 43
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "email", [], "any", false, false, false, 43), 'label');
        echo "
                                        ";
        // line 44
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "email", [], "any", false, false, false, 44), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 45
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "email", [], "any", false, false, false, 45), 'errors');
        echo "</div>
                                    </div>
                                    <div class=\"form-group\">
                                        ";
        // line 48
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "phone", [], "any", false, false, false, 48), 'label');
        echo "
                                        ";
        // line 49
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "phone", [], "any", false, false, false, 49), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 50
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "phone", [], "any", false, false, false, 50), 'errors');
        echo "</div>
                                    </div>
                                    <div class=\"form-group\">
                                        ";
        // line 53
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "facebook", [], "any", false, false, false, 53), 'label');
        echo "
                                        ";
        // line 54
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "facebook", [], "any", false, false, false, 54), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 55
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "facebook", [], "any", false, false, false, 55), 'errors');
        echo "</div>
                                    </div>
                                    <div class=\"form-group\">
                                        ";
        // line 58
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "twitter", [], "any", false, false, false, 58), 'label');
        echo "
                                        ";
        // line 59
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "twitter", [], "any", false, false, false, 59), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 60
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "twitter", [], "any", false, false, false, 60), 'errors');
        echo "</div>
                                    </div>
                                    <div class=\"form-group\">
                                        ";
        // line 63
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "icon", [], "any", false, false, false, 63), 'label');
        echo "
                                        ";
        // line 64
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "icon", [], "any", false, false, false, 64), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 65
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "icon", [], "any", false, false, false, 65), 'errors');
        echo "</div>
                                    </div>

                                    <div class=\"form-group\">
                                        <div class=\"row\">
                                            <div class=\"col-md-6\">
                                                ";
        // line 71
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lng", [], "any", false, false, false, 71), 'label');
        echo "
                                                ";
        // line 72
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lng", [], "any", false, false, false, 72), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 73
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lng", [], "any", false, false, false, 73), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"col-md-6\">
                                                ";
        // line 76
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lat", [], "any", false, false, false, 76), 'label');
        echo "
                                                ";
        // line 77
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lat", [], "any", false, false, false, 77), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 78
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lat", [], "any", false, false, false, 78), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class=\"form-group\">
                                        <div id=\"map\"></div>
                                        <pre id=\"coordinates\" class=\"coordinates\"></pre>
                                    </div>

                                </div>
                                <!-- /.card-body -->

                                <div class=\"card-footer\">
                                    <button type=\"submit\" class=\"btn btn-primary\">ارسال</button>
                                </div>
                            </form>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


";
    }

    // line 106
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 107
        echo "    <script src=\"https://api.mapbox.com/mapbox-gl-js/v1.10.1/mapbox-gl.js\"></script>
    <link href=\"https://api.mapbox.com/mapbox-gl-js/v1.10.1/mapbox-gl.css\" rel=\"stylesheet\" />
    <style>
        body { margin: 0; padding: 0; }
        #map { top: 0; bottom: 0;height: 300px; width: 100%; }
    </style>
";
    }

    // line 115
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 116
        echo "    <script>
        mapboxgl.accessToken = 'pk.eyJ1IjoiZXNsYW1ib3VsbHkiLCJhIjoiY2thaWdncDE3MDBqMjJ6dGR4cHhzeDlkYiJ9.ZUE0a2peQttyyS3jxfiPlQ';
        var coordinates = document.getElementById('coordinates');
        var map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/streets-v11',
            center: [31.16846825678161, 29.979570192574613],
            zoom: 4
        });

        var marker = new mapboxgl.Marker({
            draggable: true
        })
            .setLngLat([31.230049306794115, 30.076842995595257])
            .addTo(map);

        function onDragEnd() {
            var lngLat = marker.getLngLat();
            coordinates.style.display = 'block';
            \$('#manu_fact_form_lng').val(lngLat.lng);
            \$('#manu_fact_form_lat').val(lngLat.lat);
        }

        marker.on('dragend', onDragEnd);
    </script>

    <script>

    </script>
";
    }

    public function getTemplateName()
    {
        return "dashboard/manufacts/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  267 => 116,  263 => 115,  253 => 107,  249 => 106,  218 => 78,  214 => 77,  210 => 76,  204 => 73,  200 => 72,  196 => 71,  187 => 65,  183 => 64,  179 => 63,  173 => 60,  169 => 59,  165 => 58,  159 => 55,  155 => 54,  151 => 53,  145 => 50,  141 => 49,  137 => 48,  131 => 45,  127 => 44,  123 => 43,  117 => 40,  113 => 39,  109 => 38,  103 => 35,  99 => 34,  95 => 33,  89 => 30,  85 => 29,  66 => 13,  62 => 12,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/manufacts/create.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/manufacts/create.html.twig");
    }
}
