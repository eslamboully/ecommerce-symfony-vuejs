<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/manufacts/index.html.twig */
class __TwigTemplate_8b6699f38dd664a8d43e133a6587b58a9cdeee9d354f07f48dd7b9e15cec8242 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/manufacts/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/manufacts/index.html.twig"));

        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/manufacts/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">جدول المصنعين</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item active\">المصنعين</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <div class=\"card-header\">
";
        // line 29
        echo "                            <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.manufacts.create");
        echo "\" class=\"btn btn-success btn-md\"><i class=\"fa fa-plus\"></i> اضف جديد </a>
                            <a href=\"\" class=\"btn btn-info btn-md\" onclick=\"window.print()\"><i class=\"fa fa-print\"></i> طباعة </a>
                            <a href=\"\" class=\"btn btn-primary btn-md\"><i class=\"fa fa-plus\"></i> استيراد اكسل </a>
                            <a href=\"\" class=\"btn btn-default btn-md\"><i class=\"fa fa-refresh\"></i></a>
                            <a href=\"\" class=\"btn btn-danger btn-md\"><i class=\"fa fa-trash\"></i> حذف الكل </a>
                        </div>
                        <!-- /.card-header -->
                        <div class=\"card-body\">
                            ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 37, $this->source); })()), "flashes", [0 => "success"], "method", false, false, false, 37));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 38
            echo "                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <div class=\"card\">
                                            <div class=\"card-body label label-success\">
                                                <div style=\"font-size: 18px;\">";
            // line 42
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "
                            ";
        // line 49
        if (1 === twig_compare(twig_length_filter($this->env, (isset($context["manufacts"]) || array_key_exists("manufacts", $context) ? $context["manufacts"] : (function () { throw new RuntimeError('Variable "manufacts" does not exist.', 49, $this->source); })())), 0)) {
            // line 50
            echo "                                <table id=\"table-country\" class=\"table table-bordered\">
                                    <tr>
                                        <th>#</th>
                                        <th>الاسم</th>
                                        <th>المسؤوول</th>
                                        <th>الهاتف المحمول</th>
                                        <th>الشعار</th>
                                        <th>العمليات</th>
                                    </tr>

                                    ";
            // line 60
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["manufacts"]) || array_key_exists("manufacts", $context) ? $context["manufacts"] : (function () { throw new RuntimeError('Variable "manufacts" does not exist.', 60, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["manufact"]) {
                // line 61
                echo "                                        <tr>
                                            <td>";
                // line 62
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["manufact"], "id", [], "any", false, false, false, 62), "html", null, true);
                echo "</td>
                                            <td>";
                // line 63
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["manufact"], "name", [], "any", false, false, false, 63), "html", null, true);
                echo "</td>
                                            <td>";
                // line 64
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["manufact"], "contactName", [], "any", false, false, false, 64), "html", null, true);
                echo "</td>
                                            <td>";
                // line 65
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["manufact"], "phone", [], "any", false, false, false, 65), "html", null, true);
                echo "</td>
                                            <td>
                                                <img src=\"";
                // line 67
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, $context["manufact"], "icon", [], "any", false, false, false, 67)), "html", null, true);
                echo "\" style=\"width: 60px;height: 60px;border-radius: 20px\">
                                            </td>
                                            <td>
                                                <a href=\"";
                // line 70
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.manufacts.edit", ["id" => twig_get_attribute($this->env, $this->source, $context["manufact"], "id", [], "any", false, false, false, 70)]), "html", null, true);
                echo "\" class=\"btn btn-success btn-sm\"><i class=\"fa fa-edit\"></i> تعديل </a>
                                                <a href=\"";
                // line 71
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.manufacts.destroy", ["id" => twig_get_attribute($this->env, $this->source, $context["manufact"], "id", [], "any", false, false, false, 71)]), "html", null, true);
                echo "\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i> حذف </a>
                                            </td>
                                        </tr>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['manufact'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 75
            echo "                                </table>
                            ";
        } else {
            // line 77
            echo "                                <h1>للأسف لا يوجد مصنعين حتي الان</h1>
                            ";
        }
        // line 79
        echo "                        </div>
                        <!-- /.card-body -->
";
        // line 90
        echo "                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
        </div><!-- /.container-fluid -->
    </section>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "dashboard/manufacts/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  204 => 90,  200 => 79,  196 => 77,  192 => 75,  182 => 71,  178 => 70,  172 => 67,  167 => 65,  163 => 64,  159 => 63,  155 => 62,  152 => 61,  148 => 60,  136 => 50,  134 => 49,  131 => 48,  119 => 42,  113 => 38,  109 => 37,  97 => 29,  78 => 12,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'dashboard/layouts/base.html.twig' %}

{% block content %}
    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">جدول المصنعين</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"{{ path('dashboard.index') }}\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item active\">المصنعين</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <div class=\"card-header\">
{#                            <h3 class=\"card-title\">جدول المستخدمين</h3>#}
                            <a href=\"{{ path('dashboard.manufacts.create') }}\" class=\"btn btn-success btn-md\"><i class=\"fa fa-plus\"></i> اضف جديد </a>
                            <a href=\"\" class=\"btn btn-info btn-md\" onclick=\"window.print()\"><i class=\"fa fa-print\"></i> طباعة </a>
                            <a href=\"\" class=\"btn btn-primary btn-md\"><i class=\"fa fa-plus\"></i> استيراد اكسل </a>
                            <a href=\"\" class=\"btn btn-default btn-md\"><i class=\"fa fa-refresh\"></i></a>
                            <a href=\"\" class=\"btn btn-danger btn-md\"><i class=\"fa fa-trash\"></i> حذف الكل </a>
                        </div>
                        <!-- /.card-header -->
                        <div class=\"card-body\">
                            {% for message in app.flashes('success') %}
                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <div class=\"card\">
                                            <div class=\"card-body label label-success\">
                                                <div style=\"font-size: 18px;\">{{ message }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            {% endfor %}

                            {% if manufacts|length > 0 %}
                                <table id=\"table-country\" class=\"table table-bordered\">
                                    <tr>
                                        <th>#</th>
                                        <th>الاسم</th>
                                        <th>المسؤوول</th>
                                        <th>الهاتف المحمول</th>
                                        <th>الشعار</th>
                                        <th>العمليات</th>
                                    </tr>

                                    {% for manufact in manufacts %}
                                        <tr>
                                            <td>{{ manufact.id }}</td>
                                            <td>{{ manufact.name }}</td>
                                            <td>{{ manufact.contactName }}</td>
                                            <td>{{ manufact.phone }}</td>
                                            <td>
                                                <img src=\"{{ asset(manufact.icon) }}\" style=\"width: 60px;height: 60px;border-radius: 20px\">
                                            </td>
                                            <td>
                                                <a href=\"{{ path('dashboard.manufacts.edit',{\"id\":manufact.id}) }}\" class=\"btn btn-success btn-sm\"><i class=\"fa fa-edit\"></i> تعديل </a>
                                                <a href=\"{{ path('dashboard.manufacts.destroy',{\"id\":manufact.id}) }}\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i> حذف </a>
                                            </td>
                                        </tr>
                                    {% endfor %}
                                </table>
                            {% else %}
                                <h1>للأسف لا يوجد مصنعين حتي الان</h1>
                            {% endif %}
                        </div>
                        <!-- /.card-body -->
{#                        <div class=\"card-footer clearfix\">#}
{#                            <ul class=\"pagination pagination-sm m-0 float-right\">#}
{#                                <li class=\"page-item\"><a class=\"page-link\" href=\"#\">&laquo;</a></li>#}
{#                                <li class=\"page-item\"><a class=\"page-link\" href=\"#\">1</a></li>#}
{#                                <li class=\"page-item\"><a class=\"page-link\" href=\"#\">2</a></li>#}
{#                                <li class=\"page-item\"><a class=\"page-link\" href=\"#\">3</a></li>#}
{#                                <li class=\"page-item\"><a class=\"page-link\" href=\"#\">&raquo;</a></li>#}
{#                            </ul>#}
{#                        </div>#}
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
        </div><!-- /.container-fluid -->
    </section>

{% endblock %}
", "dashboard/manufacts/index.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/manufacts/index.html.twig");
    }
}
