<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/security/login.html.twig */
class __TwigTemplate_c5c91f5694b312b7fd2fe0c95a4e4562c06fc8884f39638f5d3fa29fa126e5e8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/security/login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/security/login.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <title>لوحة التحكم | تسجيل الدخول</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <!-- Font Awesome -->
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css\">
    <!-- Ionicons -->
    <link rel=\"stylesheet\" href=\"https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css\">
    <!-- Theme style -->
    <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/css/adminlte.min.css\">
    <!-- iCheck -->
    <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/iCheck/square/blue.css\">
    <!-- Google Font: Source Sans Pro -->
    <link href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700\" rel=\"stylesheet\">

    <!-- bootstrap rtl -->
    <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/css/bootstrap-rtl.min.css\">
    <!-- template rtl version -->
    <link rel=\"stylesheet\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/css/custom-style.css\">

    <link href=\"https://fonts.googleapis.com/css2?family=Cairo&display=swap\" rel=\"stylesheet\">

    <style>
        body, h1, h2, h3, h4, h5, h6 {
            font-family: 'Cairo', sans-serif !important;
        }
    </style>
</head>
<body class=\"hold-transition login-page\">
<div class=\"login-box\">
    <div class=\"login-logo\">
        <a href=\"#\"><b>لوحة التحكم</b></a>
    </div>
    <!-- /.login-logo -->
    <div class=\"card\">
        <div class=\"card-body login-card-body\">
            <p class=\"login-box-msg\">تسجيل دخول المشرفين</p>

            <form method=\"post\">
                ";
        // line 45
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 45, $this->source); })())) {
            // line 46
            echo "                    <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 46, $this->source); })()), "messageKey", [], "any", false, false, false, 46), twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 46, $this->source); })()), "messageData", [], "any", false, false, false, 46), "security"), "html", null, true);
            echo "</div>
                ";
        }
        // line 48
        echo "                <input type=\"hidden\" name=\"_csrf_token\"
                       value=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"
                >
                <div class=\"input-group mb-3\">
                    <input type=\"email\" value=\"";
        // line 52
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new RuntimeError('Variable "last_username" does not exist.', 52, $this->source); })()), "html", null, true);
        echo "\" name=\"email\" class=\"form-control\" placeholder=\"البريد الالكتروني\">
                    <div class=\"input-group-append\">
                        <span class=\"fa fa-envelope input-group-text\"></span>
                    </div>
                </div>
                <div class=\"input-group mb-3\">
                    <input type=\"password\" name=\"password\" class=\"form-control\" placeholder=\"كلمة المرور\">
                    <div class=\"input-group-append\">
                        <span class=\"fa fa-lock input-group-text\"></span>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-8\">
                        <div class=\"checkbox icheck\">
                            <label>
                                <input type=\"checkbox\" name=\"_remember_me\"> تذكرني
                            </label>
                        </div>
                    </div>
                    <!-- /.col -->
                    <div class=\"col-4\">
                        <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">دخول</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>
        </div>
        <!-- /.login-card-body -->
    </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src=\"";
        // line 85
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/jquery/jquery.min.js\"></script>
<!-- Bootstrap 4 -->
<script src=\"";
        // line 87
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/bootstrap/js/bootstrap.bundle.min.js\"></script>
<!-- iCheck -->
<script src=\"";
        // line 89
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/iCheck/icheck.min.js\"></script>
<script>
    \$(function () {
        \$('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass   : 'iradio_square-blue',
            increaseArea : '20%' // optional
        })
    })
</script>
</body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "dashboard/security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 89,  159 => 87,  154 => 85,  118 => 52,  112 => 49,  109 => 48,  103 => 46,  101 => 45,  77 => 24,  72 => 22,  64 => 17,  59 => 15,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <title>لوحة التحكم | تسجيل الدخول</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <!-- Font Awesome -->
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css\">
    <!-- Ionicons -->
    <link rel=\"stylesheet\" href=\"https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css\">
    <!-- Theme style -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/dist/css/adminlte.min.css\">
    <!-- iCheck -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/iCheck/square/blue.css\">
    <!-- Google Font: Source Sans Pro -->
    <link href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700\" rel=\"stylesheet\">

    <!-- bootstrap rtl -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/dist/css/bootstrap-rtl.min.css\">
    <!-- template rtl version -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/dist/css/custom-style.css\">

    <link href=\"https://fonts.googleapis.com/css2?family=Cairo&display=swap\" rel=\"stylesheet\">

    <style>
        body, h1, h2, h3, h4, h5, h6 {
            font-family: 'Cairo', sans-serif !important;
        }
    </style>
</head>
<body class=\"hold-transition login-page\">
<div class=\"login-box\">
    <div class=\"login-logo\">
        <a href=\"#\"><b>لوحة التحكم</b></a>
    </div>
    <!-- /.login-logo -->
    <div class=\"card\">
        <div class=\"card-body login-card-body\">
            <p class=\"login-box-msg\">تسجيل دخول المشرفين</p>

            <form method=\"post\">
                {% if error %}
                    <div class=\"alert alert-danger\">{{ error.messageKey|trans(error.messageData, 'security') }}</div>
                {% endif %}
                <input type=\"hidden\" name=\"_csrf_token\"
                       value=\"{{ csrf_token('authenticate') }}\"
                >
                <div class=\"input-group mb-3\">
                    <input type=\"email\" value=\"{{ last_username }}\" name=\"email\" class=\"form-control\" placeholder=\"البريد الالكتروني\">
                    <div class=\"input-group-append\">
                        <span class=\"fa fa-envelope input-group-text\"></span>
                    </div>
                </div>
                <div class=\"input-group mb-3\">
                    <input type=\"password\" name=\"password\" class=\"form-control\" placeholder=\"كلمة المرور\">
                    <div class=\"input-group-append\">
                        <span class=\"fa fa-lock input-group-text\"></span>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-8\">
                        <div class=\"checkbox icheck\">
                            <label>
                                <input type=\"checkbox\" name=\"_remember_me\"> تذكرني
                            </label>
                        </div>
                    </div>
                    <!-- /.col -->
                    <div class=\"col-4\">
                        <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">دخول</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>
        </div>
        <!-- /.login-card-body -->
    </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src=\"{{ asset('dashboard') }}/plugins/jquery/jquery.min.js\"></script>
<!-- Bootstrap 4 -->
<script src=\"{{ asset('dashboard') }}/plugins/bootstrap/js/bootstrap.bundle.min.js\"></script>
<!-- iCheck -->
<script src=\"{{ asset('dashboard') }}/plugins/iCheck/icheck.min.js\"></script>
<script>
    \$(function () {
        \$('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass   : 'iradio_square-blue',
            increaseArea : '20%' // optional
        })
    })
</script>
</body>
</html>
", "dashboard/security/login.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/security/login.html.twig");
    }
}
