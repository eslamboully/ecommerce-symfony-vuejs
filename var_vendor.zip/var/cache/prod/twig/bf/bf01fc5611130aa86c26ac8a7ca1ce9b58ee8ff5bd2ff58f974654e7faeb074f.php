<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/security/login.html.twig */
class __TwigTemplate_835bae226c29b46e2f498c65a1376270b2b074a2e036ef8faaa3c28c46a6a885 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <title>لوحة التحكم | تسجيل الدخول</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <!-- Font Awesome -->
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css\">
    <!-- Ionicons -->
    <link rel=\"stylesheet\" href=\"https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css\">
    <!-- Theme style -->
    <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/css/adminlte.min.css\">
    <!-- iCheck -->
    <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/iCheck/square/blue.css\">
    <!-- Google Font: Source Sans Pro -->
    <link href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700\" rel=\"stylesheet\">

    <!-- bootstrap rtl -->
    <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/css/bootstrap-rtl.min.css\">
    <!-- template rtl version -->
    <link rel=\"stylesheet\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/css/custom-style.css\">

    <link href=\"https://fonts.googleapis.com/css2?family=Cairo&display=swap\" rel=\"stylesheet\">

    <style>
        body, h1, h2, h3, h4, h5, h6 {
            font-family: 'Cairo', sans-serif !important;
        }
    </style>
</head>
<body class=\"hold-transition login-page\">
<div class=\"login-box\">
    <div class=\"login-logo\">
        <a href=\"#\"><b>لوحة التحكم</b></a>
    </div>
    <!-- /.login-logo -->
    <div class=\"card\">
        <div class=\"card-body login-card-body\">
            <p class=\"login-box-msg\">تسجيل دخول المشرفين</p>

            <form method=\"post\">
                ";
        // line 45
        if (($context["error"] ?? null)) {
            // line 46
            echo "                    <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, ($context["error"] ?? null), "messageKey", [], "any", false, false, false, 46), twig_get_attribute($this->env, $this->source, ($context["error"] ?? null), "messageData", [], "any", false, false, false, 46), "security"), "html", null, true);
            echo "</div>
                ";
        }
        // line 48
        echo "                <input type=\"hidden\" name=\"_csrf_token\"
                       value=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"
                >
                <div class=\"input-group mb-3\">
                    <input type=\"email\" value=\"";
        // line 52
        echo twig_escape_filter($this->env, ($context["last_username"] ?? null), "html", null, true);
        echo "\" name=\"email\" class=\"form-control\" placeholder=\"البريد الالكتروني\">
                    <div class=\"input-group-append\">
                        <span class=\"fa fa-envelope input-group-text\"></span>
                    </div>
                </div>
                <div class=\"input-group mb-3\">
                    <input type=\"password\" name=\"password\" class=\"form-control\" placeholder=\"كلمة المرور\">
                    <div class=\"input-group-append\">
                        <span class=\"fa fa-lock input-group-text\"></span>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-8\">
                        <div class=\"checkbox icheck\">
                            <label>
                                <input type=\"checkbox\" name=\"_remember_me\"> تذكرني
                            </label>
                        </div>
                    </div>
                    <!-- /.col -->
                    <div class=\"col-4\">
                        <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">دخول</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>
        </div>
        <!-- /.login-card-body -->
    </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src=\"";
        // line 85
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/jquery/jquery.min.js\"></script>
<!-- Bootstrap 4 -->
<script src=\"";
        // line 87
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/bootstrap/js/bootstrap.bundle.min.js\"></script>
<!-- iCheck -->
<script src=\"";
        // line 89
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/iCheck/icheck.min.js\"></script>
<script>
    \$(function () {
        \$('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass   : 'iradio_square-blue',
            increaseArea : '20%' // optional
        })
    })
</script>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "dashboard/security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  158 => 89,  153 => 87,  148 => 85,  112 => 52,  106 => 49,  103 => 48,  97 => 46,  95 => 45,  71 => 24,  66 => 22,  58 => 17,  53 => 15,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/security/login.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/security/login.html.twig");
    }
}
