<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/layouts/base.html.twig */
class __TwigTemplate_4fac3b6fa02f274330338878a7184e19318183822fc2bbee2b9a21fade95d4e1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'css' => [$this, 'block_css'],
            'content' => [$this, 'block_content'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/layouts/base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/layouts/base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <title>متجر السنيور | لوحة التحكم</title>
    <!-- Tell the browser to be responsive to screen width -->
";
        // line 9
        echo "    <meta name=\"viewport\" content=\"initial-scale=1,maximum-scale=1,user-scalable=no\" />

    <!-- Font Awesome -->
    <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/font-awesome/css/font-awesome.min.css\">
    <!-- Ionicons -->
    <link rel=\"stylesheet\" href=\"https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css\">
    <!-- Theme style -->
    <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/css/adminlte.min.css\">
    <!-- iCheck -->
    <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/iCheck/flat/blue.css\">
    <!-- Morris chart -->
    <link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/morris/morris.css\">
    <!-- jvectormap -->
    <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/jvectormap/jquery-jvectormap-1.2.2.css\">
    <!-- Date Picker -->
    <link rel=\"stylesheet\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/datepicker/datepicker3.css\">
    <!-- Daterange picker -->
    <link rel=\"stylesheet\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/daterangepicker/daterangepicker-bs3.css\">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel=\"stylesheet\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css\">
    <!-- Google Font: Source Sans Pro -->
    <link href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700\" rel=\"stylesheet\">
    <!-- bootstrap rtl -->
    <link rel=\"stylesheet\" href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/css/bootstrap-rtl.min.css\">
    <!-- template rtl version -->
    <link rel=\"stylesheet\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/css/custom-style.css\">

    <link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard/favicon.png"), "html", null, true);
        echo "\" />

    <link href=\"https://fonts.googleapis.com/css2?family=Cairo&display=swap\" rel=\"stylesheet\">

    <style>
        body, h1, h2, h3, h4, h5, h6 {
            font-family: 'Cairo', sans-serif !important;
        }

        .errors ul {
            list-style-type: none;
        }
    </style>

    ";
        // line 50
        $this->displayBlock('css', $context, $blocks);
        // line 51
        echo "</head>
<body class=\"hold-transition sidebar-mini\">

<div class=\"wrapper\">

    <!-- Navbar -->
    <nav class=\"main-header navbar navbar-expand bg-white navbar-light border-bottom\">
        <!-- Left navbar links -->
        <ul class=\"navbar-nav\">
            <li class=\"nav-item\">
                <a class=\"nav-link\" data-widget=\"pushmenu\" href=\"#\"><i class=\"fa fa-bars\"></i></a>
            </li>
            <li class=\"nav-item d-none d-sm-inline-block\">
                <a href=\"index3.html\" class=\"nav-link\">الذهاب للموقع</a>
            </li>
            <li class=\"nav-item d-none d-sm-inline-block\">
                <a href=\"#\" class=\"nav-link\">الطلبات</a>
            </li>
        </ul>

        <!-- SEARCH FORM -->
        <form class=\"form-inline ml-3\">
            <div class=\"input-group input-group-sm\">
                <input class=\"form-control form-control-navbar\" type=\"search\" placeholder=\"بحث...\" aria-label=\"Search\">
                <div class=\"input-group-append\">
                    <button class=\"btn btn-navbar\" type=\"submit\">
                        <i class=\"fa fa-search\"></i>
                    </button>
                </div>
            </div>
        </form>

        <!-- Right navbar links -->
        <ul class=\"navbar-nav mr-auto\">
            <!-- Messages Dropdown Menu -->
            <li class=\"nav-item dropdown\">
                <a class=\"nav-link\" data-toggle=\"dropdown\" href=\"#\">
                    <i class=\"fa fa-comments-o\"></i>
                    <span class=\"badge badge-danger navbar-badge\">3</span>
                </a>
                <div class=\"dropdown-menu dropdown-menu-lg dropdown-menu-left\">
                    <a href=\"#\" class=\"dropdown-item\">
                        <!-- Message Start -->
                        <div class=\"media\">
                            <img src=\"";
        // line 95
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/img/user1-128x128.jpg\" alt=\"User Avatar\" class=\"img-size-50 ml-3 img-circle\">
                            <div class=\"media-body\">
                                <h3 class=\"dropdown-item-title\">
                                    محمدرضا عطوان
                                    <span class=\"float-left text-sm text-danger\"><i class=\"fa fa-star\"></i></span>
                                </h3>
                                <p class=\"text-sm\">با من تماس بگیر لطفا...</p>
                                <p class=\"text-sm text-muted\"><i class=\"fa fa-clock-o mr-1\"></i> 4 ساعت قبل</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item\">
                        <!-- Message Start -->
                        <div class=\"media\">
                            <img src=\"";
        // line 111
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/img/user8-128x128.jpg\" alt=\"User Avatar\" class=\"img-size-50 img-circle ml-3\">
                            <div class=\"media-body\">
                                <h3 class=\"dropdown-item-title\">
                                    پیمان احمدی
                                    <span class=\"float-left text-sm text-muted\"><i class=\"fa fa-star\"></i></span>
                                </h3>
                                <p class=\"text-sm\">من پیامتو دریافت کردم</p>
                                <p class=\"text-sm text-muted\"><i class=\"fa fa-clock-o mr-1\"></i> 4 ساعت قبل</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item\">
                        <!-- Message Start -->
                        <div class=\"media\">
                            <img src=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/img/user3-128x128.jpg\" alt=\"User Avatar\" class=\"img-size-50 img-circle ml-3\">
                            <div class=\"media-body\">
                                <h3 class=\"dropdown-item-title\">
                                    سارا وکیلی
                                    <span class=\"float-left text-sm text-warning\"><i class=\"fa fa-star\"></i></span>
                                </h3>
                                <p class=\"text-sm\">پروژه اتون عالی بود مرسی واقعا</p>
                                <p class=\"text-sm text-muted\"><i class=\"fa fa-clock-o mr-1\"></i>4 ساعت قبل</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item dropdown-footer\">مشاهده همه پیام‌ها</a>
                </div>
            </li>
            <!-- Notifications Dropdown Menu -->
            <li class=\"nav-item dropdown\">
                <a class=\"nav-link\" data-toggle=\"dropdown\" href=\"#\">
                    <i class=\"fa fa-bell-o\"></i>
                    <span class=\"badge badge-warning navbar-badge\">15</span>
                </a>
                <div class=\"dropdown-menu dropdown-menu-lg dropdown-menu-left\">
                    <span class=\"dropdown-item dropdown-header\">15 نوتیفیکیشن</span>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item\">
                        <i class=\"fa fa-envelope ml-2\"></i> 4 پیام جدید
                        <span class=\"float-left text-muted text-sm\">3 دقیقه</span>
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item\">
                        <i class=\"fa fa-users ml-2\"></i> 8 درخواست دوستی
                        <span class=\"float-left text-muted text-sm\">12 ساعت</span>
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item\">
                        <i class=\"fa fa-file ml-2\"></i> 3 گزارش جدید
                        <span class=\"float-left text-muted text-sm\">2 روز</span>
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item dropdown-footer\">مشاهده همه نوتیفیکیشن</a>
                </div>
            </li>
            <li class=\"nav-item\">
                <a class=\"nav-link\" data-widget=\"control-sidebar\" data-slide=\"true\" href=\"#\"><i
                            class=\"fa fa-th-large\"></i></a>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    ";
        // line 179
        $this->loadTemplate("dashboard/layouts/aside.html.twig", "dashboard/layouts/base.html.twig", 179)->display($context);
        // line 180
        echo "
    <!-- Content Wrapper. Contains page content -->
    <div class=\"content-wrapper\">
        <!-- Content Header (Page header) -->
        ";
        // line 184
        $this->displayBlock('content', $context, $blocks);
        // line 185
        echo "        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class=\"main-footer\">
        <strong> جميع الحقوق محفوظة &copy;  <a href=\"http://abdelrahman.el-senior.tech/\">عبدالرحمن اسامة</a>.</strong>
    </footer>

    <!-- Control Sidebar -->
    <aside class=\"control-sidebar control-sidebar-dark\">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src=\"";
        // line 201
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/jquery/jquery.min.js\"></script>
<!-- jQuery UI 1.11.4 -->
<script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.min.js\"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    \$.widget.bridge('uibutton', \$.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src=\"";
        // line 209
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/bootstrap/js/bootstrap.bundle.min.js\"></script>
<!-- Morris.js charts -->
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js\"></script>
<script src=\"";
        // line 212
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/morris/morris.min.js\"></script>
<!-- Sparkline -->
<script src=\"";
        // line 214
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/sparkline/jquery.sparkline.min.js\"></script>
<!-- jvectormap -->
<script src=\"";
        // line 216
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js\"></script>
<script src=\"";
        // line 217
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/jvectormap/jquery-jvectormap-world-mill-en.js\"></script>
<!-- jQuery Knob Chart -->
<script src=\"";
        // line 219
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/knob/jquery.knob.js\"></script>
<!-- daterangepicker -->
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js\"></script>
<script src=\"";
        // line 222
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/daterangepicker/daterangepicker.js\"></script>
<!-- datepicker -->
<script src=\"";
        // line 224
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/datepicker/bootstrap-datepicker.js\"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src=\"";
        // line 226
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js\"></script>
<!-- Slimscroll -->
<script src=\"";
        // line 228
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/slimScroll/jquery.slimscroll.min.js\"></script>
<!-- FastClick -->
<script src=\"";
        // line 230
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/fastclick/fastclick.js\"></script>
<!-- AdminLTE App -->
<script src=\"";
        // line 232
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/js/adminlte.js\"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src=\"";
        // line 234
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/js/pages/dashboard.js\"></script>
<!-- AdminLTE for demo purposes -->
<script src=\"";
        // line 236
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/js/demo.js\"></script>


";
        // line 239
        $this->displayBlock('js', $context, $blocks);
        // line 240
        echo "<script>
    \$(\"button[type=submit]\").on('click',function () {
        \$(\"button[type=submit]\").attr(\"disabled\",\"disabled\");
    });
</script>
</body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 50
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 184
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 239
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "dashboard/layouts/base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  438 => 239,  420 => 184,  402 => 50,  385 => 240,  383 => 239,  377 => 236,  372 => 234,  367 => 232,  362 => 230,  357 => 228,  352 => 226,  347 => 224,  342 => 222,  336 => 219,  331 => 217,  327 => 216,  322 => 214,  317 => 212,  311 => 209,  300 => 201,  282 => 185,  280 => 184,  274 => 180,  272 => 179,  217 => 127,  198 => 111,  179 => 95,  133 => 51,  131 => 50,  114 => 36,  109 => 34,  104 => 32,  97 => 28,  92 => 26,  87 => 24,  82 => 22,  77 => 20,  72 => 18,  67 => 16,  60 => 12,  55 => 9,  46 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <title>متجر السنيور | لوحة التحكم</title>
    <!-- Tell the browser to be responsive to screen width -->
{#    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">#}
    <meta name=\"viewport\" content=\"initial-scale=1,maximum-scale=1,user-scalable=no\" />

    <!-- Font Awesome -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/font-awesome/css/font-awesome.min.css\">
    <!-- Ionicons -->
    <link rel=\"stylesheet\" href=\"https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css\">
    <!-- Theme style -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/dist/css/adminlte.min.css\">
    <!-- iCheck -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/iCheck/flat/blue.css\">
    <!-- Morris chart -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/morris/morris.css\">
    <!-- jvectormap -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/jvectormap/jquery-jvectormap-1.2.2.css\">
    <!-- Date Picker -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/datepicker/datepicker3.css\">
    <!-- Daterange picker -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/daterangepicker/daterangepicker-bs3.css\">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css\">
    <!-- Google Font: Source Sans Pro -->
    <link href=\"https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700\" rel=\"stylesheet\">
    <!-- bootstrap rtl -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/dist/css/bootstrap-rtl.min.css\">
    <!-- template rtl version -->
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/dist/css/custom-style.css\">

    <link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"{{ asset('dashboard/favicon.png') }}\" />

    <link href=\"https://fonts.googleapis.com/css2?family=Cairo&display=swap\" rel=\"stylesheet\">

    <style>
        body, h1, h2, h3, h4, h5, h6 {
            font-family: 'Cairo', sans-serif !important;
        }

        .errors ul {
            list-style-type: none;
        }
    </style>

    {% block css %}{% endblock %}
</head>
<body class=\"hold-transition sidebar-mini\">

<div class=\"wrapper\">

    <!-- Navbar -->
    <nav class=\"main-header navbar navbar-expand bg-white navbar-light border-bottom\">
        <!-- Left navbar links -->
        <ul class=\"navbar-nav\">
            <li class=\"nav-item\">
                <a class=\"nav-link\" data-widget=\"pushmenu\" href=\"#\"><i class=\"fa fa-bars\"></i></a>
            </li>
            <li class=\"nav-item d-none d-sm-inline-block\">
                <a href=\"index3.html\" class=\"nav-link\">الذهاب للموقع</a>
            </li>
            <li class=\"nav-item d-none d-sm-inline-block\">
                <a href=\"#\" class=\"nav-link\">الطلبات</a>
            </li>
        </ul>

        <!-- SEARCH FORM -->
        <form class=\"form-inline ml-3\">
            <div class=\"input-group input-group-sm\">
                <input class=\"form-control form-control-navbar\" type=\"search\" placeholder=\"بحث...\" aria-label=\"Search\">
                <div class=\"input-group-append\">
                    <button class=\"btn btn-navbar\" type=\"submit\">
                        <i class=\"fa fa-search\"></i>
                    </button>
                </div>
            </div>
        </form>

        <!-- Right navbar links -->
        <ul class=\"navbar-nav mr-auto\">
            <!-- Messages Dropdown Menu -->
            <li class=\"nav-item dropdown\">
                <a class=\"nav-link\" data-toggle=\"dropdown\" href=\"#\">
                    <i class=\"fa fa-comments-o\"></i>
                    <span class=\"badge badge-danger navbar-badge\">3</span>
                </a>
                <div class=\"dropdown-menu dropdown-menu-lg dropdown-menu-left\">
                    <a href=\"#\" class=\"dropdown-item\">
                        <!-- Message Start -->
                        <div class=\"media\">
                            <img src=\"{{ asset('dashboard') }}/dist/img/user1-128x128.jpg\" alt=\"User Avatar\" class=\"img-size-50 ml-3 img-circle\">
                            <div class=\"media-body\">
                                <h3 class=\"dropdown-item-title\">
                                    محمدرضا عطوان
                                    <span class=\"float-left text-sm text-danger\"><i class=\"fa fa-star\"></i></span>
                                </h3>
                                <p class=\"text-sm\">با من تماس بگیر لطفا...</p>
                                <p class=\"text-sm text-muted\"><i class=\"fa fa-clock-o mr-1\"></i> 4 ساعت قبل</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item\">
                        <!-- Message Start -->
                        <div class=\"media\">
                            <img src=\"{{ asset('dashboard') }}/dist/img/user8-128x128.jpg\" alt=\"User Avatar\" class=\"img-size-50 img-circle ml-3\">
                            <div class=\"media-body\">
                                <h3 class=\"dropdown-item-title\">
                                    پیمان احمدی
                                    <span class=\"float-left text-sm text-muted\"><i class=\"fa fa-star\"></i></span>
                                </h3>
                                <p class=\"text-sm\">من پیامتو دریافت کردم</p>
                                <p class=\"text-sm text-muted\"><i class=\"fa fa-clock-o mr-1\"></i> 4 ساعت قبل</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item\">
                        <!-- Message Start -->
                        <div class=\"media\">
                            <img src=\"{{ asset('dashboard') }}/dist/img/user3-128x128.jpg\" alt=\"User Avatar\" class=\"img-size-50 img-circle ml-3\">
                            <div class=\"media-body\">
                                <h3 class=\"dropdown-item-title\">
                                    سارا وکیلی
                                    <span class=\"float-left text-sm text-warning\"><i class=\"fa fa-star\"></i></span>
                                </h3>
                                <p class=\"text-sm\">پروژه اتون عالی بود مرسی واقعا</p>
                                <p class=\"text-sm text-muted\"><i class=\"fa fa-clock-o mr-1\"></i>4 ساعت قبل</p>
                            </div>
                        </div>
                        <!-- Message End -->
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item dropdown-footer\">مشاهده همه پیام‌ها</a>
                </div>
            </li>
            <!-- Notifications Dropdown Menu -->
            <li class=\"nav-item dropdown\">
                <a class=\"nav-link\" data-toggle=\"dropdown\" href=\"#\">
                    <i class=\"fa fa-bell-o\"></i>
                    <span class=\"badge badge-warning navbar-badge\">15</span>
                </a>
                <div class=\"dropdown-menu dropdown-menu-lg dropdown-menu-left\">
                    <span class=\"dropdown-item dropdown-header\">15 نوتیفیکیشن</span>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item\">
                        <i class=\"fa fa-envelope ml-2\"></i> 4 پیام جدید
                        <span class=\"float-left text-muted text-sm\">3 دقیقه</span>
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item\">
                        <i class=\"fa fa-users ml-2\"></i> 8 درخواست دوستی
                        <span class=\"float-left text-muted text-sm\">12 ساعت</span>
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item\">
                        <i class=\"fa fa-file ml-2\"></i> 3 گزارش جدید
                        <span class=\"float-left text-muted text-sm\">2 روز</span>
                    </a>
                    <div class=\"dropdown-divider\"></div>
                    <a href=\"#\" class=\"dropdown-item dropdown-footer\">مشاهده همه نوتیفیکیشن</a>
                </div>
            </li>
            <li class=\"nav-item\">
                <a class=\"nav-link\" data-widget=\"control-sidebar\" data-slide=\"true\" href=\"#\"><i
                            class=\"fa fa-th-large\"></i></a>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    {% include 'dashboard/layouts/aside.html.twig' %}

    <!-- Content Wrapper. Contains page content -->
    <div class=\"content-wrapper\">
        <!-- Content Header (Page header) -->
        {% block content %}{% endblock %}
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class=\"main-footer\">
        <strong> جميع الحقوق محفوظة &copy;  <a href=\"http://abdelrahman.el-senior.tech/\">عبدالرحمن اسامة</a>.</strong>
    </footer>

    <!-- Control Sidebar -->
    <aside class=\"control-sidebar control-sidebar-dark\">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src=\"{{ asset('dashboard') }}/plugins/jquery/jquery.min.js\"></script>
<!-- jQuery UI 1.11.4 -->
<script src=\"https://code.jquery.com/ui/1.12.1/jquery-ui.min.js\"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    \$.widget.bridge('uibutton', \$.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src=\"{{ asset('dashboard') }}/plugins/bootstrap/js/bootstrap.bundle.min.js\"></script>
<!-- Morris.js charts -->
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js\"></script>
<script src=\"{{ asset('dashboard') }}/plugins/morris/morris.min.js\"></script>
<!-- Sparkline -->
<script src=\"{{ asset('dashboard') }}/plugins/sparkline/jquery.sparkline.min.js\"></script>
<!-- jvectormap -->
<script src=\"{{ asset('dashboard') }}/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js\"></script>
<script src=\"{{ asset('dashboard') }}/plugins/jvectormap/jquery-jvectormap-world-mill-en.js\"></script>
<!-- jQuery Knob Chart -->
<script src=\"{{ asset('dashboard') }}/plugins/knob/jquery.knob.js\"></script>
<!-- daterangepicker -->
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js\"></script>
<script src=\"{{ asset('dashboard') }}/plugins/daterangepicker/daterangepicker.js\"></script>
<!-- datepicker -->
<script src=\"{{ asset('dashboard') }}/plugins/datepicker/bootstrap-datepicker.js\"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src=\"{{ asset('dashboard') }}/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js\"></script>
<!-- Slimscroll -->
<script src=\"{{ asset('dashboard') }}/plugins/slimScroll/jquery.slimscroll.min.js\"></script>
<!-- FastClick -->
<script src=\"{{ asset('dashboard') }}/plugins/fastclick/fastclick.js\"></script>
<!-- AdminLTE App -->
<script src=\"{{ asset('dashboard') }}/dist/js/adminlte.js\"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src=\"{{ asset('dashboard') }}/dist/js/pages/dashboard.js\"></script>
<!-- AdminLTE for demo purposes -->
<script src=\"{{ asset('dashboard') }}/dist/js/demo.js\"></script>


{% block js %}{% endblock %}
<script>
    \$(\"button[type=submit]\").on('click',function () {
        \$(\"button[type=submit]\").attr(\"disabled\",\"disabled\");
    });
</script>
</body>
</html>
", "dashboard/layouts/base.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/layouts/base.html.twig");
    }
}
