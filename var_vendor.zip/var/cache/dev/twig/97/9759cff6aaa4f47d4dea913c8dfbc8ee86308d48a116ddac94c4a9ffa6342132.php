<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/products/create.html.twig */
class __TwigTemplate_9844f938d70c6aada1141d116523df5147c1199a88cfb37e5abf3605bcf718e8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/products/create.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/products/create.html.twig"));

        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/products/create.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">اضف منتج</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\">المنتجات</a></li>
                        <li class=\"breadcrumb-item active\">اضف</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card card-primary card-outline\">
                        <div class=\"card-body\">
                            <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
                                <div style=\"margin-bottom: 10px\">
                                    <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                    <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
";
        // line 34
        echo "                                    <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
";
        // line 36
        echo "                                </div>
                                ";
        // line 37
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 37, $this->source); })()), 'errors');
        echo "
                                ";
        // line 38
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 38, $this->source); })()), "_token", [], "any", false, false, false, 38), 'row');
        echo "
                                <ul class=\"nav nav-tabs\" id=\"custom-content-below-tab\" role=\"tablist\">
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link active\" id=\"custom-content-below-info-tab\" data-toggle=\"pill\" href=\"#custom-content-below-info\" role=\"tab\" aria-controls=\"custom-content-below-home\" aria-selected=\"true\"><i class=\"fa fa-info\"></i> معلومات المنتج </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-department-tab\" data-toggle=\"pill\" href=\"#custom-content-below-department\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-list\"></i> القسم </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-settings-tab\" data-toggle=\"pill\" href=\"#custom-content-below-settings\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-gears\"></i> اعدادات المنتج </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-content-tab\" data-toggle=\"pill\" href=\"#custom-content-below-content\" role=\"tab\" aria-controls=\"custom-content-below-messages\" aria-selected=\"false\"><i class=\"fa fa-question\"></i> سبب الرفض </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-sizes-tab\" data-toggle=\"pill\" href=\"#custom-content-below-sizes\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-truck\"></i> معلومات الشحن </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-other-tab\" data-toggle=\"pill\" href=\"#custom-content-below-other\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-cart-plus\"></i> معلومات اضافية </a>
                                    </li>
                                </ul>
                                <div class=\"tab-content\" id=\"custom-content-below-tabContent\">
                                <div class=\"tab-pane fade active show\" id=\"custom-content-below-info\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-info-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات المنتج</h3>
                                        <div class=\"form-group\">
                                            ";
        // line 64
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 64, $this->source); })()), "title", [], "any", false, false, false, 64), 'label');
        echo "
                                            ";
        // line 65
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 65, $this->source); })()), "title", [], "any", false, false, false, 65), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 66
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 66, $this->source); })()), "title", [], "any", false, false, false, 66), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"form-group\" >
                                            ";
        // line 69
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 69, $this->source); })()), "content", [], "any", false, false, false, 69), 'label');
        echo "
                                            ";
        // line 70
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 70, $this->source); })()), "content", [], "any", false, false, false, 70), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 71
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 71, $this->source); })()), "content", [], "any", false, false, false, 71), 'errors');
        echo "</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade show\" id=\"custom-content-below-department\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-department-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>القسم</h3>
                                        <div class=\"form-group\">
                                            <input id=\"department_form_department\" type=\"hidden\" name=\"department_id\" value=\"\">
";
        // line 81
        echo "                                            <div id=\"jstree_demo_div\"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-settings\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-settings-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>اعدادات المنتج</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 90
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 90, $this->source); })()), "price", [], "any", false, false, false, 90), 'label');
        echo "
                                                ";
        // line 91
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 91, $this->source); })()), "price", [], "any", false, false, false, 91), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 92
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 92, $this->source); })()), "price", [], "any", false, false, false, 92), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 95
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 95, $this->source); })()), "stock", [], "any", false, false, false, 95), 'label');
        echo "
                                                ";
        // line 96
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 96, $this->source); })()), "stock", [], "any", false, false, false, 96), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 97
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 97, $this->source); })()), "stock", [], "any", false, false, false, 97), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 100
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 100, $this->source); })()), "start_at", [], "any", false, false, false, 100), 'label');
        echo "
                                                ";
        // line 101
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 101, $this->source); })()), "start_at", [], "any", false, false, false, 101), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 102
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 102, $this->source); })()), "start_at", [], "any", false, false, false, 102), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 105
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 105, $this->source); })()), "end_at", [], "any", false, false, false, 105), 'label');
        echo "
                                                ";
        // line 106
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 106, $this->source); })()), "end_at", [], "any", false, false, false, 106), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 107
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 107, $this->source); })()), "end_at", [], "any", false, false, false, 107), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                        <div class=\"form-group\">
                                            ";
        // line 111
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 111, $this->source); })()), "price_offer", [], "any", false, false, false, 111), 'label');
        echo "
                                            ";
        // line 112
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 112, $this->source); })()), "price_offer", [], "any", false, false, false, 112), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 113
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 113, $this->source); })()), "price_offer", [], "any", false, false, false, 113), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 117
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 117, $this->source); })()), "start_offer_at", [], "any", false, false, false, 117), 'label');
        echo "
                                                ";
        // line 118
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 118, $this->source); })()), "start_offer_at", [], "any", false, false, false, 118), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 119
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 119, $this->source); })()), "start_offer_at", [], "any", false, false, false, 119), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 122
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 122, $this->source); })()), "end_offer_at", [], "any", false, false, false, 122), 'label');
        echo "
                                                ";
        // line 123
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 123, $this->source); })()), "end_offer_at", [], "any", false, false, false, 123), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 124
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 124, $this->source); })()), "end_offer_at", [], "any", false, false, false, 124), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-content\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-content-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>سبب الرفض والحالة</h3>
                                        <div class=\"form-group\">
                                            ";
        // line 133
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 133, $this->source); })()), "status", [], "any", false, false, false, 133), 'label');
        echo "
                                            ";
        // line 134
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 134, $this->source); })()), "status", [], "any", false, false, false, 134), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 135
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 135, $this->source); })()), "status", [], "any", false, false, false, 135), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"form-group\">
                                            ";
        // line 138
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 138, $this->source); })()), "reason", [], "any", false, false, false, 138), 'label');
        echo "
                                            ";
        // line 139
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 139, $this->source); })()), "reason", [], "any", false, false, false, 139), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 140
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 140, $this->source); })()), "reason", [], "any", false, false, false, 140), 'errors');
        echo "</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-sizes\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-sizes-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>الوزن والحجم</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 149
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 149, $this->source); })()), "weight_string", [], "any", false, false, false, 149), 'label');
        echo "
                                                ";
        // line 150
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 150, $this->source); })()), "weight_string", [], "any", false, false, false, 150), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 151
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 151, $this->source); })()), "weight_string", [], "any", false, false, false, 151), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 154
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 154, $this->source); })()), "weight", [], "any", false, false, false, 154), 'label');
        echo "
                                                ";
        // line 155
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 155, $this->source); })()), "weight", [], "any", false, false, false, 155), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 156
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 156, $this->source); })()), "weight", [], "any", false, false, false, 156), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 159
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 159, $this->source); })()), "Size", [], "any", false, false, false, 159), 'label');
        echo "
                                                ";
        // line 160
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 160, $this->source); })()), "Size", [], "any", false, false, false, 160), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 161
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 161, $this->source); })()), "Size", [], "any", false, false, false, 161), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 164
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 164, $this->source); })()), "size_string", [], "any", false, false, false, 164), 'label');
        echo "
                                                ";
        // line 165
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 165, $this->source); })()), "size_string", [], "any", false, false, false, 165), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 166
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 166, $this->source); })()), "size_string", [], "any", false, false, false, 166), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 169
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 169, $this->source); })()), "Country", [], "any", false, false, false, 169), 'label');
        echo "
                                                ";
        // line 170
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 170, $this->source); })()), "Country", [], "any", false, false, false, 170), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 171
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 171, $this->source); })()), "Country", [], "any", false, false, false, 171), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 174
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 174, $this->source); })()), "ManuFact", [], "any", false, false, false, 174), 'label');
        echo "
                                                ";
        // line 175
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 175, $this->source); })()), "ManuFact", [], "any", false, false, false, 175), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 176
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 176, $this->source); })()), "ManuFact", [], "any", false, false, false, 176), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-12 col-lg-12 col-sm-12 col-sm-12\">
                                                ";
        // line 179
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 179, $this->source); })()), "Color", [], "any", false, false, false, 179), 'label');
        echo "
                                                ";
        // line 180
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 180, $this->source); })()), "Color", [], "any", false, false, false, 180), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 181
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 181, $this->source); })()), "Color", [], "any", false, false, false, 181), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-other\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-other-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات اضافية</h3>
                                        ";
        // line 189
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 189, $this->source); })()), "photo", [], "any", false, false, false, 189), 'label');
        echo "
                                        ";
        // line 190
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 190, $this->source); })()), "photo", [], "any", false, false, false, 190), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 191
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 191, $this->source); })()), "photo", [], "any", false, false, false, 191), 'errors');
        echo "</div>
                                        ";
        // line 192
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 192, $this->source); })()), "Trademark", [], "any", false, false, false, 192), 'label');
        echo "
                                        ";
        // line 193
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 193, $this->source); })()), "Trademark", [], "any", false, false, false, 193), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 194
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 194, $this->source); })()), "Trademark", [], "any", false, false, false, 194), 'errors');
        echo "</div>
                                        ";
        // line 195
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 195, $this->source); })()), "other_data", [], "any", false, false, false, 195), 'label');
        echo "
                                        ";
        // line 196
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 196, $this->source); })()), "other_data", [], "any", false, false, false, 196), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 197
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 197, $this->source); })()), "other_data", [], "any", false, false, false, 197), 'errors');
        echo "</div>
                                    </div>
                                </div>
                            </div>
                                <div style=\"margin-bottom: 5px;margin-top: 10px\">
                                    <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                    <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
";
        // line 205
        echo "                                    <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
";
        // line 207
        echo "                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 221
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        // line 222
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/themes/default/style.min.css\" />
    <link rel=\"stylesheet\" href=\"";
        // line 223
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2.min.css\">
    <link rel=\"stylesheet\" href=\"";
        // line 224
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2-bootstrap4.min.css\">
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 228
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 229
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/jstree.min.js\"></script>
    <script src=\"";
        // line 230
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2.full.min.js\"></script>
    <script src=\"https://cdn.ckeditor.com/4.14.0/standard-all/ckeditor.js\"></script>
    ";
        // line 233
        echo "
    <script type=\"text/javascript\">

        \$(function () { \$('#jstree_demo_div').jstree({ 'core' : {
                'data' : ";
        // line 237
        echo (isset($context["departments"]) || array_key_exists("departments", $context) ? $context["departments"] : (function () { throw new RuntimeError('Variable "departments" does not exist.', 237, $this->source); })());
        echo "
            } }); });

        \$('#jstree_demo_div').on(\"changed.jstree\", function (e, data) {
            \$('#department_form_department').val(data.selected);

            \$.ajax({
                'method': 'POST',
                'url' : '";
        // line 245
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.specific.size");
        echo "',
                'type' : 'json',
                'data' : {id:data.selected},
                success : function (data_ajax) {
                    \$('#product_form_Size').html('');
                    \$.each(data_ajax, function( index, size ) {
                        \$('#product_form_Size').append(`<option value=\"\${size.id}\">\${size.name}</option>`);
                    });
                },
                beforeSend: function(){
                    \$('.card-footer button').attr('disabled' ,'disabled');
                },
                complete: function(){
                    \$('.card-footer button').removeAttr('disabled' ,'disabled');
                },
            });
        });

        \$(document).ready(function() {
            \$('.select2').select2();
            CKEDITOR.replace('product_form[content]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });

            CKEDITOR.replace('product_form[other_data]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });
        });
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "dashboard/products/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  573 => 245,  562 => 237,  556 => 233,  551 => 230,  546 => 229,  536 => 228,  524 => 224,  520 => 223,  515 => 222,  505 => 221,  483 => 207,  478 => 205,  468 => 197,  464 => 196,  460 => 195,  456 => 194,  452 => 193,  448 => 192,  444 => 191,  440 => 190,  436 => 189,  425 => 181,  421 => 180,  417 => 179,  411 => 176,  407 => 175,  403 => 174,  397 => 171,  393 => 170,  389 => 169,  383 => 166,  379 => 165,  375 => 164,  369 => 161,  365 => 160,  361 => 159,  355 => 156,  351 => 155,  347 => 154,  341 => 151,  337 => 150,  333 => 149,  321 => 140,  317 => 139,  313 => 138,  307 => 135,  303 => 134,  299 => 133,  287 => 124,  283 => 123,  279 => 122,  273 => 119,  269 => 118,  265 => 117,  258 => 113,  254 => 112,  250 => 111,  243 => 107,  239 => 106,  235 => 105,  229 => 102,  225 => 101,  221 => 100,  215 => 97,  211 => 96,  207 => 95,  201 => 92,  197 => 91,  193 => 90,  182 => 81,  170 => 71,  166 => 70,  162 => 69,  156 => 66,  152 => 65,  148 => 64,  119 => 38,  115 => 37,  112 => 36,  107 => 34,  84 => 13,  80 => 12,  70 => 4,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'dashboard/layouts/base.html.twig' %}

{% block content %}
    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">اضف منتج</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"{{ path('dashboard.index') }}\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"{{ path('dashboard.products.index') }}\">المنتجات</a></li>
                        <li class=\"breadcrumb-item active\">اضف</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card card-primary card-outline\">
                        <div class=\"card-body\">
                            <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
                                <div style=\"margin-bottom: 10px\">
                                    <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                    <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
{#                                    <a href=\"\" class=\"btn btn-primary\"> نسخ المنتج <i class=\"fa fa-copy\"></i></a>#}
                                    <a href=\"{{ path('dashboard.products.index') }}\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
{#                                    <a href=\"\" class=\"btn btn-danger\"> حذف <i class=\"fa fa-trash\"></i></a>#}
                                </div>
                                {{ form_errors(form) }}
                                {{ form_row(form._token) }}
                                <ul class=\"nav nav-tabs\" id=\"custom-content-below-tab\" role=\"tablist\">
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link active\" id=\"custom-content-below-info-tab\" data-toggle=\"pill\" href=\"#custom-content-below-info\" role=\"tab\" aria-controls=\"custom-content-below-home\" aria-selected=\"true\"><i class=\"fa fa-info\"></i> معلومات المنتج </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-department-tab\" data-toggle=\"pill\" href=\"#custom-content-below-department\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-list\"></i> القسم </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-settings-tab\" data-toggle=\"pill\" href=\"#custom-content-below-settings\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-gears\"></i> اعدادات المنتج </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-content-tab\" data-toggle=\"pill\" href=\"#custom-content-below-content\" role=\"tab\" aria-controls=\"custom-content-below-messages\" aria-selected=\"false\"><i class=\"fa fa-question\"></i> سبب الرفض </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-sizes-tab\" data-toggle=\"pill\" href=\"#custom-content-below-sizes\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-truck\"></i> معلومات الشحن </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-other-tab\" data-toggle=\"pill\" href=\"#custom-content-below-other\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-cart-plus\"></i> معلومات اضافية </a>
                                    </li>
                                </ul>
                                <div class=\"tab-content\" id=\"custom-content-below-tabContent\">
                                <div class=\"tab-pane fade active show\" id=\"custom-content-below-info\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-info-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات المنتج</h3>
                                        <div class=\"form-group\">
                                            {{ form_label(form.title) }}
                                            {{ form_widget(form.title) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.title) }}</div>
                                        </div>
                                        <div class=\"form-group\" >
                                            {{ form_label(form.content) }}
                                            {{ form_widget(form.content) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.content) }}</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade show\" id=\"custom-content-below-department\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-department-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>القسم</h3>
                                        <div class=\"form-group\">
                                            <input id=\"department_form_department\" type=\"hidden\" name=\"department_id\" value=\"\">
{#                                            <label for=\"\">اختر القسم</label>#}
                                            <div id=\"jstree_demo_div\"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-settings\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-settings-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>اعدادات المنتج</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.price) }}
                                                {{ form_widget(form.price) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.price) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.stock) }}
                                                {{ form_widget(form.stock) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.stock) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.start_at) }}
                                                {{ form_widget(form.start_at) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.start_at) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.end_at) }}
                                                {{ form_widget(form.end_at) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.end_at) }}</div>
                                            </div>
                                        </div>
                                        <div class=\"form-group\">
                                            {{ form_label(form.price_offer) }}
                                            {{ form_widget(form.price_offer) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.price_offer) }}</div>
                                        </div>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                {{ form_label(form.start_offer_at) }}
                                                {{ form_widget(form.start_offer_at) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.start_offer_at) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                {{ form_label(form.end_offer_at) }}
                                                {{ form_widget(form.end_offer_at) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.end_offer_at) }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-content\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-content-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>سبب الرفض والحالة</h3>
                                        <div class=\"form-group\">
                                            {{ form_label(form.status) }}
                                            {{ form_widget(form.status) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.status) }}</div>
                                        </div>
                                        <div class=\"form-group\">
                                            {{ form_label(form.reason) }}
                                            {{ form_widget(form.reason) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.reason) }}</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-sizes\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-sizes-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>الوزن والحجم</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.weight_string) }}
                                                {{ form_widget(form.weight_string) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.weight_string) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.weight) }}
                                                {{ form_widget(form.weight) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.weight) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.Size) }}
                                                {{ form_widget(form.Size) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.Size) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.size_string) }}
                                                {{ form_widget(form.size_string) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.size_string) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                {{ form_label(form.Country) }}
                                                {{ form_widget(form.Country) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.Country) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                {{ form_label(form.ManuFact) }}
                                                {{ form_widget(form.ManuFact) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.ManuFact) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-12 col-lg-12 col-sm-12 col-sm-12\">
                                                {{ form_label(form.Color) }}
                                                {{ form_widget(form.Color) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.Color) }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-other\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-other-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات اضافية</h3>
                                        {{ form_label(form.photo) }}
                                        {{ form_widget(form.photo) }}
                                        <div style=\"color: red\" class=\"errors\">{{ form_errors(form.photo) }}</div>
                                        {{ form_label(form.Trademark) }}
                                        {{ form_widget(form.Trademark) }}
                                        <div style=\"color: red\" class=\"errors\">{{ form_errors(form.Trademark) }}</div>
                                        {{ form_label(form.other_data) }}
                                        {{ form_widget(form.other_data) }}
                                        <div style=\"color: red\" class=\"errors\">{{ form_errors(form.other_data) }}</div>
                                    </div>
                                </div>
                            </div>
                                <div style=\"margin-bottom: 5px;margin-top: 10px\">
                                    <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                    <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
{#                                    <a href=\"\" class=\"btn btn-primary\"> نسخ المنتج <i class=\"fa fa-copy\"></i></a>#}
                                    <a href=\"{{ path('dashboard.products.index') }}\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
{#                                    <a href=\"\" class=\"btn btn-danger\"> حذف <i class=\"fa fa-trash\"></i></a>#}
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


{% endblock %}

{% block css %}
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/dist/themes/default/style.min.css\" />
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/select2/select2.min.css\">
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/select2/select2-bootstrap4.min.css\">
{#    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css\">#}
{% endblock %}

{% block js %}
    <script src=\"{{ asset('dashboard') }}/dist/jstree.min.js\"></script>
    <script src=\"{{ asset('dashboard') }}/plugins/select2/select2.full.min.js\"></script>
    <script src=\"https://cdn.ckeditor.com/4.14.0/standard-all/ckeditor.js\"></script>
    {#    <script src=\"{{ asset('dashboard') }}/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js\"></script>#}

    <script type=\"text/javascript\">

        \$(function () { \$('#jstree_demo_div').jstree({ 'core' : {
                'data' : {{ departments | raw }}
            } }); });

        \$('#jstree_demo_div').on(\"changed.jstree\", function (e, data) {
            \$('#department_form_department').val(data.selected);

            \$.ajax({
                'method': 'POST',
                'url' : '{{ path('dashboard.products.specific.size') }}',
                'type' : 'json',
                'data' : {id:data.selected},
                success : function (data_ajax) {
                    \$('#product_form_Size').html('');
                    \$.each(data_ajax, function( index, size ) {
                        \$('#product_form_Size').append(`<option value=\"\${size.id}\">\${size.name}</option>`);
                    });
                },
                beforeSend: function(){
                    \$('.card-footer button').attr('disabled' ,'disabled');
                },
                complete: function(){
                    \$('.card-footer button').removeAttr('disabled' ,'disabled');
                },
            });
        });

        \$(document).ready(function() {
            \$('.select2').select2();
            CKEDITOR.replace('product_form[content]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });

            CKEDITOR.replace('product_form[other_data]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });
        });
    </script>
{% endblock %}", "dashboard/products/create.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/products/create.html.twig");
    }
}
