<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* front/layouts/base.html.twig */
class __TwigTemplate_796c344fb7588f205a382a13f042964f77ae7e0799291d1ae81498dea27b37a3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/layouts/base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"zxx\">
<head>
    <title>متجر السينيور | الرئيسية</title>
    <meta charset=\"UTF-8\">
    <meta name=\"description\" content=\" Divisima | eCommerce Template\">
    <meta name=\"keywords\" content=\"divisima, eCommerce, creative, html\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <!-- Favicon -->
    <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/img/favicon.ico\" rel=\"shortcut icon\"/>

    <!-- Google Font -->
    <link href=\"https://fonts.googleapis.com/css?family=Josefin+Sans:300,300i,400,400i,700,700i\" rel=\"stylesheet\">


    <!-- Stylesheets -->
    <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/css/bootstrap.min.css\"/>
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-rtl/3.4.0/css/bootstrap-rtl.min.css\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/css/font-awesome.min.css\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/css/flaticon.css\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/css/slicknav.min.css\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/css/jquery-ui.min.css\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/css/owl.carousel.min.css\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/css/animate.css\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/css/style.css\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/css/style-rtl.css\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/app.css"), "html", null, true);
        echo "\"/>

    <link href=\"https://fonts.googleapis.com/css?family=Cairo:400,700\" rel=\"stylesheet\">
    <style>
        body, h1, h2, h3, h4, h5, h6 {
            font-family: 'Cairo', sans-serif !important;
        }
    </style>

    <!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->

</head>
<body>
<div id=\"abdelrahman\">
    <!-- Page Preloder -->
";
        // line 48
        echo "
    <!-- Header section -->
    <header class=\"header-section\">
        <div class=\"header-top\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-lg-2 text-center text-lg-left\">
                        <!-- logo -->
                        <router-link tag=\"a\" to=\"/\" class=\"site-logo\">
                            <img src=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("uploads/settings/" . twig_get_attribute($this->env, $this->source, ($context["config"] ?? null), "site_logo", [], "any", false, false, false, 57))), "html", null, true);
        echo "\" alt=\"\">
                        </router-link>
                    </div>
                    <div class=\"col-xl-6 col-lg-5\">
                        <form class=\"header-search-form\">
                            <input type=\"text\" placeholder=\"ابحث عن اي شيء في الموقع ...\">
                            <button><i class=\"flaticon-search\"></i></button>
                        </form>
                    </div>
                    <div class=\"col-xl-4 col-lg-5\">
                        <div class=\"user-panel\">
                            ";
        // line 68
        if (twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 68)) {
            // line 69
            echo "                                <div class=\"up-item\">
                                    <i class=\"flaticon-profile\"></i>
                                    <a class=\"disabled\">";
            // line 71
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 71), "name", [], "any", false, false, false, 71), "html", null, true);
            echo "</a>
                                </div>
                            ";
        } else {
            // line 74
            echo "                                <div class=\"up-item\">
                                    <i class=\"flaticon-profile\"></i>
                                    <a href=\"#\" data-toggle=\"modal\" data-target=\"#exampleModal\">تسجيل الدخول</a> او <a href=\"#\" data-toggle=\"modal\" data-target=\"#registerModal\">تسجيل جديد</a>
                                </div>
                            ";
        }
        // line 79
        echo "                            <div class=\"up-item\">
                                ";
        // line 80
        if (twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 80)) {
            // line 81
            echo "                                        <div class=\"shopping-card\">
";
            // line 83
            echo "                                            <i class=\"flaticon-bag\"></i>
                                        </div>
                                        <router-link to=\"/cart\">عربة التسوق</router-link>
                                ";
        } else {
            // line 87
            echo "                                    <div class=\"shopping-card\">
                                        <span>0</span>
                                        <i class=\"flaticon-bag\"></i>
                                    </div>
                                    <a href=\"#\" data-toggle=\"modal\" data-target=\"#exampleModal\">عربة التسوق</a>
                                ";
        }
        // line 93
        echo "                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav class=\"main-navbar\">
            <div class=\"container\">
                <!-- menu -->
                <ul class=\"main-menu\" style=\"text-align: right;\">
                    <li><router-link tag=\"a\" to=\"/\">الرئيسية</router-link></li>
                    ";
        // line 104
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["categories"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 105
            echo "                    <li><router-link tag=\"a\" to=\"\" style=\"font-size: 15.5px\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["category"], "name", [], "any", false, false, false, 105), "html", null, true);
            echo "</router-link>
                        <ul class=\"sub-menu\">
                            ";
            // line 107
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["category"], "departments", [], "any", false, false, false, 107));
            foreach ($context['_seq'] as $context["_key"] => $context["department"]) {
                // line 108
                echo "                                <li><router-link tag=\"a\" to=\"/category/";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["department"], "id", [], "any", false, false, false, 108), "html", null, true);
                echo "/";
                echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["department"], "name", [], "any", false, false, false, 108), [" " => "-"]), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["department"], "name", [], "any", false, false, false, 108), "html", null, true);
                echo "</router-link></li>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['department'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 110
            echo "                        </ul>
                    </li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 113
        echo "                    ";
        if ((twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 113) && 1 === twig_compare(twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 113), "orders", [], "any", false, false, false, 113)), 0))) {
            // line 114
            echo "                        <li><router-link tag=\"a\" to=\"/orders\">طلباتي</router-link></li>
                    ";
        } else {
            // line 116
            echo "                        <li><a href=\"#\" onclick=\"alert('لا يوجد لديك طلبات')\">طلباتي</a></li>
                    ";
        }
        // line 118
        echo "                </ul>
            </div>
        </nav>
    </header>
    <!-- Header section end -->
    ";
        // line 123
        $this->displayBlock('content', $context, $blocks);
        // line 124
        echo "
    <router-view></router-view>
    <vue-progress-bar></vue-progress-bar>
    <!-- Footer section -->
    <section class=\"footer-section\">
        <div class=\"container\">
            <div class=\"footer-logo text-center\">
                <router-link tag=\"a\" to=\"/\"><img src=\"";
        // line 131
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("uploads/settings/" . twig_get_attribute($this->env, $this->source, ($context["config"] ?? null), "site_logo", [], "any", false, false, false, 131))), "html", null, true);
        echo "\" style=\"width:162px; height:31px;\" alt=\"\"></router-link>
            </div>
            <div class=\"row\" style=\"text-align: right\">
                <div class=\"col-lg-3 col-sm-6\">
                    <div class=\"footer-widget about-widget\">
                        <h2>من نحن</h2>
                        <p>";
        // line 137
        echo twig_get_attribute($this->env, $this->source, ($context["config"] ?? null), "site_description", [], "any", false, false, false, 137);
        echo "</p>
                        <img src=\"";
        // line 138
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/img/cards.png\" alt=\"\">
                    </div>
                </div>
                <div class=\"col-lg-3 col-sm-6\">
                    <div class=\"footer-widget about-widget\">
                        <h2>اسئلة</h2>
                        <ul>
                            <li><a href=\"\">الشركاء</a></li>
                            <li><a href=\"\">المسوقين</a></li>
                            <li><a href=\"\">الدعم الفني</a></li>
                            <li><a href=\"\">الشروط والاحكام</a></li>
                        </ul>
                        <ul>
                            <li><a href=\"\">من نحن</a></li>
                            <li><a href=\"\">الطلبات</a></li>
                            <li><a href=\"\">مسترجع</a></li>
                            <li><a href=\"\">التسوق</a></li>
                            <li><a href=\"\">المدونة</a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-lg-3 col-sm-6\">
                    <div class=\"footer-widget about-widget\">
                        <h2>صفحات مهمة</h2>
                        <div class=\"fw-latest-post-widget\">
                            <div class=\"lp-item\">
                                <div class=\"lp-content\">
                                    <h6>كيف اطلب المنتجات</h6>
                                    <span>Oct 21, 2018</span>
                                    <a href=\"#\" class=\"readmore\">اقرأ المزيد</a>
                                </div>
                            </div>
                            <div class=\"lp-item\">
                                <div class=\"lp-content\">
                                    <h6>الدعم الفني</h6>
                                    <span>Oct 21, 2018</span>
                                    <a href=\"#\" class=\"readmore\">اقرا المزيد</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-lg-3 col-sm-6\">
                    <div class=\"footer-widget contact-widget\">
                        <h2>معلومات التواصل</h2>
                        <div class=\"con-info\">
                            <span>S.</span>
                            <p>";
        // line 185
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["config"] ?? null), "site_name", [], "any", false, false, false, 185), "html", null, true);
        echo "</p>
                        </div>
                        <div class=\"con-info\">
                            <span>A.</span>
                            <p>";
        // line 189
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["config"] ?? null), "address", [], "any", false, false, false, 189), "html", null, true);
        echo "</p>
                        </div>
                        <div class=\"con-info\">
                            <span>P.</span>
                            <p>";
        // line 193
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["config"] ?? null), "phone", [], "any", false, false, false, 193), "html", null, true);
        echo "</p>
                        </div>
                        <div class=\"con-info\">
                            <span>E.</span>
                            <p>";
        // line 197
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["config"] ?? null), "email", [], "any", false, false, false, 197), "html", null, true);
        echo "</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"social-links-warp\">
            <div class=\"container\">
                <div class=\"social-links\">
                    <a href=\"#\" class=\"instagram\"><i class=\"fa fa-instagram\"></i><span>instagram</span></a>
                    <a href=\"#\" class=\"google-plus\"><i class=\"fa fa-google-plus\"></i><span>g+plus</span></a>
                    <a href=\"#\" class=\"pinterest\"><i class=\"fa fa-pinterest\"></i><span>pinterest</span></a>
                    <a href=\"#\" class=\"facebook\"><i class=\"fa fa-facebook\"></i><span>facebook</span></a>
                    <a href=\"#\" class=\"twitter\"><i class=\"fa fa-twitter\"></i><span>twitter</span></a>
                    <a href=\"#\" class=\"youtube\"><i class=\"fa fa-youtube\"></i><span>youtube</span></a>
                    <a href=\"#\" class=\"tumblr\"><i class=\"fa fa-tumblr-square\"></i><span>tumblr</span></a>
                </div>

";
        // line 217
        echo "            </div>
        </div>
    </section>
    <!-- Footer section end -->


    <!-- Modal -->
    <div class=\"modal fade\" id=\"exampleModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\" id=\"exampleModalLabel\">تسجيل الدخول</h5>
                </div>
                <div class=\"modal-body\" style=\"text-align: right\">
                    <form id=\"loginForm\" action=\"#\" method=\"post\">

                        <div class=\"form-group\">
                            <label for=\"\">البريد الالكتروني</label>
                            <input id=\"username\" class=\"form-control\" type=\"text\" name=\"email\" placeholder=\"البريد الالكتروني\">
                        </div>
                        <div class=\"form-group\">
                            <label for=\"\">كلمة المرور</label>
                            <input id=\"password\" class=\"form-control\" type=\"password\" name=\"password\" placeholder=\"كلمة المرور\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" id=\"loginSubmitButton\" class=\"btn btn-primary\">دخول</button>
                    <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">اغلاق</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Register -->
    <!-- Modal -->
    <div class=\"modal fade\" id=\"registerModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"registerModalLabel\" aria-hidden=\"true\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\" id=\"registerModalLabel\">تسجيل جديد</h5>
                </div>
                <div class=\"modal-body\" style=\"text-align: right\">
                    <form id=\"registerForm\" action=\"#\" method=\"post\">

                        <div class=\"form-group\">
                            <label for=\"\">الاسم الاول</label>
                            <input id=\"firstname\" class=\"form-control\" type=\"text\" name=\"name\" placeholder=\"الاسم الاول فقط\">
                        </div>
                        <div class=\"form-group\">
                            <label for=\"\">البريد الالكتروني</label>
                            <input id=\"email\" class=\"form-control\" type=\"email\" name=\"email\" placeholder=\"البريد الالكتروني\">
                        </div>
                        <div class=\"form-group\">
                            <label for=\"\">رقم الهاتف</label>
                            <input id=\"phone\" class=\"form-control\" type=\"text\" name=\"phone\" placeholder=\"رقم الهاتف يجب ان يكون صحيح\">
                        </div>
                        <div class=\"form-group\">
                            <label for=\"\">كلمة المرور</label>
                            <input id=\"pass\" class=\"form-control\" type=\"password\" name=\"password\" placeholder=\"كلمة المرور\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" id=\"registerSubmitButton\" class=\"btn btn-primary\">دخول</button>
                    <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">اغلاق</button>
                </div>
            </div>
        </div>
    </div>
</div>



<!--====== Javascripts & Jquery ======-->
<script src=\"";
        // line 292
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/js/jquery-3.2.1.min.js\"></script>
<script src=\"";
        // line 293
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/js/bootstrap.min.js\"></script>
<script src=\"";
        // line 294
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/js/jquery.slicknav.min.js\"></script>
<script src=\"";
        // line 295
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/js/owl.carousel.min.js\"></script>
<script src=\"";
        // line 296
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/js/jquery.nicescroll.min.js\"></script>
<script src=\"";
        // line 297
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/js/jquery.zoom.min.js\"></script>
<script src=\"";
        // line 298
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front"), "html", null, true);
        echo "/js/jquery-ui.min.js\"></script>
<script src=\"";
        // line 299
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/app.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 300
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/runtime.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 301
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/vendors~app.js"), "html", null, true);
        echo "\"></script>
";
        // line 303
        echo "
<script>
    \$(\"#loginSubmitButton\").on('click',function (e) {
        e.preventDefault();
        let username = \$('#username').val();
        let password = \$('#password').val();

        \$.ajax({
            url : '";
        // line 311
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("front.login");
        echo "',
            method: 'POST',
            type: 'JSON',
            data: {
                email:username,
                password:password
            },
            success: function () {
                window.location.reload();
            },
            error: function (jqXHR) {
                \$('#loginForm .err').remove();
                \$('#loginForm').prepend(`<div class=\"alert alert-danger err\">\${jqXHR.responseJSON.error}</div>`);
            }
        });
    });

    \$(\"#registerSubmitButton\").on('click',function (e) {
        e.preventDefault();
        let name = \$('#firstname').val();
        let email = \$('#email').val();
        let phone = \$('#phone').val();
        let pass = \$('#pass').val();

        \$.ajax({
            url : '";
        // line 336
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("front.register");
        echo "',
            method: 'POST',
            type: 'JSON',
            data: {
                name:name,
                email:email,
                phone:phone,
                password:pass,
            },
            success: function (response) {
                if (response.status === false) {
                    \$('#registerForm .err').remove();
                    response.error.forEach(function (error) {
                        \$('#registerForm').prepend(`<div class=\"alert alert-danger err\">\${error}</div>`);
                    });
                }else{
                    \$('#registerForm').trigger(\"reset\");
                    alert('تم التسجيل بنجاح');
                    \$('#registerModal').modal('hide');
                    \$('#exampleModal').modal('show');
                }
            }
        });
    });
</script>
</body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 123
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "front/layouts/base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  558 => 123,  523 => 336,  495 => 311,  485 => 303,  481 => 301,  477 => 300,  473 => 299,  469 => 298,  465 => 297,  461 => 296,  457 => 295,  453 => 294,  449 => 293,  445 => 292,  368 => 217,  347 => 197,  340 => 193,  333 => 189,  326 => 185,  276 => 138,  272 => 137,  263 => 131,  254 => 124,  252 => 123,  245 => 118,  241 => 116,  237 => 114,  234 => 113,  226 => 110,  213 => 108,  209 => 107,  203 => 105,  199 => 104,  186 => 93,  178 => 87,  172 => 83,  169 => 81,  167 => 80,  164 => 79,  157 => 74,  151 => 71,  147 => 69,  145 => 68,  131 => 57,  120 => 48,  99 => 27,  95 => 26,  91 => 25,  87 => 24,  83 => 23,  79 => 22,  75 => 21,  71 => 20,  67 => 19,  62 => 17,  52 => 10,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "front/layouts/base.html.twig", "/opt/lampp/htdocs/ecommerce/templates/front/layouts/base.html.twig");
    }
}
