<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/dashboard/login' => [[['_route' => 'dashboard.login', '_controller' => 'App\\Controller\\Dashboard\\AdminAuthController::login'], null, null, null, false, false, null]],
        '/dashboard/logout' => [[['_route' => 'dashboard.logout', '_controller' => 'App\\Controller\\Dashboard\\AdminAuthController::logout'], null, null, null, false, false, null]],
        '/dashboard/admins/index' => [[['_route' => 'dashboard.admins.index', '_controller' => 'App\\Controller\\Dashboard\\AdminController::index'], null, null, null, false, false, null]],
        '/dashboard/admins/create' => [[['_route' => 'dashboard.admins.create', '_controller' => 'App\\Controller\\Dashboard\\AdminController::create'], null, null, null, false, false, null]],
        '/dashboard/cities/index' => [[['_route' => 'dashboard.cities.index', '_controller' => 'App\\Controller\\Dashboard\\CityController::index'], null, null, null, false, false, null]],
        '/dashboard/cities/create' => [[['_route' => 'dashboard.cities.create', '_controller' => 'App\\Controller\\Dashboard\\CityController::create'], null, null, null, false, false, null]],
        '/dashboard/colors/index' => [[['_route' => 'dashboard.colors.index', '_controller' => 'App\\Controller\\Dashboard\\ColorController::index'], null, null, null, false, false, null]],
        '/dashboard/colors/create' => [[['_route' => 'dashboard.colors.create', '_controller' => 'App\\Controller\\Dashboard\\ColorController::create'], null, null, null, false, false, null]],
        '/dashboard/countries/index' => [[['_route' => 'dashboard.countries.index', '_controller' => 'App\\Controller\\Dashboard\\CountryController::index'], null, null, null, false, false, null]],
        '/dashboard/countries/create' => [[['_route' => 'dashboard.countries.create', '_controller' => 'App\\Controller\\Dashboard\\CountryController::create'], null, null, null, false, false, null]],
        '/dashboard/departments/index' => [[['_route' => 'dashboard.departments.index', '_controller' => 'App\\Controller\\Dashboard\\DepartmentController::index'], null, null, null, false, false, null]],
        '/dashboard/departments/create' => [[['_route' => 'dashboard.departments.create', '_controller' => 'App\\Controller\\Dashboard\\DepartmentController::create'], null, null, null, false, false, null]],
        '/dashboard' => [[['_route' => 'dashboard.index', '_controller' => 'App\\Controller\\Dashboard\\HomeController::index'], null, null, null, true, false, null]],
        '/dashboard/settings' => [[['_route' => 'dashboard.settings', '_controller' => 'App\\Controller\\Dashboard\\HomeController::getSettings'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/dashboard/malls/index' => [[['_route' => 'dashboard.malls.index', '_controller' => 'App\\Controller\\Dashboard\\MallController::index'], null, null, null, false, false, null]],
        '/dashboard/malls/create' => [[['_route' => 'dashboard.malls.create', '_controller' => 'App\\Controller\\Dashboard\\MallController::create'], null, null, null, false, false, null]],
        '/dashboard/manufacts/index' => [[['_route' => 'dashboard.manufacts.index', '_controller' => 'App\\Controller\\Dashboard\\ManuFactController::index'], null, null, null, false, false, null]],
        '/dashboard/manufacts/create' => [[['_route' => 'dashboard.manufacts.create', '_controller' => 'App\\Controller\\Dashboard\\ManuFactController::create'], null, null, null, false, false, null]],
        '/dashboard/orders/index' => [[['_route' => 'dashboard.orders.index', '_controller' => 'App\\Controller\\Dashboard\\OrderController::index'], null, null, null, false, false, null]],
        '/dashboard/products/index' => [[['_route' => 'dashboard.products.index', '_controller' => 'App\\Controller\\Dashboard\\ProductController::index'], null, null, null, false, false, null]],
        '/dashboard/products/specific-state' => [[['_route' => 'dashboard.products.specific.size', '_controller' => 'App\\Controller\\Dashboard\\ProductController::specific'], null, ['POST' => 0], null, false, false, null]],
        '/dashboard/shippings/index' => [[['_route' => 'dashboard.shippings.index', '_controller' => 'App\\Controller\\Dashboard\\ShippingController::index'], null, null, null, false, false, null]],
        '/dashboard/shippings/create' => [[['_route' => 'dashboard.shippings.create', '_controller' => 'App\\Controller\\Dashboard\\ShippingController::create'], null, null, null, false, false, null]],
        '/dashboard/sizes/index' => [[['_route' => 'dashboard.sizes.index', '_controller' => 'App\\Controller\\Dashboard\\SizeController::index'], null, null, null, false, false, null]],
        '/dashboard/sizes/create' => [[['_route' => 'dashboard.sizes.create', '_controller' => 'App\\Controller\\Dashboard\\SizeController::create'], null, null, null, false, false, null]],
        '/dashboard/states/index' => [[['_route' => 'dashboard.states.index', '_controller' => 'App\\Controller\\Dashboard\\StateController::index'], null, null, null, false, false, null]],
        '/dashboard/states/create' => [[['_route' => 'dashboard.states.create', '_controller' => 'App\\Controller\\Dashboard\\StateController::create'], null, null, null, false, false, null]],
        '/dashboard/states/specific-state' => [[['_route' => 'dashboard.states.specific.state', '_controller' => 'App\\Controller\\Dashboard\\StateController::specific'], null, ['POST' => 0], null, false, false, null]],
        '/dashboard/trademarks/index' => [[['_route' => 'dashboard.trademarks.index', '_controller' => 'App\\Controller\\Dashboard\\TrademarkController::index'], null, null, null, false, false, null]],
        '/dashboard/trademarks/create' => [[['_route' => 'dashboard.trademarks.create', '_controller' => 'App\\Controller\\Dashboard\\TrademarkController::create'], null, null, null, false, false, null]],
        '/dashboard/users/index' => [[['_route' => 'dashboard.users.index', '_controller' => 'App\\Controller\\Dashboard\\UserController::index'], null, null, null, false, false, null]],
        '/dashboard/users/create' => [[['_route' => 'dashboard.users.create', '_controller' => 'App\\Controller\\Dashboard\\UserController::create'], null, null, null, false, false, null]],
        '/dashboard/weights/index' => [[['_route' => 'dashboard.weights.index', '_controller' => 'App\\Controller\\Dashboard\\WeightController::index'], null, null, null, false, false, null]],
        '/dashboard/weights/create' => [[['_route' => 'dashboard.weights.create', '_controller' => 'App\\Controller\\Dashboard\\WeightController::create'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'front.index', '_controller' => 'App\\Controller\\Front\\FrontController::index'], null, null, null, false, false, null]],
        '/cart' => [[['_route' => 'front.cart', '_controller' => 'App\\Controller\\Front\\FrontController::cart'], null, null, null, false, false, null]],
        '/orders' => [[['_route' => 'front.orders', '_controller' => 'App\\Controller\\Front\\FrontController::orders'], null, null, null, false, false, null]],
        '/profile' => [[['_route' => 'front.profile', '_controller' => 'App\\Controller\\Front\\FrontController::profile'], null, null, null, false, false, null]],
        '/api/latest/products' => [[['_route' => 'api.latest.products', '_controller' => 'App\\Controller\\Front\\FrontController::latest_products'], null, ['POST' => 0], null, false, false, null]],
        '/api/products' => [[['_route' => 'api.products', '_controller' => 'App\\Controller\\Front\\FrontController::products'], null, ['POST' => 0], null, false, false, null]],
        '/api/own/cart' => [[['_route' => 'api.own.cart', '_controller' => 'App\\Controller\\Front\\FrontController::api_own_cart'], null, null, null, false, false, null]],
        '/api/orders' => [[['_route' => 'api.get.orders', '_controller' => 'App\\Controller\\Front\\FrontController::api_get_orders'], null, ['POST' => 0], null, false, false, null]],
        '/login' => [[['_route' => 'front.login', '_controller' => 'App\\Controller\\Front\\UserAuthController::login'], null, ['POST' => 0], null, false, false, null]],
        '/register' => [[['_route' => 'front.register', '_controller' => 'App\\Controller\\Front\\UserAuthController::register'], null, ['POST' => 0], null, false, false, null]],
        '/logout' => [[['_route' => 'front.logout', '_controller' => 'App\\Controller\\Front\\UserAuthController::logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/dashboard/(?'
                    .'|admins/(?'
                        .'|edit/([^/]++)(*:44)'
                        .'|destroy/([^/]++)(*:67)'
                    .')'
                    .'|c(?'
                        .'|ities/(?'
                            .'|edit/([^/]++)(*:101)'
                            .'|destroy/([^/]++)(*:125)'
                        .')'
                        .'|o(?'
                            .'|lors/(?'
                                .'|edit/([^/]++)(*:159)'
                                .'|destroy/([^/]++)(*:183)'
                            .')'
                            .'|untries/(?'
                                .'|edit/([^/]++)(*:216)'
                                .'|destroy/([^/]++)(*:240)'
                            .')'
                        .')'
                    .')'
                    .'|departments/(?'
                        .'|edit/([^/]++)(*:279)'
                        .'|destroy/([^/]++)(*:303)'
                    .')'
                    .'|ma(?'
                        .'|lls/(?'
                            .'|edit/([^/]++)(*:337)'
                            .'|destroy/([^/]++)(*:361)'
                        .')'
                        .'|nufacts/(?'
                            .'|edit/([^/]++)(*:394)'
                            .'|destroy/([^/]++)(*:418)'
                        .')'
                    .')'
                    .'|orders/(?'
                        .'|edit/([^/]++)(*:451)'
                        .'|destroy/([^/]++)(*:475)'
                    .')'
                    .'|products/(?'
                        .'|create(?:/([^/]++))?(*:516)'
                        .'|edit/([^/]++)(*:537)'
                        .'|destroy/([^/]++)(*:561)'
                    .')'
                    .'|s(?'
                        .'|hippings/(?'
                            .'|edit/([^/]++)(*:599)'
                            .'|destroy/([^/]++)(*:623)'
                        .')'
                        .'|izes/(?'
                            .'|edit/([^/]++)(*:653)'
                            .'|destroy/([^/]++)(*:677)'
                        .')'
                        .'|tates/(?'
                            .'|edit/([^/]++)(*:708)'
                            .'|destroy/([^/]++)(*:732)'
                        .')'
                    .')'
                    .'|trademarks/(?'
                        .'|edit/([^/]++)(*:769)'
                        .'|destroy/([^/]++)(*:793)'
                    .')'
                    .'|users/(?'
                        .'|edit/([^/]++)(*:824)'
                        .'|destroy/([^/]++)(*:848)'
                    .')'
                    .'|weights/(?'
                        .'|edit/([^/]++)(*:881)'
                        .'|destroy/([^/]++)(*:905)'
                    .')'
                .')'
                .'|/category/([^/]++)(?:/([^/]++))?(*:947)'
                .'|/product/([^/]++)(?:/([^/]++))?(*:986)'
                .'|/api/(?'
                    .'|more/(?'
                        .'|products(?:/([^/]++))?(*:1032)'
                        .'|specific/products/([^/]++)(?:/([^/]++))?(*:1081)'
                    .')'
                    .'|c(?'
                        .'|a(?'
                            .'|tegory/([^/]++)(*:1114)'
                            .'|rt/([^/]++)(*:1134)'
                        .')'
                        .'|reate/(?'
                            .'|love/([^/]++)(*:1166)'
                            .'|order/([^/]++)(*:1189)'
                        .')'
                    .')'
                    .'|product/([^/]++)(*:1216)'
                    .'|loves/([^/]++)(*:1239)'
                    .'|delete/product/([^/]++)/([^/]++)(*:1280)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        44 => [[['_route' => 'dashboard.admins.edit', '_controller' => 'App\\Controller\\Dashboard\\AdminController::edit'], ['id'], null, null, false, true, null]],
        67 => [[['_route' => 'dashboard.admins.destroy', '_controller' => 'App\\Controller\\Dashboard\\AdminController::destroy'], ['id'], null, null, false, true, null]],
        101 => [[['_route' => 'dashboard.cities.edit', '_controller' => 'App\\Controller\\Dashboard\\CityController::edit'], ['id'], null, null, false, true, null]],
        125 => [[['_route' => 'dashboard.cities.destroy', '_controller' => 'App\\Controller\\Dashboard\\CityController::destroy'], ['id'], null, null, false, true, null]],
        159 => [[['_route' => 'dashboard.colors.edit', '_controller' => 'App\\Controller\\Dashboard\\ColorController::edit'], ['id'], null, null, false, true, null]],
        183 => [[['_route' => 'dashboard.colors.destroy', '_controller' => 'App\\Controller\\Dashboard\\ColorController::destroy'], ['id'], null, null, false, true, null]],
        216 => [[['_route' => 'dashboard.countries.edit', '_controller' => 'App\\Controller\\Dashboard\\CountryController::edit'], ['id'], null, null, false, true, null]],
        240 => [[['_route' => 'dashboard.countries.destroy', '_controller' => 'App\\Controller\\Dashboard\\CountryController::destroy'], ['id'], null, null, false, true, null]],
        279 => [[['_route' => 'dashboard.departments.edit', '_controller' => 'App\\Controller\\Dashboard\\DepartmentController::edit'], ['id'], null, null, false, true, null]],
        303 => [[['_route' => 'dashboard.departments.destroy', '_controller' => 'App\\Controller\\Dashboard\\DepartmentController::destroy'], ['id'], null, null, false, true, null]],
        337 => [[['_route' => 'dashboard.malls.edit', '_controller' => 'App\\Controller\\Dashboard\\MallController::edit'], ['id'], null, null, false, true, null]],
        361 => [[['_route' => 'dashboard.malls.destroy', '_controller' => 'App\\Controller\\Dashboard\\MallController::destroy'], ['id'], null, null, false, true, null]],
        394 => [[['_route' => 'dashboard.manufacts.edit', '_controller' => 'App\\Controller\\Dashboard\\ManuFactController::edit'], ['id'], null, null, false, true, null]],
        418 => [[['_route' => 'dashboard.manufacts.destroy', '_controller' => 'App\\Controller\\Dashboard\\ManuFactController::destroy'], ['id'], null, null, false, true, null]],
        451 => [[['_route' => 'dashboard.orders.edit', '_controller' => 'App\\Controller\\Dashboard\\OrderController::edit'], ['id'], null, null, false, true, null]],
        475 => [[['_route' => 'dashboard.orders.destroy', '_controller' => 'App\\Controller\\Dashboard\\OrderController::destroy'], ['id'], null, null, false, true, null]],
        516 => [[['_route' => 'dashboard.products.create', 'copyId' => null, '_controller' => 'App\\Controller\\Dashboard\\ProductController::create'], ['copyId'], null, null, false, true, null]],
        537 => [[['_route' => 'dashboard.products.edit', '_controller' => 'App\\Controller\\Dashboard\\ProductController::edit'], ['id'], null, null, false, true, null]],
        561 => [[['_route' => 'dashboard.products.destroy', '_controller' => 'App\\Controller\\Dashboard\\ProductController::destroy'], ['id'], null, null, false, true, null]],
        599 => [[['_route' => 'dashboard.shippings.edit', '_controller' => 'App\\Controller\\Dashboard\\ShippingController::edit'], ['id'], null, null, false, true, null]],
        623 => [[['_route' => 'dashboard.shippings.destroy', '_controller' => 'App\\Controller\\Dashboard\\ShippingController::destroy'], ['id'], null, null, false, true, null]],
        653 => [[['_route' => 'dashboard.sizes.edit', '_controller' => 'App\\Controller\\Dashboard\\SizeController::edit'], ['id'], null, null, false, true, null]],
        677 => [[['_route' => 'dashboard.sizes.destroy', '_controller' => 'App\\Controller\\Dashboard\\SizeController::destroy'], ['id'], null, null, false, true, null]],
        708 => [[['_route' => 'dashboard.states.edit', '_controller' => 'App\\Controller\\Dashboard\\StateController::edit'], ['id'], null, null, false, true, null]],
        732 => [[['_route' => 'dashboard.states.destroy', '_controller' => 'App\\Controller\\Dashboard\\StateController::destroy'], ['id'], null, null, false, true, null]],
        769 => [[['_route' => 'dashboard.trademarks.edit', '_controller' => 'App\\Controller\\Dashboard\\TrademarkController::edit'], ['id'], null, null, false, true, null]],
        793 => [[['_route' => 'dashboard.trademarks.destroy', '_controller' => 'App\\Controller\\Dashboard\\TrademarkController::destroy'], ['id'], null, null, false, true, null]],
        824 => [[['_route' => 'dashboard.users.edit', '_controller' => 'App\\Controller\\Dashboard\\UserController::edit'], ['id'], null, null, false, true, null]],
        848 => [[['_route' => 'dashboard.users.destroy', '_controller' => 'App\\Controller\\Dashboard\\UserController::destroy'], ['id'], null, null, false, true, null]],
        881 => [[['_route' => 'dashboard.weights.edit', '_controller' => 'App\\Controller\\Dashboard\\WeightController::edit'], ['id'], null, null, false, true, null]],
        905 => [[['_route' => 'dashboard.weights.destroy', '_controller' => 'App\\Controller\\Dashboard\\WeightController::destroy'], ['id'], null, null, false, true, null]],
        947 => [[['_route' => 'front.category', 'title' => null, '_controller' => 'App\\Controller\\Front\\FrontController::category'], ['id', 'title'], null, null, false, true, null]],
        986 => [[['_route' => 'front.product', 'title' => null, '_controller' => 'App\\Controller\\Front\\FrontController::product'], ['id', 'title'], null, null, false, true, null]],
        1032 => [[['_route' => 'api.more.products', 'skipNumber' => null, '_controller' => 'App\\Controller\\Front\\FrontController::more_products'], ['skipNumber'], ['POST' => 0], null, false, true, null]],
        1081 => [[['_route' => 'api.more.specific.products', 'skipNumber' => null, '_controller' => 'App\\Controller\\Front\\FrontController::more_specific_products'], ['id', 'skipNumber'], ['POST' => 0], null, false, true, null]],
        1114 => [[['_route' => 'api.category', '_controller' => 'App\\Controller\\Front\\FrontController::getCategory'], ['id'], ['POST' => 0, 'GET' => 1], null, false, true, null]],
        1134 => [[['_route' => 'api.cart', '_controller' => 'App\\Controller\\Front\\FrontController::api_cart'], ['id'], null, null, false, true, null]],
        1166 => [[['_route' => 'api.create.love', '_controller' => 'App\\Controller\\Front\\FrontController::api_create_love'], ['id'], null, null, false, true, null]],
        1189 => [[['_route' => 'api.create.order', '_controller' => 'App\\Controller\\Front\\FrontController::api_create_order'], ['id'], ['POST' => 0], null, false, true, null]],
        1216 => [[['_route' => 'api.product', '_controller' => 'App\\Controller\\Front\\FrontController::api_products'], ['id'], null, null, false, true, null]],
        1239 => [[['_route' => 'api.loves', '_controller' => 'App\\Controller\\Front\\FrontController::api_loves'], ['id'], null, null, false, true, null]],
        1280 => [
            [['_route' => 'api.delete.product', '_controller' => 'App\\Controller\\Front\\FrontController::api_delete_product'], ['cartId', 'productId'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
