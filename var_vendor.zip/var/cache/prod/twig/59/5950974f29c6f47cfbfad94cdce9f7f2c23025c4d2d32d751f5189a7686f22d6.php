<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/index.html.twig */
class __TwigTemplate_7e94a0db39a6f685e2492373b8455a7205eef62d14401197b93a0c1426b5ea2a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">الرئيسية</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
";
        // line 13
        echo "                        <li class=\"breadcrumb-item active\">الرئيسية</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-12 col-sm-6 col-md-3\">
                    <div class=\"info-box\">
                        <span class=\"info-box-icon bg-info elevation-1\"><i class=\"fa fa-user\"></i></span>

                        <div class=\"info-box-content\">
                            <span class=\"info-box-text\"> الاعضاء </span>
                            <span class=\"info-box-number\">
                  10
                </span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class=\"col-12 col-sm-6 col-md-3\">
                    <div class=\"info-box mb-3\">
                        <span class=\"info-box-icon bg-danger elevation-1\"><i class=\"fa fa-tag\"></i></span>

                        <div class=\"info-box-content\">
                            <span class=\"info-box-text\">المنتجات</span>
                            <span class=\"info-box-number\">41</span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->

                <!-- fix for small devices only -->
                <div class=\"clearfix hidden-md-up\"></div>

                <div class=\"col-12 col-sm-6 col-md-3\">
                    <div class=\"info-box mb-3\">
                        <span class=\"info-box-icon bg-success elevation-1\"><i class=\"fa fa-shopping-basket\"></i></span>

                        <div class=\"info-box-content\">
                            <span class=\"info-box-text\">الطلبات</span>
                            <span class=\"info-box-number\">760</span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class=\"col-12 col-sm-6 col-md-3\">
                    <div class=\"info-box mb-3\">
                        <span class=\"info-box-icon bg-warning elevation-1\"><i class=\"fa fa-users\"></i></span>

                        <div class=\"info-box-content\">
                            <span class=\"info-box-text\">الزوار</span>
                            <span class=\"info-box-number\">10</span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
            <div class=\"row\">

                <!-- right col (We are only adding the ID to make the widgets sortable)-->
                <section class=\"col-lg-12 connectedSortable\">
                    <!-- solid sales graph -->
                    <div class=\"card bg-info-gradient\">
                        <div class=\"card-header no-border\">
                            <h3 class=\"card-title\">
                                <i class=\"fa fa-th mr-1\"></i>
                                الطلبات منذ البدء
                            </h3>

                            <div class=\"card-tools\">
                                <button type=\"button\" class=\"btn bg-info btn-sm\" data-widget=\"collapse\">
                                    <i class=\"fa fa-minus\"></i>
                                </button>
                                <button type=\"button\" class=\"btn bg-info btn-sm\" data-widget=\"remove\">
                                    <i class=\"fa fa-times\"></i>
                                </button>
                            </div>
                        </div>
                        <div class=\"card-body\">
                            <div class=\"chart\" id=\"line-chart\" style=\"height: 250px;\"></div>
                        </div>
                        <!-- /.card-body -->
                        <div class=\"card-footer bg-transparent\">
                            <div class=\"row\">
                                <div class=\"col-4 text-center\">
                                    <input type=\"text\" class=\"knob\" data-readonly=\"true\" value=\"20\" data-width=\"60\" data-height=\"60\"
                                           data-fgColor=\"#39CCCC\">

                                    <div class=\"text-white\">طلبات الشهر</div>
                                </div>
                                <!-- ./col -->
                                <div class=\"col-4 text-center\">
                                    <input type=\"text\" class=\"knob\" data-readonly=\"true\" value=\"50\" data-width=\"60\" data-height=\"60\"
                                           data-fgColor=\"#39CCCC\">

                                    <div class=\"text-white\">تسجيلات جديدة</div>
                                </div>
                                <!-- ./col -->
                                <div class=\"col-4 text-center\">
                                    <input type=\"text\" class=\"knob\" data-readonly=\"true\" value=\"30\" data-width=\"60\" data-height=\"60\"
                                           data-fgColor=\"#39CCCC\">

                                    <div class=\"text-white\">زوار يوميا</div>
                                </div>
                                <!-- ./col -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.card-footer -->
                    </div>
                    <!-- /.card -->
                </section>
                <!-- right col -->
                <!-- Left col -->
                <section class=\"col-lg-12 connectedSortable\">
                    <!-- Custom tabs (Charts with tabs)-->
                    <div class=\"card\">
                        <div class=\"card-header d-flex p-0\">
                            <h3 class=\"card-title p-3\">
                                <i class=\"fa fa-pie-chart mr-1\"></i>
                                معدل الزوار شهريا
                            </h3>
                            <ul class=\"nav nav-pills mr-auto p-2\">
                                <li class=\"nav-item\">
                                    <a class=\"nav-link active\" href=\"#revenue-chart\" data-toggle=\"tab\">اساسي</a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" href=\"#sales-chart\" data-toggle=\"tab\">نسبة</a>
                                </li>
                            </ul>
                        </div><!-- /.card-header -->
                        <div class=\"card-body\">
                            <div class=\"tab-content p-0\">
                                <!-- Morris chart - Sales -->
                                <div class=\"chart tab-pane active\" id=\"revenue-chart\"
                                     style=\"position: relative; height: 300px;\"></div>
                                <div class=\"chart tab-pane\" id=\"sales-chart\" style=\"position: relative; height: 300px;\"></div>
                            </div>
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </section>
                <!-- /.Left col -->
            </div>

            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
";
    }

    public function getTemplateName()
    {
        return "dashboard/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/index.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/index.html.twig");
    }
}
