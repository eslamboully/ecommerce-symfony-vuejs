<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/shippings/edit.html.twig */
class __TwigTemplate_ac033fc3888683626b5fbba149924bc408f2676cd89e2490b6f259eeded169ee extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/shippings/edit.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/shippings/edit.html.twig"));

        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/shippings/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">تعديل شركات الشحن</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.shippings.index");
        echo "\">شركات الشحن</a></li>
                        <li class=\"breadcrumb-item active\">تعديل</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <form role=\"form\" method=\"post\" enctype=\"multipart/form-data\">
                            ";
        // line 29
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 29, $this->source); })()), 'errors');
        echo "
                            ";
        // line 30
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 30, $this->source); })()), "_token", [], "any", false, false, false, 30), 'row');
        echo "
                            <div class=\"card-body\">
                                <div class=\"form-group\">
                                    ";
        // line 33
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 33, $this->source); })()), "name", [], "any", false, false, false, 33), 'label');
        echo "
                                    ";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 34, $this->source); })()), "name", [], "any", false, false, false, 34), 'widget');
        echo "
                                    <div style=\"color: red\" class=\"errors\">";
        // line 35
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 35, $this->source); })()), "name", [], "any", false, false, false, 35), 'errors');
        echo "</div>
                                </div>

                                <div class=\"form-group\">
                                    ";
        // line 39
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 39, $this->source); })()), "User", [], "any", false, false, false, 39), 'label');
        echo "
                                    ";
        // line 40
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 40, $this->source); })()), "User", [], "any", false, false, false, 40), 'widget');
        echo "
                                    <div style=\"color: red\" class=\"errors\">";
        // line 41
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 41, $this->source); })()), "User", [], "any", false, false, false, 41), 'errors');
        echo "</div>
                                </div>

                                <div class=\"form-group\">
                                    ";
        // line 45
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 45, $this->source); })()), "address", [], "any", false, false, false, 45), 'label');
        echo "
                                    ";
        // line 46
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 46, $this->source); })()), "address", [], "any", false, false, false, 46), 'widget');
        echo "
                                    <div style=\"color: red\" class=\"errors\">";
        // line 47
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 47, $this->source); })()), "address", [], "any", false, false, false, 47), 'errors');
        echo "</div>
                                </div>


                                <div class=\"form-group\">
                                    <div class=\"row\">
                                        <div class=\"col-md-6\">
                                            ";
        // line 54
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 54, $this->source); })()), "lng", [], "any", false, false, false, 54), 'label');
        echo "
                                            ";
        // line 55
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 55, $this->source); })()), "lng", [], "any", false, false, false, 55), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 56
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 56, $this->source); })()), "lng", [], "any", false, false, false, 56), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"col-md-6\">
                                            ";
        // line 59
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 59, $this->source); })()), "lat", [], "any", false, false, false, 59), 'label');
        echo "
                                            ";
        // line 60
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 60, $this->source); })()), "lat", [], "any", false, false, false, 60), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 61
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 61, $this->source); })()), "lat", [], "any", false, false, false, 61), 'errors');
        echo "</div>
                                        </div>
                                    </div>
                                </div>

                                <div class=\"form-group\">
                                    <div id=\"map\"></div>
                                    <pre id=\"coordinates\" class=\"coordinates\"></pre>
                                </div>

                                <div class=\"form-group\">
                                    ";
        // line 72
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 72, $this->source); })()), "icon", [], "any", false, false, false, 72), 'label');
        echo "
                                    ";
        // line 73
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 73, $this->source); })()), "icon", [], "any", false, false, false, 73), 'widget');
        echo "
                                    <div style=\"color: red\" class=\"errors\">";
        // line 74
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 74, $this->source); })()), "icon", [], "any", false, false, false, 74), 'errors');
        echo "</div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class=\"card-footer\">
                                <button type=\"submit\" class=\"btn btn-primary\">ارسال</button>
                            </div>
                        </form>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 92
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        // line 93
        echo "    <script src=\"https://api.mapbox.com/mapbox-gl-js/v1.10.1/mapbox-gl.js\"></script>
    <link href=\"https://api.mapbox.com/mapbox-gl-js/v1.10.1/mapbox-gl.css\" rel=\"stylesheet\" />
    <style>
        body { margin: 0; padding: 0; }
        #map { top: 0; bottom: 0;height: 300px; width: 100%; }
    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 101
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 102
        echo "    <script>
        mapboxgl.accessToken = 'pk.eyJ1IjoiZXNsYW1ib3VsbHkiLCJhIjoiY2thaWdncDE3MDBqMjJ6dGR4cHhzeDlkYiJ9.ZUE0a2peQttyyS3jxfiPlQ';
        var coordinates = document.getElementById('coordinates');
        var map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/streets-v11',
            center: [";
        // line 108
        ((0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["shipping"]) || array_key_exists("shipping", $context) ? $context["shipping"] : (function () { throw new RuntimeError('Variable "shipping" does not exist.', 108, $this->source); })()), "lng", [], "any", false, false, false, 108), null)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["shipping"]) || array_key_exists("shipping", $context) ? $context["shipping"] : (function () { throw new RuntimeError('Variable "shipping" does not exist.', 108, $this->source); })()), "lng", [], "any", false, false, false, 108), "html", null, true))) : (print (31.168468256781608261007932014763355255126953125)));
        echo ", ";
        ((0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["shipping"]) || array_key_exists("shipping", $context) ? $context["shipping"] : (function () { throw new RuntimeError('Variable "shipping" does not exist.', 108, $this->source); })()), "lat", [], "any", false, false, false, 108), null)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["shipping"]) || array_key_exists("shipping", $context) ? $context["shipping"] : (function () { throw new RuntimeError('Variable "shipping" does not exist.', 108, $this->source); })()), "lat", [], "any", false, false, false, 108), "html", null, true))) : (print (29.97957019257461297456757165491580963134765625)));
        echo "],
            zoom: 17
        });

        var marker = new mapboxgl.Marker({
            draggable: true
        })
            .setLngLat([";
        // line 115
        ((0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["shipping"]) || array_key_exists("shipping", $context) ? $context["shipping"] : (function () { throw new RuntimeError('Variable "shipping" does not exist.', 115, $this->source); })()), "lng", [], "any", false, false, false, 115), null)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["shipping"]) || array_key_exists("shipping", $context) ? $context["shipping"] : (function () { throw new RuntimeError('Variable "shipping" does not exist.', 115, $this->source); })()), "lng", [], "any", false, false, false, 115), "html", null, true))) : (print (31.168468256781608261007932014763355255126953125)));
        echo ", ";
        ((0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["shipping"]) || array_key_exists("shipping", $context) ? $context["shipping"] : (function () { throw new RuntimeError('Variable "shipping" does not exist.', 115, $this->source); })()), "lat", [], "any", false, false, false, 115), null)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["shipping"]) || array_key_exists("shipping", $context) ? $context["shipping"] : (function () { throw new RuntimeError('Variable "shipping" does not exist.', 115, $this->source); })()), "lat", [], "any", false, false, false, 115), "html", null, true))) : (print (29.97957019257461297456757165491580963134765625)));
        echo "])
            .addTo(map);

        function onDragEnd() {
            var lngLat = marker.getLngLat();
            coordinates.style.display = 'block';
            \$('#shipping_form_lng').val(lngLat.lng);
            \$('#shipping_form_lat').val(lngLat.lat);
        }

        marker.on('dragend', onDragEnd);
    </script>

    <script>

    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "dashboard/shippings/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  288 => 115,  276 => 108,  268 => 102,  258 => 101,  242 => 93,  232 => 92,  205 => 74,  201 => 73,  197 => 72,  183 => 61,  179 => 60,  175 => 59,  169 => 56,  165 => 55,  161 => 54,  151 => 47,  147 => 46,  143 => 45,  136 => 41,  132 => 40,  128 => 39,  121 => 35,  117 => 34,  113 => 33,  107 => 30,  103 => 29,  84 => 13,  80 => 12,  70 => 4,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'dashboard/layouts/base.html.twig' %}

{% block content %}
    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">تعديل شركات الشحن</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"{{ path('dashboard.index') }}\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"{{ path('dashboard.shippings.index') }}\">شركات الشحن</a></li>
                        <li class=\"breadcrumb-item active\">تعديل</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <form role=\"form\" method=\"post\" enctype=\"multipart/form-data\">
                            {{ form_errors(form) }}
                            {{ form_row(form._token) }}
                            <div class=\"card-body\">
                                <div class=\"form-group\">
                                    {{ form_label(form.name) }}
                                    {{ form_widget(form.name) }}
                                    <div style=\"color: red\" class=\"errors\">{{ form_errors(form.name) }}</div>
                                </div>

                                <div class=\"form-group\">
                                    {{ form_label(form.User) }}
                                    {{ form_widget(form.User) }}
                                    <div style=\"color: red\" class=\"errors\">{{ form_errors(form.User) }}</div>
                                </div>

                                <div class=\"form-group\">
                                    {{ form_label(form.address) }}
                                    {{ form_widget(form.address) }}
                                    <div style=\"color: red\" class=\"errors\">{{ form_errors(form.address) }}</div>
                                </div>


                                <div class=\"form-group\">
                                    <div class=\"row\">
                                        <div class=\"col-md-6\">
                                            {{ form_label(form.lng) }}
                                            {{ form_widget(form.lng) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.lng) }}</div>
                                        </div>
                                        <div class=\"col-md-6\">
                                            {{ form_label(form.lat) }}
                                            {{ form_widget(form.lat) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.lat) }}</div>
                                        </div>
                                    </div>
                                </div>

                                <div class=\"form-group\">
                                    <div id=\"map\"></div>
                                    <pre id=\"coordinates\" class=\"coordinates\"></pre>
                                </div>

                                <div class=\"form-group\">
                                    {{ form_label(form.icon) }}
                                    {{ form_widget(form.icon) }}
                                    <div style=\"color: red\" class=\"errors\">{{ form_errors(form.icon) }}</div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class=\"card-footer\">
                                <button type=\"submit\" class=\"btn btn-primary\">ارسال</button>
                            </div>
                        </form>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
{% endblock %}

{% block css %}
    <script src=\"https://api.mapbox.com/mapbox-gl-js/v1.10.1/mapbox-gl.js\"></script>
    <link href=\"https://api.mapbox.com/mapbox-gl-js/v1.10.1/mapbox-gl.css\" rel=\"stylesheet\" />
    <style>
        body { margin: 0; padding: 0; }
        #map { top: 0; bottom: 0;height: 300px; width: 100%; }
    </style>
{% endblock %}

{% block js %}
    <script>
        mapboxgl.accessToken = 'pk.eyJ1IjoiZXNsYW1ib3VsbHkiLCJhIjoiY2thaWdncDE3MDBqMjJ6dGR4cHhzeDlkYiJ9.ZUE0a2peQttyyS3jxfiPlQ';
        var coordinates = document.getElementById('coordinates');
        var map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/streets-v11',
            center: [{{ shipping.lng != null ? shipping.lng : 31.16846825678161 }}, {{ shipping.lat != null ? shipping.lat : 29.979570192574613 }}],
            zoom: 17
        });

        var marker = new mapboxgl.Marker({
            draggable: true
        })
            .setLngLat([{{ shipping.lng != null ? shipping.lng : 31.16846825678161 }}, {{ shipping.lat != null ? shipping.lat : 29.979570192574613 }}])
            .addTo(map);

        function onDragEnd() {
            var lngLat = marker.getLngLat();
            coordinates.style.display = 'block';
            \$('#shipping_form_lng').val(lngLat.lng);
            \$('#shipping_form_lat').val(lngLat.lat);
        }

        marker.on('dragend', onDragEnd);
    </script>

    <script>

    </script>
{% endblock %}", "dashboard/shippings/edit.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/shippings/edit.html.twig");
    }
}
