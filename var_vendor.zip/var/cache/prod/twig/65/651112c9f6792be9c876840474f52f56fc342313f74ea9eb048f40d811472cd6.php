<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/sizes/edit.html.twig */
class __TwigTemplate_e8a1d7ca3c18ee196749541c6881a179a3504ebb6610f128f94982f3214c1e24 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/sizes/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">تعديل العلامات التجارية</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.sizes.index");
        echo "\">العلامات التجارية</a></li>
                        <li class=\"breadcrumb-item active\">تعديل</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <form role=\"form\" method=\"post\" enctype=\"multipart/form-data\">
                            ";
        // line 29
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        echo "
                            ";
        // line 30
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "_token", [], "any", false, false, false, 30), 'row');
        echo "
                            <div class=\"card-body\">
                                <div class=\"form-group\">
                                    ";
        // line 33
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 33), 'label');
        echo "
                                    ";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 34), 'widget');
        echo "
                                    <div style=\"color: red\" class=\"errors\">";
        // line 35
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 35), 'errors');
        echo "</div>
                                </div>
                                <div class=\"form-group\">
                                    <input id=\"department_form_department\" type=\"hidden\" name=\"department_id\" value=\"\">
                                    <label for=\"\">القسم الرئيسي</label>
                                    <div id=\"jstree_demo_div\"></div>
                                </div>
                                <div class=\"form-group\">
                                    ";
        // line 43
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "is_public", [], "any", false, false, false, 43), 'label');
        echo "
                                    ";
        // line 44
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "is_public", [], "any", false, false, false, 44), 'widget');
        echo "
                                    <div style=\"color: red\" class=\"errors\">";
        // line 45
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "is_public", [], "any", false, false, false, 45), 'errors');
        echo "</div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class=\"card-footer\">
                                <button type=\"submit\" class=\"btn btn-primary\">ارسال</button>
                            </div>
                        </form>

                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
";
    }

    // line 64
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 65
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/themes/default/style.min.css\" />
";
    }

    // line 68
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 69
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/jstree.min.js\"></script>

    <script>
        \$(function () { \$('#jstree_demo_div').jstree({ 'core' : {
                'data' : ";
        // line 73
        echo ($context["departments"] ?? null);
        echo "
            } }); });

        \$('#jstree_demo_div').on(\"changed.jstree\", function (e, data) {
            \$('#department_form_department').val(data.selected);
        });
    </script>
";
    }

    public function getTemplateName()
    {
        return "dashboard/sizes/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 73,  159 => 69,  155 => 68,  148 => 65,  144 => 64,  122 => 45,  118 => 44,  114 => 43,  103 => 35,  99 => 34,  95 => 33,  89 => 30,  85 => 29,  66 => 13,  62 => 12,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/sizes/edit.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/sizes/edit.html.twig");
    }
}
