<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/orders/index.html.twig */
class __TwigTemplate_beefc04f0e8981739fe20f9a75f9aa3bf6516d10ec2304a40f6ee3a1b5a584bd extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/orders/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">جدول الطلبات</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item active\">الطلبات</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <div class=\"card-header\">
";
        // line 29
        echo "                            <a href=\"\" class=\"btn btn-info btn-md\" onclick=\"window.print()\"><i class=\"fa fa-print\"></i> طباعة </a>
                            <a href=\"\" class=\"btn btn-primary btn-md\"><i class=\"fa fa-plus\"></i> استيراد اكسل </a>
                            <a href=\"\" class=\"btn btn-default btn-md\"><i class=\"fa fa-refresh\"></i></a>
                            <a href=\"\" class=\"btn btn-danger btn-md\"><i class=\"fa fa-trash\"></i> حذف الكل </a>
                        </div>
                        <!-- /.card-header -->
                        <div class=\"card-body\">
                            ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "flashes", [0 => "success"], "method", false, false, false, 36));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 37
            echo "                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <div class=\"card\">
                                            <div class=\"card-body label label-success\">
                                                <div style=\"font-size: 18px;\">";
            // line 41
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "
                            ";
        // line 48
        if (1 === twig_compare(twig_length_filter($this->env, ($context["orders"] ?? null)), 0)) {
            // line 49
            echo "                                <table id=\"table-country\" class=\"table table-bordered\">
                                    <tr>
                                        <th>رقم الطلب</th>
                                        <th>السعر الكلي</th>
                                        <th>صاحب الطلب</th>
                                        <th>الحالة</th>
                                        <th>العمليات</th>
                                    </tr>

                                    ";
            // line 58
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["orders"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["order"]) {
                // line 59
                echo "                                        <tr>
                                            <td>#";
                // line 60
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["order"], "id", [], "any", false, false, false, 60), "html", null, true);
                echo "</td>
                                            <td>";
                // line 61
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["order"], "totalPrice", [], "any", false, false, false, 61), "html", null, true);
                echo " جنية مصري</td>
                                            <td>
                                                ";
                // line 63
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["order"], "User", [], "any", false, false, false, 63), "name", [], "any", false, false, false, 63), "html", null, true);
                echo "
                                                <br/>
                                                ";
                // line 65
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["order"], "User", [], "any", false, false, false, 65), "email", [], "any", false, false, false, 65), "html", null, true);
                echo "
                                            </td>
                                            <td>
                                                ";
                // line 68
                if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["order"], "status", [], "any", false, false, false, 68), 1)) {
                    // line 69
                    echo "                                                    ";
                    echo "جاري التجهيز";
                    echo "
                                                ";
                } elseif (0 === twig_compare(twig_get_attribute($this->env, $this->source,                 // line 70
$context["order"], "status", [], "any", false, false, false, 70), 2)) {
                    // line 71
                    echo "                                                    ";
                    echo "تم تجهيز الطلب";
                    echo "
                                                ";
                } elseif (0 === twig_compare(twig_get_attribute($this->env, $this->source,                 // line 72
$context["order"], "status", [], "any", false, false, false, 72), 3)) {
                    // line 73
                    echo "                                                    ";
                    echo "تم الاستلام من العميل";
                    echo "
                                                ";
                }
                // line 75
                echo "                                            </td>
                                            <td>
                                                <a href=\"";
                // line 77
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.orders.edit", ["id" => twig_get_attribute($this->env, $this->source, $context["order"], "id", [], "any", false, false, false, 77)]), "html", null, true);
                echo "\" class=\"btn btn-success btn-sm\"><i class=\"fa fa-edit\"></i> التالي </a>
                                                <a href=\"";
                // line 78
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.orders.destroy", ["id" => twig_get_attribute($this->env, $this->source, $context["order"], "id", [], "any", false, false, false, 78)]), "html", null, true);
                echo "\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i> حذف </a>
                                            </td>
                                        </tr>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['order'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 82
            echo "                                </table>
                            ";
        } else {
            // line 84
            echo "                                <h1>للأسف لا يوجد مدن او محافظات حتي الان</h1>
                            ";
        }
        // line 86
        echo "                        </div>
                        <!-- /.card-body -->
";
        // line 97
        echo "                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
        </div><!-- /.container-fluid -->
    </section>

";
    }

    public function getTemplateName()
    {
        return "dashboard/orders/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 97,  201 => 86,  197 => 84,  193 => 82,  183 => 78,  179 => 77,  175 => 75,  169 => 73,  167 => 72,  162 => 71,  160 => 70,  155 => 69,  153 => 68,  147 => 65,  142 => 63,  137 => 61,  133 => 60,  130 => 59,  126 => 58,  115 => 49,  113 => 48,  110 => 47,  98 => 41,  92 => 37,  88 => 36,  79 => 29,  60 => 12,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/orders/index.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/orders/index.html.twig");
    }
}
