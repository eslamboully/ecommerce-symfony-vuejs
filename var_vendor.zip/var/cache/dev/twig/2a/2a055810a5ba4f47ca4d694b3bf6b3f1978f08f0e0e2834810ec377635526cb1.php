<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/products/edit.html.twig */
class __TwigTemplate_3dac5740ac9e0636a2ae773db725034b5954ad12bda4216c9333bbaad9ca548b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/products/edit.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/products/edit.html.twig"));

        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/products/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">تعديل المنتج</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\">المنتجات</a></li>
                        <li class=\"breadcrumb-item active\">تعديل</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"card card-primary card-outline\">
                    <div class=\"card-body\">
                        <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
                            ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 30, $this->source); })()), "flashes", [0 => "success"], "method", false, false, false, 30));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 31
            echo "                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <div class=\"card\">
                                            <div class=\"card-body label label-success\">
                                                <div style=\"font-size: 18px;\">";
            // line 35
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "                            <div style=\"margin-bottom: 10px\">
                                <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
                                <a href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.create", ["copyId" => twig_get_attribute($this->env, $this->source, (isset($context["product"]) || array_key_exists("product", $context) ? $context["product"] : (function () { throw new RuntimeError('Variable "product" does not exist.', 44, $this->source); })()), "id", [], "any", false, false, false, 44)]), "html", null, true);
        echo "\" class=\"btn btn-primary\"> نسخ المنتج <i class=\"fa fa-copy\"></i></a>
                                <a href=\"";
        // line 45
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
                                <a href=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.destroy", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["product"]) || array_key_exists("product", $context) ? $context["product"] : (function () { throw new RuntimeError('Variable "product" does not exist.', 46, $this->source); })()), "id", [], "any", false, false, false, 46)]), "html", null, true);
        echo "\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger\"> حذف <i class=\"fa fa-trash\"></i></a>
                            </div>
                            ";
        // line 48
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 48, $this->source); })()), 'errors');
        echo "
                            ";
        // line 49
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 49, $this->source); })()), "_token", [], "any", false, false, false, 49), 'row');
        echo "
                            <ul class=\"nav nav-tabs\" id=\"custom-content-below-tab\" role=\"tablist\">
                                <li class=\"nav-item\">
                                    <a class=\"nav-link active\" id=\"custom-content-below-info-tab\" data-toggle=\"pill\" href=\"#custom-content-below-info\" role=\"tab\" aria-controls=\"custom-content-below-home\" aria-selected=\"true\"><i class=\"fa fa-info\"></i> معلومات المنتج </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-department-tab\" data-toggle=\"pill\" href=\"#custom-content-below-department\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-list\"></i> القسم </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-settings-tab\" data-toggle=\"pill\" href=\"#custom-content-below-settings\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-gears\"></i> اعدادات المنتج </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-content-tab\" data-toggle=\"pill\" href=\"#custom-content-below-content\" role=\"tab\" aria-controls=\"custom-content-below-messages\" aria-selected=\"false\"><i class=\"fa fa-question\"></i> سبب الرفض </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-sizes-tab\" data-toggle=\"pill\" href=\"#custom-content-below-sizes\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-truck\"></i> معلومات الشحن </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-other-tab\" data-toggle=\"pill\" href=\"#custom-content-below-other\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-cart-plus\"></i> معلومات اضافية </a>
                                </li>
                            </ul>
                            <div class=\"tab-content\" id=\"custom-content-below-tabContent\">
                                <div class=\"tab-pane fade active show\" id=\"custom-content-below-info\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-info-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات المنتج</h3>
                                        <div class=\"form-group\">
                                            ";
        // line 75
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 75, $this->source); })()), "title", [], "any", false, false, false, 75), 'label');
        echo "
                                            ";
        // line 76
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 76, $this->source); })()), "title", [], "any", false, false, false, 76), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 77
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 77, $this->source); })()), "title", [], "any", false, false, false, 77), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"form-group\">
                                            ";
        // line 80
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 80, $this->source); })()), "content", [], "any", false, false, false, 80), 'label');
        echo "
                                            ";
        // line 81
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 81, $this->source); })()), "content", [], "any", false, false, false, 81), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 82
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 82, $this->source); })()), "content", [], "any", false, false, false, 82), 'errors');
        echo "</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade show\" id=\"custom-content-below-department\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-department-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>القسم</h3>
                                        <div class=\"form-group\">
                                            <input id=\"department_form_department\" type=\"hidden\" name=\"department_id\" value=\"\">
                                            ";
        // line 92
        echo "                                            <div id=\"jstree_demo_div\"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-settings\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-settings-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>اعدادات المنتج</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 101
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 101, $this->source); })()), "price", [], "any", false, false, false, 101), 'label');
        echo "
                                                ";
        // line 102
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 102, $this->source); })()), "price", [], "any", false, false, false, 102), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 103
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 103, $this->source); })()), "price", [], "any", false, false, false, 103), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 106
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 106, $this->source); })()), "stock", [], "any", false, false, false, 106), 'label');
        echo "
                                                ";
        // line 107
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 107, $this->source); })()), "stock", [], "any", false, false, false, 107), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 108
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 108, $this->source); })()), "stock", [], "any", false, false, false, 108), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 111
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 111, $this->source); })()), "start_at", [], "any", false, false, false, 111), 'label');
        echo "
                                                ";
        // line 112
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 112, $this->source); })()), "start_at", [], "any", false, false, false, 112), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 113
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 113, $this->source); })()), "start_at", [], "any", false, false, false, 113), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 116
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 116, $this->source); })()), "end_at", [], "any", false, false, false, 116), 'label');
        echo "
                                                ";
        // line 117
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 117, $this->source); })()), "end_at", [], "any", false, false, false, 117), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 118
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 118, $this->source); })()), "end_at", [], "any", false, false, false, 118), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                        <div class=\"form-group\">
                                            ";
        // line 122
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 122, $this->source); })()), "price_offer", [], "any", false, false, false, 122), 'label');
        echo "
                                            ";
        // line 123
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 123, $this->source); })()), "price_offer", [], "any", false, false, false, 123), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 124
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 124, $this->source); })()), "price_offer", [], "any", false, false, false, 124), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 128
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 128, $this->source); })()), "start_offer_at", [], "any", false, false, false, 128), 'label');
        echo "
                                                ";
        // line 129
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 129, $this->source); })()), "start_offer_at", [], "any", false, false, false, 129), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 130
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 130, $this->source); })()), "start_offer_at", [], "any", false, false, false, 130), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 133
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 133, $this->source); })()), "end_offer_at", [], "any", false, false, false, 133), 'label');
        echo "
                                                ";
        // line 134
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 134, $this->source); })()), "end_offer_at", [], "any", false, false, false, 134), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 135
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 135, $this->source); })()), "end_offer_at", [], "any", false, false, false, 135), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-content\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-content-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>سبب الرفض والحالة</h3>
                                        <div class=\"form-group\">
                                            ";
        // line 144
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 144, $this->source); })()), "status", [], "any", false, false, false, 144), 'label');
        echo "
                                            ";
        // line 145
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 145, $this->source); })()), "status", [], "any", false, false, false, 145), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 146
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 146, $this->source); })()), "status", [], "any", false, false, false, 146), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"form-group\">
                                            ";
        // line 149
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 149, $this->source); })()), "reason", [], "any", false, false, false, 149), 'label');
        echo "
                                            ";
        // line 150
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 150, $this->source); })()), "reason", [], "any", false, false, false, 150), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 151
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 151, $this->source); })()), "reason", [], "any", false, false, false, 151), 'errors');
        echo "</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-sizes\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-sizes-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>الوزن والحجم</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 160
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 160, $this->source); })()), "weight_string", [], "any", false, false, false, 160), 'label');
        echo "
                                                ";
        // line 161
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 161, $this->source); })()), "weight_string", [], "any", false, false, false, 161), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 162
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 162, $this->source); })()), "weight_string", [], "any", false, false, false, 162), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 165
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 165, $this->source); })()), "weight", [], "any", false, false, false, 165), 'label');
        echo "
                                                ";
        // line 166
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 166, $this->source); })()), "weight", [], "any", false, false, false, 166), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 167
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 167, $this->source); })()), "weight", [], "any", false, false, false, 167), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 170
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 170, $this->source); })()), "Size", [], "any", false, false, false, 170), 'label');
        echo "
                                                ";
        // line 171
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 171, $this->source); })()), "Size", [], "any", false, false, false, 171), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 172
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 172, $this->source); })()), "Size", [], "any", false, false, false, 172), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 175
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 175, $this->source); })()), "size_string", [], "any", false, false, false, 175), 'label');
        echo "
                                                ";
        // line 176
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 176, $this->source); })()), "size_string", [], "any", false, false, false, 176), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 177
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 177, $this->source); })()), "size_string", [], "any", false, false, false, 177), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 180
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 180, $this->source); })()), "Country", [], "any", false, false, false, 180), 'label');
        echo "
                                                ";
        // line 181
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 181, $this->source); })()), "Country", [], "any", false, false, false, 181), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 182
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 182, $this->source); })()), "Country", [], "any", false, false, false, 182), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 185
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 185, $this->source); })()), "ManuFact", [], "any", false, false, false, 185), 'label');
        echo "
                                                ";
        // line 186
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 186, $this->source); })()), "ManuFact", [], "any", false, false, false, 186), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 187
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 187, $this->source); })()), "ManuFact", [], "any", false, false, false, 187), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-12 col-lg-12 col-sm-12 col-sm-12\">
                                                ";
        // line 190
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 190, $this->source); })()), "Color", [], "any", false, false, false, 190), 'label');
        echo "
                                                ";
        // line 191
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 191, $this->source); })()), "Color", [], "any", false, false, false, 191), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 192
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 192, $this->source); })()), "Color", [], "any", false, false, false, 192), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-other\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-other-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات اضافية</h3>
                                        ";
        // line 200
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 200, $this->source); })()), "photo", [], "any", false, false, false, 200), 'label');
        echo "
                                        ";
        // line 201
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 201, $this->source); })()), "photo", [], "any", false, false, false, 201), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 202
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 202, $this->source); })()), "photo", [], "any", false, false, false, 202), 'errors');
        echo "</div>
                                        ";
        // line 203
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 203, $this->source); })()), "Trademark", [], "any", false, false, false, 203), 'label');
        echo "
                                        ";
        // line 204
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 204, $this->source); })()), "Trademark", [], "any", false, false, false, 204), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 205
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 205, $this->source); })()), "Trademark", [], "any", false, false, false, 205), 'errors');
        echo "</div>
                                        ";
        // line 206
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 206, $this->source); })()), "other_data", [], "any", false, false, false, 206), 'label');
        echo "
                                        ";
        // line 207
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 207, $this->source); })()), "other_data", [], "any", false, false, false, 207), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 208
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 208, $this->source); })()), "other_data", [], "any", false, false, false, 208), 'errors');
        echo "</div>
                                    </div>
                                </div>
                            </div>
                            <div style=\"margin-bottom: 5px;margin-top: 10px\">
                                <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
                                <a href=\"";
        // line 215
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.create", ["copyId" => twig_get_attribute($this->env, $this->source, (isset($context["product"]) || array_key_exists("product", $context) ? $context["product"] : (function () { throw new RuntimeError('Variable "product" does not exist.', 215, $this->source); })()), "id", [], "any", false, false, false, 215)]), "html", null, true);
        echo "\" class=\"btn btn-primary\"> نسخ المنتج <i class=\"fa fa-copy\"></i></a>
                                <a href=\"";
        // line 216
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
                                <a href=\"";
        // line 217
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.destroy", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["product"]) || array_key_exists("product", $context) ? $context["product"] : (function () { throw new RuntimeError('Variable "product" does not exist.', 217, $this->source); })()), "id", [], "any", false, false, false, 217)]), "html", null, true);
        echo "\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger\"> حذف <i class=\"fa fa-trash\"></i></a>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div><!-- /.container-fluid -->
    </section>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 231
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        // line 232
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/themes/default/style.min.css\" />
    <link rel=\"stylesheet\" href=\"";
        // line 233
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2.min.css\">
    <link rel=\"stylesheet\" href=\"";
        // line 234
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2-bootstrap4.min.css\">

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 238
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 239
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/jstree.min.js\"></script>
    <script src=\"";
        // line 240
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2.full.min.js\"></script>
    <script src=\"https://cdn.ckeditor.com/4.14.0/standard-all/ckeditor.js\"></script>

    <script>
        ";
        // line 245
        echo "        ";
        // line 246
        echo "        ";
        // line 247
        echo "
        ";
        // line 249
        echo "        ";
        // line 250
        echo "        ";
        // line 251
        echo "        ";
        // line 252
        echo "        ";
        // line 253
        echo "        ";
        // line 254
        echo "        ";
        // line 255
        echo "        ";
        // line 256
        echo "        ";
        // line 257
        echo "        ";
        // line 258
        echo "        ";
        // line 259
        echo "        ";
        // line 260
        echo "        ";
        // line 261
        echo "        ";
        // line 262
        echo "        ";
        // line 263
        echo "        ";
        // line 264
        echo "        ";
        // line 265
        echo "        ";
        // line 266
        echo "        ";
        // line 267
        echo "
        \$(function () { \$('#jstree_demo_div').jstree({ 'core' : {
                'data' : ";
        // line 269
        echo (isset($context["departments"]) || array_key_exists("departments", $context) ? $context["departments"] : (function () { throw new RuntimeError('Variable "departments" does not exist.', 269, $this->source); })());
        echo "
            } }); });

        \$('#jstree_demo_div').on(\"changed.jstree\", function (e, data) {
            \$('#department_form_department').val(data.selected);

            \$.ajax({
                'method': 'POST',
                'url' : '";
        // line 277
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.specific.size");
        echo "',
                'type' : 'json',
                'data' : {id:data.selected},
                success : function (data_ajax) {
                    \$('#product_form_Size').html('');
                    \$.each(data_ajax, function( index, size ) {
                        \$('#product_form_Size').append(`<option value=\"\${size.id}\">\${size.name}</option>`);
                    });
                },
                beforeSend: function(){
                    \$('.card-footer button').attr('disabled' ,'disabled');
                },
                complete: function(){
                    \$('.card-footer button').removeAttr('disabled' ,'disabled');
                },
            });
        });

        \$(document).ready(function() {
            \$('.select2').select2();
            CKEDITOR.replace('product_form[content]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });

            CKEDITOR.replace('product_form[other_data]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });
        });
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "dashboard/products/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  650 => 277,  639 => 269,  635 => 267,  633 => 266,  631 => 265,  629 => 264,  627 => 263,  625 => 262,  623 => 261,  621 => 260,  619 => 259,  617 => 258,  615 => 257,  613 => 256,  611 => 255,  609 => 254,  607 => 253,  605 => 252,  603 => 251,  601 => 250,  599 => 249,  596 => 247,  594 => 246,  592 => 245,  585 => 240,  580 => 239,  570 => 238,  557 => 234,  553 => 233,  548 => 232,  538 => 231,  515 => 217,  511 => 216,  507 => 215,  497 => 208,  493 => 207,  489 => 206,  485 => 205,  481 => 204,  477 => 203,  473 => 202,  469 => 201,  465 => 200,  454 => 192,  450 => 191,  446 => 190,  440 => 187,  436 => 186,  432 => 185,  426 => 182,  422 => 181,  418 => 180,  412 => 177,  408 => 176,  404 => 175,  398 => 172,  394 => 171,  390 => 170,  384 => 167,  380 => 166,  376 => 165,  370 => 162,  366 => 161,  362 => 160,  350 => 151,  346 => 150,  342 => 149,  336 => 146,  332 => 145,  328 => 144,  316 => 135,  312 => 134,  308 => 133,  302 => 130,  298 => 129,  294 => 128,  287 => 124,  283 => 123,  279 => 122,  272 => 118,  268 => 117,  264 => 116,  258 => 113,  254 => 112,  250 => 111,  244 => 108,  240 => 107,  236 => 106,  230 => 103,  226 => 102,  222 => 101,  211 => 92,  199 => 82,  195 => 81,  191 => 80,  185 => 77,  181 => 76,  177 => 75,  148 => 49,  144 => 48,  139 => 46,  135 => 45,  131 => 44,  126 => 41,  114 => 35,  108 => 31,  104 => 30,  84 => 13,  80 => 12,  70 => 4,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'dashboard/layouts/base.html.twig' %}

{% block content %}
    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">تعديل المنتج</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"{{ path('dashboard.index') }}\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"{{ path('dashboard.products.index') }}\">المنتجات</a></li>
                        <li class=\"breadcrumb-item active\">تعديل</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"card card-primary card-outline\">
                    <div class=\"card-body\">
                        <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
                            {% for message in app.flashes('success') %}
                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <div class=\"card\">
                                            <div class=\"card-body label label-success\">
                                                <div style=\"font-size: 18px;\">{{ message }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            {% endfor %}
                            <div style=\"margin-bottom: 10px\">
                                <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
                                <a href=\"{{ path('dashboard.products.create',{\"copyId\":product.id}) }}\" class=\"btn btn-primary\"> نسخ المنتج <i class=\"fa fa-copy\"></i></a>
                                <a href=\"{{ path('dashboard.products.index') }}\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
                                <a href=\"{{ path('dashboard.products.destroy',{\"id\":product.id}) }}\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger\"> حذف <i class=\"fa fa-trash\"></i></a>
                            </div>
                            {{ form_errors(form) }}
                            {{ form_row(form._token) }}
                            <ul class=\"nav nav-tabs\" id=\"custom-content-below-tab\" role=\"tablist\">
                                <li class=\"nav-item\">
                                    <a class=\"nav-link active\" id=\"custom-content-below-info-tab\" data-toggle=\"pill\" href=\"#custom-content-below-info\" role=\"tab\" aria-controls=\"custom-content-below-home\" aria-selected=\"true\"><i class=\"fa fa-info\"></i> معلومات المنتج </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-department-tab\" data-toggle=\"pill\" href=\"#custom-content-below-department\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-list\"></i> القسم </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-settings-tab\" data-toggle=\"pill\" href=\"#custom-content-below-settings\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-gears\"></i> اعدادات المنتج </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-content-tab\" data-toggle=\"pill\" href=\"#custom-content-below-content\" role=\"tab\" aria-controls=\"custom-content-below-messages\" aria-selected=\"false\"><i class=\"fa fa-question\"></i> سبب الرفض </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-sizes-tab\" data-toggle=\"pill\" href=\"#custom-content-below-sizes\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-truck\"></i> معلومات الشحن </a>
                                </li>
                                <li class=\"nav-item\">
                                    <a class=\"nav-link\" id=\"custom-content-below-other-tab\" data-toggle=\"pill\" href=\"#custom-content-below-other\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-cart-plus\"></i> معلومات اضافية </a>
                                </li>
                            </ul>
                            <div class=\"tab-content\" id=\"custom-content-below-tabContent\">
                                <div class=\"tab-pane fade active show\" id=\"custom-content-below-info\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-info-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات المنتج</h3>
                                        <div class=\"form-group\">
                                            {{ form_label(form.title) }}
                                            {{ form_widget(form.title) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.title) }}</div>
                                        </div>
                                        <div class=\"form-group\">
                                            {{ form_label(form.content) }}
                                            {{ form_widget(form.content) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.content) }}</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade show\" id=\"custom-content-below-department\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-department-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>القسم</h3>
                                        <div class=\"form-group\">
                                            <input id=\"department_form_department\" type=\"hidden\" name=\"department_id\" value=\"\">
                                            {#                                            <label for=\"\">اختر القسم</label>#}
                                            <div id=\"jstree_demo_div\"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-settings\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-settings-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>اعدادات المنتج</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.price) }}
                                                {{ form_widget(form.price) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.price) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.stock) }}
                                                {{ form_widget(form.stock) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.stock) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.start_at) }}
                                                {{ form_widget(form.start_at) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.start_at) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.end_at) }}
                                                {{ form_widget(form.end_at) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.end_at) }}</div>
                                            </div>
                                        </div>
                                        <div class=\"form-group\">
                                            {{ form_label(form.price_offer) }}
                                            {{ form_widget(form.price_offer) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.price_offer) }}</div>
                                        </div>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                {{ form_label(form.start_offer_at) }}
                                                {{ form_widget(form.start_offer_at) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.start_offer_at) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                {{ form_label(form.end_offer_at) }}
                                                {{ form_widget(form.end_offer_at) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.end_offer_at) }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-content\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-content-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>سبب الرفض والحالة</h3>
                                        <div class=\"form-group\">
                                            {{ form_label(form.status) }}
                                            {{ form_widget(form.status) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.status) }}</div>
                                        </div>
                                        <div class=\"form-group\">
                                            {{ form_label(form.reason) }}
                                            {{ form_widget(form.reason) }}
                                            <div style=\"color: red\" class=\"errors\">{{ form_errors(form.reason) }}</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-sizes\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-sizes-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>الوزن والحجم</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.weight_string) }}
                                                {{ form_widget(form.weight_string) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.weight_string) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.weight) }}
                                                {{ form_widget(form.weight) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.weight) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.Size) }}
                                                {{ form_widget(form.Size) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.Size) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                {{ form_label(form.size_string) }}
                                                {{ form_widget(form.size_string) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.size_string) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                {{ form_label(form.Country) }}
                                                {{ form_widget(form.Country) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.Country) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                {{ form_label(form.ManuFact) }}
                                                {{ form_widget(form.ManuFact) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.ManuFact) }}</div>
                                            </div>
                                            <div class=\"form-group col-md-12 col-lg-12 col-sm-12 col-sm-12\">
                                                {{ form_label(form.Color) }}
                                                {{ form_widget(form.Color) }}
                                                <div style=\"color: red\" class=\"errors\">{{ form_errors(form.Color) }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-other\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-other-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات اضافية</h3>
                                        {{ form_label(form.photo) }}
                                        {{ form_widget(form.photo) }}
                                        <div style=\"color: red\" class=\"errors\">{{ form_errors(form.photo) }}</div>
                                        {{ form_label(form.Trademark) }}
                                        {{ form_widget(form.Trademark) }}
                                        <div style=\"color: red\" class=\"errors\">{{ form_errors(form.Trademark) }}</div>
                                        {{ form_label(form.other_data) }}
                                        {{ form_widget(form.other_data) }}
                                        <div style=\"color: red\" class=\"errors\">{{ form_errors(form.other_data) }}</div>
                                    </div>
                                </div>
                            </div>
                            <div style=\"margin-bottom: 5px;margin-top: 10px\">
                                <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
                                <a href=\"{{ path('dashboard.products.create',{\"copyId\":product.id}) }}\" class=\"btn btn-primary\"> نسخ المنتج <i class=\"fa fa-copy\"></i></a>
                                <a href=\"{{ path('dashboard.products.index') }}\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
                                <a href=\"{{ path('dashboard.products.destroy',{\"id\":product.id}) }}\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger\"> حذف <i class=\"fa fa-trash\"></i></a>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div><!-- /.container-fluid -->
    </section>

{% endblock %}

{% block css %}
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/dist/themes/default/style.min.css\" />
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/select2/select2.min.css\">
    <link rel=\"stylesheet\" href=\"{{ asset('dashboard') }}/plugins/select2/select2-bootstrap4.min.css\">

{% endblock %}

{% block js %}
    <script src=\"{{ asset('dashboard') }}/dist/jstree.min.js\"></script>
    <script src=\"{{ asset('dashboard') }}/plugins/select2/select2.full.min.js\"></script>
    <script src=\"https://cdn.ckeditor.com/4.14.0/standard-all/ckeditor.js\"></script>

    <script>
        {#\$(document).ready(function () {#}
        {#    let id = \$('#department_form_department').val();#}
        {#    // var selectedCountryId = \$(country).children(\"option:selected\").val();#}

        {#    #}{#\$.ajax(#}{#}#}
        {#    #}{#    'method': 'POST',#}
        {#    #}{#    'url' : '{{ path('dashboard.products.specific.size') }}',#}
        {#    #}{#    'type' : 'json',#}
        {#    #}{#    'data' : {id:id},#}
        {#    #}{#    success : function (data_ajax) #}{#}#}
        {#    #}{#        \$('#product_form_Size').html('');#}
        {#    #}{#        \$.each(data_ajax, function( index, size ) #}{#}#}
        {#    #}{#            \$('#product_form_Size').append(`<option value=\"\${size.id}\">\${size.name}</option>`);#}
        {#    #}{#        });#}
        {#    #}{#    },#}
        {#    #}{#    beforeSend: function()#}{#}#}
        {#    #}{#        \$('.card-footer button').attr('disabled' ,'disabled');#}
        {#    #}{#    },#}
        {#    #}{#    complete: function()#}{#}#}
        {#    #}{#        \$('.card-footer button').removeAttr('disabled' ,'disabled');#}
        {#    #}{#    },#}
        {#    #}{#});#}
        {#});#}

        \$(function () { \$('#jstree_demo_div').jstree({ 'core' : {
                'data' : {{ departments | raw }}
            } }); });

        \$('#jstree_demo_div').on(\"changed.jstree\", function (e, data) {
            \$('#department_form_department').val(data.selected);

            \$.ajax({
                'method': 'POST',
                'url' : '{{ path('dashboard.products.specific.size') }}',
                'type' : 'json',
                'data' : {id:data.selected},
                success : function (data_ajax) {
                    \$('#product_form_Size').html('');
                    \$.each(data_ajax, function( index, size ) {
                        \$('#product_form_Size').append(`<option value=\"\${size.id}\">\${size.name}</option>`);
                    });
                },
                beforeSend: function(){
                    \$('.card-footer button').attr('disabled' ,'disabled');
                },
                complete: function(){
                    \$('.card-footer button').removeAttr('disabled' ,'disabled');
                },
            });
        });

        \$(document).ready(function() {
            \$('.select2').select2();
            CKEDITOR.replace('product_form[content]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });

            CKEDITOR.replace('product_form[other_data]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });
        });
    </script>
{% endblock %}", "dashboard/products/edit.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/products/edit.html.twig");
    }
}
