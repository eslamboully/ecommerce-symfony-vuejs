<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/products/create.html.twig */
class __TwigTemplate_68211616402413f81e119dfaa04c48929fbb5b4067f739a5ba5614553da9e7ff extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/products/create.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">اضف منتج</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\">المنتجات</a></li>
                        <li class=\"breadcrumb-item active\">اضف</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card card-primary card-outline\">
                        <div class=\"card-body\">
                            <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
                                <div style=\"margin-bottom: 10px\">
                                    <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                    <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
";
        // line 34
        echo "                                    <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
";
        // line 36
        echo "                                </div>
                                ";
        // line 37
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        echo "
                                ";
        // line 38
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "_token", [], "any", false, false, false, 38), 'row');
        echo "
                                <ul class=\"nav nav-tabs\" id=\"custom-content-below-tab\" role=\"tablist\">
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link active\" id=\"custom-content-below-info-tab\" data-toggle=\"pill\" href=\"#custom-content-below-info\" role=\"tab\" aria-controls=\"custom-content-below-home\" aria-selected=\"true\"><i class=\"fa fa-info\"></i> معلومات المنتج </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-department-tab\" data-toggle=\"pill\" href=\"#custom-content-below-department\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-list\"></i> القسم </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-settings-tab\" data-toggle=\"pill\" href=\"#custom-content-below-settings\" role=\"tab\" aria-controls=\"custom-content-below-profile\" aria-selected=\"false\"><i class=\"fa fa-gears\"></i> اعدادات المنتج </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-content-tab\" data-toggle=\"pill\" href=\"#custom-content-below-content\" role=\"tab\" aria-controls=\"custom-content-below-messages\" aria-selected=\"false\"><i class=\"fa fa-question\"></i> سبب الرفض </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-sizes-tab\" data-toggle=\"pill\" href=\"#custom-content-below-sizes\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-truck\"></i> معلومات الشحن </a>
                                    </li>
                                    <li class=\"nav-item\">
                                        <a class=\"nav-link\" id=\"custom-content-below-other-tab\" data-toggle=\"pill\" href=\"#custom-content-below-other\" role=\"tab\" aria-controls=\"custom-content-below-settings\" aria-selected=\"false\"><i class=\"fa fa-cart-plus\"></i> معلومات اضافية </a>
                                    </li>
                                </ul>
                                <div class=\"tab-content\" id=\"custom-content-below-tabContent\">
                                <div class=\"tab-pane fade active show\" id=\"custom-content-below-info\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-info-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات المنتج</h3>
                                        <div class=\"form-group\">
                                            ";
        // line 64
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 64), 'label');
        echo "
                                            ";
        // line 65
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 65), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 66
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 66), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"form-group\" >
                                            ";
        // line 69
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "content", [], "any", false, false, false, 69), 'label');
        echo "
                                            ";
        // line 70
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "content", [], "any", false, false, false, 70), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 71
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "content", [], "any", false, false, false, 71), 'errors');
        echo "</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade show\" id=\"custom-content-below-department\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-department-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>القسم</h3>
                                        <div class=\"form-group\">
                                            <input id=\"department_form_department\" type=\"hidden\" name=\"department_id\" value=\"\">
";
        // line 81
        echo "                                            <div id=\"jstree_demo_div\"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-settings\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-settings-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>اعدادات المنتج</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 90
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price", [], "any", false, false, false, 90), 'label');
        echo "
                                                ";
        // line 91
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price", [], "any", false, false, false, 91), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 92
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price", [], "any", false, false, false, 92), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 95
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "stock", [], "any", false, false, false, 95), 'label');
        echo "
                                                ";
        // line 96
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "stock", [], "any", false, false, false, 96), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 97
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "stock", [], "any", false, false, false, 97), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 100
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_at", [], "any", false, false, false, 100), 'label');
        echo "
                                                ";
        // line 101
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_at", [], "any", false, false, false, 101), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 102
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_at", [], "any", false, false, false, 102), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 105
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_at", [], "any", false, false, false, 105), 'label');
        echo "
                                                ";
        // line 106
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_at", [], "any", false, false, false, 106), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 107
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_at", [], "any", false, false, false, 107), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                        <div class=\"form-group\">
                                            ";
        // line 111
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price_offer", [], "any", false, false, false, 111), 'label');
        echo "
                                            ";
        // line 112
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price_offer", [], "any", false, false, false, 112), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 113
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "price_offer", [], "any", false, false, false, 113), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 117
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_offer_at", [], "any", false, false, false, 117), 'label');
        echo "
                                                ";
        // line 118
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_offer_at", [], "any", false, false, false, 118), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 119
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "start_offer_at", [], "any", false, false, false, 119), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 122
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_offer_at", [], "any", false, false, false, 122), 'label');
        echo "
                                                ";
        // line 123
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_offer_at", [], "any", false, false, false, 123), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 124
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "end_offer_at", [], "any", false, false, false, 124), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-content\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-content-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>سبب الرفض والحالة</h3>
                                        <div class=\"form-group\">
                                            ";
        // line 133
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "status", [], "any", false, false, false, 133), 'label');
        echo "
                                            ";
        // line 134
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "status", [], "any", false, false, false, 134), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 135
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "status", [], "any", false, false, false, 135), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"form-group\">
                                            ";
        // line 138
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "reason", [], "any", false, false, false, 138), 'label');
        echo "
                                            ";
        // line 139
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "reason", [], "any", false, false, false, 139), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 140
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "reason", [], "any", false, false, false, 140), 'errors');
        echo "</div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-sizes\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-sizes-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>الوزن والحجم</h3>
                                        <div class=\"row\">
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 149
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight_string", [], "any", false, false, false, 149), 'label');
        echo "
                                                ";
        // line 150
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight_string", [], "any", false, false, false, 150), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 151
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight_string", [], "any", false, false, false, 151), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 154
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight", [], "any", false, false, false, 154), 'label');
        echo "
                                                ";
        // line 155
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight", [], "any", false, false, false, 155), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 156
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "weight", [], "any", false, false, false, 156), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 159
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Size", [], "any", false, false, false, 159), 'label');
        echo "
                                                ";
        // line 160
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Size", [], "any", false, false, false, 160), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 161
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Size", [], "any", false, false, false, 161), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-3 col-lg-3 col-sm-3 col-sm-12\">
                                                ";
        // line 164
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "size_string", [], "any", false, false, false, 164), 'label');
        echo "
                                                ";
        // line 165
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "size_string", [], "any", false, false, false, 165), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 166
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "size_string", [], "any", false, false, false, 166), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 169
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Country", [], "any", false, false, false, 169), 'label');
        echo "
                                                ";
        // line 170
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Country", [], "any", false, false, false, 170), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 171
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Country", [], "any", false, false, false, 171), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-6 col-lg-6 col-sm-6 col-sm-12\">
                                                ";
        // line 174
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "ManuFact", [], "any", false, false, false, 174), 'label');
        echo "
                                                ";
        // line 175
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "ManuFact", [], "any", false, false, false, 175), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 176
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "ManuFact", [], "any", false, false, false, 176), 'errors');
        echo "</div>
                                            </div>
                                            <div class=\"form-group col-md-12 col-lg-12 col-sm-12 col-sm-12\">
                                                ";
        // line 179
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Color", [], "any", false, false, false, 179), 'label');
        echo "
                                                ";
        // line 180
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Color", [], "any", false, false, false, 180), 'widget');
        echo "
                                                <div style=\"color: red\" class=\"errors\">";
        // line 181
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Color", [], "any", false, false, false, 181), 'errors');
        echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"tab-pane fade\" id=\"custom-content-below-other\" role=\"tabpanel\" aria-labelledby=\"custom-content-below-other-tab\">
                                    <div style=\"margin: 10px\">
                                        <h3>معلومات اضافية</h3>
                                        ";
        // line 189
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "photo", [], "any", false, false, false, 189), 'label');
        echo "
                                        ";
        // line 190
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "photo", [], "any", false, false, false, 190), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 191
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "photo", [], "any", false, false, false, 191), 'errors');
        echo "</div>
                                        ";
        // line 192
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Trademark", [], "any", false, false, false, 192), 'label');
        echo "
                                        ";
        // line 193
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Trademark", [], "any", false, false, false, 193), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 194
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "Trademark", [], "any", false, false, false, 194), 'errors');
        echo "</div>
                                        ";
        // line 195
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "other_data", [], "any", false, false, false, 195), 'label');
        echo "
                                        ";
        // line 196
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "other_data", [], "any", false, false, false, 196), 'widget');
        echo "
                                        <div style=\"color: red\" class=\"errors\">";
        // line 197
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "other_data", [], "any", false, false, false, 197), 'errors');
        echo "</div>
                                    </div>
                                </div>
                            </div>
                                <div style=\"margin-bottom: 5px;margin-top: 10px\">
                                    <button name=\"save\" class=\"btn btn-info\"> حفظ وعوده <i class=\"fa fa-save\"></i> </button>
                                    <button name=\"save_and_continue\" class=\"btn btn-success\"> حفظ واستمرار <i class=\"fa fa-save\"></i></button>
";
        // line 205
        echo "                                    <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\" class=\"btn btn-default\"> رجوع <i class=\"fa fa-arrow-left\"></i></a>
";
        // line 207
        echo "                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


";
    }

    // line 221
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 222
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/themes/default/style.min.css\" />
    <link rel=\"stylesheet\" href=\"";
        // line 223
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2.min.css\">
    <link rel=\"stylesheet\" href=\"";
        // line 224
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2-bootstrap4.min.css\">
";
    }

    // line 228
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 229
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/jstree.min.js\"></script>
    <script src=\"";
        // line 230
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/plugins/select2/select2.full.min.js\"></script>
    <script src=\"https://cdn.ckeditor.com/4.14.0/standard-all/ckeditor.js\"></script>
    ";
        // line 233
        echo "
    <script type=\"text/javascript\">

        \$(function () { \$('#jstree_demo_div').jstree({ 'core' : {
                'data' : ";
        // line 237
        echo ($context["departments"] ?? null);
        echo "
            } }); });

        \$('#jstree_demo_div').on(\"changed.jstree\", function (e, data) {
            \$('#department_form_department').val(data.selected);

            \$.ajax({
                'method': 'POST',
                'url' : '";
        // line 245
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.specific.size");
        echo "',
                'type' : 'json',
                'data' : {id:data.selected},
                success : function (data_ajax) {
                    \$('#product_form_Size').html('');
                    \$.each(data_ajax, function( index, size ) {
                        \$('#product_form_Size').append(`<option value=\"\${size.id}\">\${size.name}</option>`);
                    });
                },
                beforeSend: function(){
                    \$('.card-footer button').attr('disabled' ,'disabled');
                },
                complete: function(){
                    \$('.card-footer button').removeAttr('disabled' ,'disabled');
                },
            });
        });

        \$(document).ready(function() {
            \$('.select2').select2();
            CKEDITOR.replace('product_form[content]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });

            CKEDITOR.replace('product_form[other_data]',{
                extraPlugins: 'language',
                language_list: ['ar:Arabic:rtl'],
                contentsLangDirection: 'rtl',
                height: 200
            });
        });
    </script>
";
    }

    public function getTemplateName()
    {
        return "dashboard/products/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  531 => 245,  520 => 237,  514 => 233,  509 => 230,  504 => 229,  500 => 228,  494 => 224,  490 => 223,  485 => 222,  481 => 221,  465 => 207,  460 => 205,  450 => 197,  446 => 196,  442 => 195,  438 => 194,  434 => 193,  430 => 192,  426 => 191,  422 => 190,  418 => 189,  407 => 181,  403 => 180,  399 => 179,  393 => 176,  389 => 175,  385 => 174,  379 => 171,  375 => 170,  371 => 169,  365 => 166,  361 => 165,  357 => 164,  351 => 161,  347 => 160,  343 => 159,  337 => 156,  333 => 155,  329 => 154,  323 => 151,  319 => 150,  315 => 149,  303 => 140,  299 => 139,  295 => 138,  289 => 135,  285 => 134,  281 => 133,  269 => 124,  265 => 123,  261 => 122,  255 => 119,  251 => 118,  247 => 117,  240 => 113,  236 => 112,  232 => 111,  225 => 107,  221 => 106,  217 => 105,  211 => 102,  207 => 101,  203 => 100,  197 => 97,  193 => 96,  189 => 95,  183 => 92,  179 => 91,  175 => 90,  164 => 81,  152 => 71,  148 => 70,  144 => 69,  138 => 66,  134 => 65,  130 => 64,  101 => 38,  97 => 37,  94 => 36,  89 => 34,  66 => 13,  62 => 12,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/products/create.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/products/create.html.twig");
    }
}
