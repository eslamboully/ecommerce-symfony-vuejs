<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/shippings/edit.html.twig */
class __TwigTemplate_593e37ff7ada3eaa25032e594bb993f7d8da2e9e6c9a0b62fa1845d70d600521 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/shippings/edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">تعديل شركات الشحن</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 13
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.shippings.index");
        echo "\">شركات الشحن</a></li>
                        <li class=\"breadcrumb-item active\">تعديل</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <form role=\"form\" method=\"post\" enctype=\"multipart/form-data\">
                            ";
        // line 29
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        echo "
                            ";
        // line 30
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "_token", [], "any", false, false, false, 30), 'row');
        echo "
                            <div class=\"card-body\">
                                <div class=\"form-group\">
                                    ";
        // line 33
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 33), 'label');
        echo "
                                    ";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 34), 'widget');
        echo "
                                    <div style=\"color: red\" class=\"errors\">";
        // line 35
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 35), 'errors');
        echo "</div>
                                </div>

                                <div class=\"form-group\">
                                    ";
        // line 39
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "User", [], "any", false, false, false, 39), 'label');
        echo "
                                    ";
        // line 40
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "User", [], "any", false, false, false, 40), 'widget');
        echo "
                                    <div style=\"color: red\" class=\"errors\">";
        // line 41
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "User", [], "any", false, false, false, 41), 'errors');
        echo "</div>
                                </div>

                                <div class=\"form-group\">
                                    ";
        // line 45
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "address", [], "any", false, false, false, 45), 'label');
        echo "
                                    ";
        // line 46
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "address", [], "any", false, false, false, 46), 'widget');
        echo "
                                    <div style=\"color: red\" class=\"errors\">";
        // line 47
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "address", [], "any", false, false, false, 47), 'errors');
        echo "</div>
                                </div>


                                <div class=\"form-group\">
                                    <div class=\"row\">
                                        <div class=\"col-md-6\">
                                            ";
        // line 54
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lng", [], "any", false, false, false, 54), 'label');
        echo "
                                            ";
        // line 55
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lng", [], "any", false, false, false, 55), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 56
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lng", [], "any", false, false, false, 56), 'errors');
        echo "</div>
                                        </div>
                                        <div class=\"col-md-6\">
                                            ";
        // line 59
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lat", [], "any", false, false, false, 59), 'label');
        echo "
                                            ";
        // line 60
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lat", [], "any", false, false, false, 60), 'widget');
        echo "
                                            <div style=\"color: red\" class=\"errors\">";
        // line 61
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "lat", [], "any", false, false, false, 61), 'errors');
        echo "</div>
                                        </div>
                                    </div>
                                </div>

                                <div class=\"form-group\">
                                    <div id=\"map\"></div>
                                    <pre id=\"coordinates\" class=\"coordinates\"></pre>
                                </div>

                                <div class=\"form-group\">
                                    ";
        // line 72
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "icon", [], "any", false, false, false, 72), 'label');
        echo "
                                    ";
        // line 73
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "icon", [], "any", false, false, false, 73), 'widget');
        echo "
                                    <div style=\"color: red\" class=\"errors\">";
        // line 74
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "icon", [], "any", false, false, false, 74), 'errors');
        echo "</div>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class=\"card-footer\">
                                <button type=\"submit\" class=\"btn btn-primary\">ارسال</button>
                            </div>
                        </form>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
";
    }

    // line 92
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 93
        echo "    <script src=\"https://api.mapbox.com/mapbox-gl-js/v1.10.1/mapbox-gl.js\"></script>
    <link href=\"https://api.mapbox.com/mapbox-gl-js/v1.10.1/mapbox-gl.css\" rel=\"stylesheet\" />
    <style>
        body { margin: 0; padding: 0; }
        #map { top: 0; bottom: 0;height: 300px; width: 100%; }
    </style>
";
    }

    // line 101
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 102
        echo "    <script>
        mapboxgl.accessToken = 'pk.eyJ1IjoiZXNsYW1ib3VsbHkiLCJhIjoiY2thaWdncDE3MDBqMjJ6dGR4cHhzeDlkYiJ9.ZUE0a2peQttyyS3jxfiPlQ';
        var coordinates = document.getElementById('coordinates');
        var map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/streets-v11',
            center: [";
        // line 108
        ((0 !== twig_compare(twig_get_attribute($this->env, $this->source, ($context["shipping"] ?? null), "lng", [], "any", false, false, false, 108), null)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["shipping"] ?? null), "lng", [], "any", false, false, false, 108), "html", null, true))) : (print (31.168468256781608261007932014763355255126953125)));
        echo ", ";
        ((0 !== twig_compare(twig_get_attribute($this->env, $this->source, ($context["shipping"] ?? null), "lat", [], "any", false, false, false, 108), null)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["shipping"] ?? null), "lat", [], "any", false, false, false, 108), "html", null, true))) : (print (29.97957019257461297456757165491580963134765625)));
        echo "],
            zoom: 17
        });

        var marker = new mapboxgl.Marker({
            draggable: true
        })
            .setLngLat([";
        // line 115
        ((0 !== twig_compare(twig_get_attribute($this->env, $this->source, ($context["shipping"] ?? null), "lng", [], "any", false, false, false, 115), null)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["shipping"] ?? null), "lng", [], "any", false, false, false, 115), "html", null, true))) : (print (31.168468256781608261007932014763355255126953125)));
        echo ", ";
        ((0 !== twig_compare(twig_get_attribute($this->env, $this->source, ($context["shipping"] ?? null), "lat", [], "any", false, false, false, 115), null)) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["shipping"] ?? null), "lat", [], "any", false, false, false, 115), "html", null, true))) : (print (29.97957019257461297456757165491580963134765625)));
        echo "])
            .addTo(map);

        function onDragEnd() {
            var lngLat = marker.getLngLat();
            coordinates.style.display = 'block';
            \$('#shipping_form_lng').val(lngLat.lng);
            \$('#shipping_form_lat').val(lngLat.lat);
        }

        marker.on('dragend', onDragEnd);
    </script>

    <script>

    </script>
";
    }

    public function getTemplateName()
    {
        return "dashboard/shippings/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  246 => 115,  234 => 108,  226 => 102,  222 => 101,  212 => 93,  208 => 92,  187 => 74,  183 => 73,  179 => 72,  165 => 61,  161 => 60,  157 => 59,  151 => 56,  147 => 55,  143 => 54,  133 => 47,  129 => 46,  125 => 45,  118 => 41,  114 => 40,  110 => 39,  103 => 35,  99 => 34,  95 => 33,  89 => 30,  85 => 29,  66 => 13,  62 => 12,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/shippings/edit.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/shippings/edit.html.twig");
    }
}
