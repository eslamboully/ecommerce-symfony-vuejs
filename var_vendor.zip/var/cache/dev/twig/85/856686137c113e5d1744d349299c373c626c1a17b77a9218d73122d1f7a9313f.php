<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/settings.html.twig */
class __TwigTemplate_fae1e8f678e25e67bb27a802571b4824fba7fdf3275fa895265cd70249dd6fbe extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/settings.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/settings.html.twig"));

        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/settings.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">الاعدادات</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item active\">الاعدادات</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <div class=\"card-header\">
";
        // line 29
        echo "                        </div>
                        <!-- /.card-header -->
                        <div class=\"card-body\">
                            ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 32, $this->source); })()), "flashes", [0 => "success"], "method", false, false, false, 32));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 33
            echo "                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <div class=\"card\">
                                            <div class=\"card-body label label-success\">
                                                <div style=\"font-size: 18px;\">";
            // line 37
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "
                            <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
                                ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new RuntimeError('Variable "settings" does not exist.', 45, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["setting"]) {
            // line 46
            echo "                                    <div class=\"form-group\">
                                        ";
            // line 47
            if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["setting"], "type", [], "any", false, false, false, 47), 1)) {
                // line 48
                echo "                                            <label for=\"\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["setting"], "displayName", [], "any", false, false, false, 48), "html", null, true);
                echo "</label>
                                            <input type=\"text\" class=\"form-control\" name=\"settings[";
                // line 49
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["setting"], "var", [], "any", false, false, false, 49), "html", null, true);
                echo "]\" value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["setting"], "value", [], "any", false, false, false, 49), "html", null, true);
                echo "\">
                                        ";
            } elseif (0 === twig_compare(twig_get_attribute($this->env, $this->source,             // line 50
$context["setting"], "type", [], "any", false, false, false, 50), 2)) {
                // line 51
                echo "                                            <label for=\"\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["setting"], "displayName", [], "any", false, false, false, 51), "html", null, true);
                echo "</label>
                                            <textarea class=\"form-control\" name=\"settings[";
                // line 52
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["setting"], "var", [], "any", false, false, false, 52), "html", null, true);
                echo "]\">";
                echo twig_get_attribute($this->env, $this->source, $context["setting"], "value", [], "any", false, false, false, 52);
                echo "</textarea>
                                        ";
            } elseif (0 === twig_compare(twig_get_attribute($this->env, $this->source,             // line 53
$context["setting"], "type", [], "any", false, false, false, 53), 3)) {
                // line 54
                echo "                                            <label for=\"\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["setting"], "displayName", [], "any", false, false, false, 54), "html", null, true);
                echo "</label>
                                            <br/>
                                            <input type=\"file\" name=\"settings[";
                // line 56
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["setting"], "var", [], "any", false, false, false, 56), "html", null, true);
                echo "]\">
                                            ";
                // line 57
                if (0 !== twig_compare(twig_get_attribute($this->env, $this->source, $context["setting"], "value", [], "any", false, false, false, 57), null)) {
                    // line 58
                    echo "                                                <img src=\"";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("uploads/settings/" . twig_get_attribute($this->env, $this->source, $context["setting"], "value", [], "any", false, false, false, 58))), "html", null, true);
                    echo "\" style=\"width: 80px;height: 80px\" alt=\"\">
                                            ";
                } else {
                    // line 60
                    echo "                                                <img src=\"";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/settings/default.jpg"), "html", null, true);
                    echo "\" style=\"width: 80px;height: 80px\" alt=\"\">
                                            ";
                }
                // line 62
                echo "                                        ";
            }
            // line 63
            echo "                                    </div>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['setting'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 65
        echo "
                                <button class=\"btn btn-success\"> حفظ الاعدادات <i class=\"fa fa-save\"></i></button>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 78
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 79
        echo "    <script src=\"https://cdn.ckeditor.com/4.14.0/standard-all/ckeditor.js\"></script>

    <script>
        \$('textarea').ckeditor({
            extraPlugins: 'language',
            language_list: ['ar:Arabic:rtl'],
            contentsLangDirection: 'rtl',
            height: 200
        });
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "dashboard/settings.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  229 => 79,  219 => 78,  198 => 65,  191 => 63,  188 => 62,  182 => 60,  176 => 58,  174 => 57,  170 => 56,  164 => 54,  162 => 53,  156 => 52,  151 => 51,  149 => 50,  143 => 49,  138 => 48,  136 => 47,  133 => 46,  129 => 45,  125 => 43,  113 => 37,  107 => 33,  103 => 32,  98 => 29,  79 => 12,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'dashboard/layouts/base.html.twig' %}

{% block content %}
    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">الاعدادات</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"{{ path('dashboard.index') }}\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item active\">الاعدادات</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <div class=\"card-header\">
{#                            <h3 class=\"card-title\"></h3>#}
                        </div>
                        <!-- /.card-header -->
                        <div class=\"card-body\">
                            {% for message in app.flashes('success') %}
                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <div class=\"card\">
                                            <div class=\"card-body label label-success\">
                                                <div style=\"font-size: 18px;\">{{ message }}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            {% endfor %}

                            <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
                                {% for setting in settings %}
                                    <div class=\"form-group\">
                                        {% if (setting.type == 1) %}
                                            <label for=\"\">{{ setting.displayName }}</label>
                                            <input type=\"text\" class=\"form-control\" name=\"settings[{{ setting.var }}]\" value=\"{{ setting.value }}\">
                                        {% elseif (setting.type == 2) %}
                                            <label for=\"\">{{ setting.displayName }}</label>
                                            <textarea class=\"form-control\" name=\"settings[{{ setting.var }}]\">{{ setting.value|raw }}</textarea>
                                        {% elseif (setting.type == 3) %}
                                            <label for=\"\">{{ setting.displayName }}</label>
                                            <br/>
                                            <input type=\"file\" name=\"settings[{{ setting.var }}]\">
                                            {% if (setting.value != null) %}
                                                <img src=\"{{ asset('uploads/settings/'~setting.value) }}\" style=\"width: 80px;height: 80px\" alt=\"\">
                                            {% else %}
                                                <img src=\"{{ asset('uploads/settings/default.jpg') }}\" style=\"width: 80px;height: 80px\" alt=\"\">
                                            {% endif %}
                                        {% endif %}
                                    </div>
                                {% endfor %}

                                <button class=\"btn btn-success\"> حفظ الاعدادات <i class=\"fa fa-save\"></i></button>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
{% endblock %}

{% block js %}
    <script src=\"https://cdn.ckeditor.com/4.14.0/standard-all/ckeditor.js\"></script>

    <script>
        \$('textarea').ckeditor({
            extraPlugins: 'language',
            language_list: ['ar:Arabic:rtl'],
            contentsLangDirection: 'rtl',
            height: 200
        });
    </script>
{% endblock %}", "dashboard/settings.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/settings.html.twig");
    }
}
