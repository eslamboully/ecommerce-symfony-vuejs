<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/layouts/aside.html.twig */
class __TwigTemplate_97d56099cc5e5a506d31c3dcea03a35dde51adafc308e25bdd980be7e77577d7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/layouts/aside.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "dashboard/layouts/aside.html.twig"));

        // line 1
        echo "<aside class=\"main-sidebar sidebar-dark-primary elevation-4\">
    <!-- Brand Logo -->
    <a href=\"";
        // line 3
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\" class=\"brand-link\">
        <img src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("dashboard"), "html", null, true);
        echo "/dist/img/AdminLTELogo.png\" alt=\"AdminLTE Logo\" class=\"brand-image img-circle elevation-3\"
             style=\"opacity: .8\">
        <span class=\"brand-text font-weight-light\">لوحة التحكم</span>
    </a>

    ";
        // line 9
        $context["router"] = twig_split_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 9, $this->source); })()), "request", [], "any", false, false, false, 9), "attributes", [], "any", false, false, false, 9), "get", [0 => "_route"], "method", false, false, false, 9), ".");
        // line 10
        echo "
    <!-- Sidebar -->
    <div class=\"sidebar\" style=\"direction: ltr\">
        <div style=\"direction: rtl\">
            <!-- Sidebar user panel (optional) -->
            <div class=\"user-panel mt-3 pb-3 mb-3 d-flex\">
                <div class=\"image\">
                    <img src=\"https://secure.gravatar.com/avatar/5ffa2a1ffeb767c60ab7e1052e385d5c?s=52&d=mm&r=g\" class=\"img-circle elevation-2\" alt=\"User Image\">
                </div>
                <div class=\"info\">
                    <a href=\"#\" class=\"d-block\">";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 20, $this->source); })()), "user", [], "any", false, false, false, 20), "name", [], "any", false, false, false, 20), "html", null, true);
        echo "</a>
                </div>
            </div>

            <!-- Sidebar Menu -->
            <nav class=\"mt-2\">
                <ul class=\"nav nav-pills nav-sidebar flex-column\" data-widget=\"treeview\" role=\"menu\" data-accordion=\"false\">
                    <!-- Add icons to the links using the .nav-icon class
                         with font-awesome or any other icon font library -->
                    <li class=\"nav-item ";
        // line 29
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 29, $this->source); })()), 1, [], "array", false, false, false, 29), "index")) ? ("menu-open") : (""));
        echo "\">
                        <a href=\"";
        // line 30
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-dashboard\"></i>
                            <p>
                                الرئيسية
                            </p>
                        </a>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 37
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 37, $this->source); })()), 1, [], "array", false, false, false, 37), "admins")) ? ("menu-open") : (""));
        echo "\">
                        <a href=\"#\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-user-secret\"></i>
                            <p>
                                المشرفين
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 47
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.admins.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المشرفين</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 53
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.admins.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 60
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 60, $this->source); })()), 1, [], "array", false, false, false, 60), "users")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 61
        echo "                        <a href=\"#\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-user\"></i>
                            <p>
                                المستخدمين
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 70
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>جميع المستخدمين</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 76
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.index", ["type" => 1]);
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الاعضاء</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 82
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.index", ["type" => 2]);
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المتاجر</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 88
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.index", ["type" => 3]);
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الشركات</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 94
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 101
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 101, $this->source); })()), 1, [], "array", false, false, false, 101), "countries")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 102
        echo "                        <a href=\"#\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-flag\"></i>
                            <p>
                                الدول
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 111
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.countries.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الدول</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 117
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.countries.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 124
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 124, $this->source); })()), 1, [], "array", false, false, false, 124), "cities")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 125
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 127
        echo "                            <i class=\"nav-icon fa fa-flag-checkered\"></i>
                            <p>
                                المحافظات / المدن
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 135
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.cities.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المحافظات / المدن</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 141
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.cities.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 148
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 148, $this->source); })()), 1, [], "array", false, false, false, 148), "states")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 149
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 151
        echo "                            <i class=\"nav-icon fa fa-flag\"></i>
                            <p>
                                المناطق / الاحياء
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 159
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.states.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المناطق / الاحياء</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 165
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.states.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 172
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 172, $this->source); })()), 1, [], "array", false, false, false, 172), "departments")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 173
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 175
        echo "                            <i class=\"nav-icon fa fa-list-ol\"></i>
                            <p>
                                الاقسام
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 183
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.departments.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الاقسام</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 189
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.departments.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 196
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 196, $this->source); })()), 1, [], "array", false, false, false, 196), "trademarks")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 197
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 199
        echo "                            <i class=\"nav-icon fa fa-trademark\"></i>
                            <p>
                                العلامات التجارية
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 207
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.trademarks.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>العلامات التجارية</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 213
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.trademarks.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 220
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 220, $this->source); })()), 1, [], "array", false, false, false, 220), "manufacts")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 221
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 223
        echo "                            <i class=\"nav-icon fa fa-rocket\"></i>
                            <p>
                                المصنعين
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 231
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.manufacts.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المصنعين</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 237
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.manufacts.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 244
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 244, $this->source); })()), 1, [], "array", false, false, false, 244), "shippings")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 245
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 247
        echo "                            <i class=\"nav-icon fa fa-truck\"></i>
                            <p>
                                شركات الشحن
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 255
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.shippings.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>شركات الشحن</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 261
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.shippings.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 268
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 268, $this->source); })()), 1, [], "array", false, false, false, 268), "malls")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 269
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 271
        echo "                            <i class=\"nav-icon fa fa-building\"></i>
                            <p>
                                المجمعات التجارية
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 279
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.malls.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المجمعات التجارية</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 285
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.malls.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 292
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 292, $this->source); })()), 1, [], "array", false, false, false, 292), "colors")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 293
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 295
        echo "                            <i class=\"nav-icon fa fa-paint-brush\"></i>
                            <p>
                                الالوان
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 303
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.colors.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الالوان</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 309
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.colors.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 316
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 316, $this->source); })()), 1, [], "array", false, false, false, 316), "sizes")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 317
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 319
        echo "                            <i class=\"nav-icon fa fa-sliders\"></i>
                            <p>
                                المقاسات
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 327
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.sizes.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المقاسات</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 333
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.sizes.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 340
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 340, $this->source); })()), 1, [], "array", false, false, false, 340), "weights")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 341
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 343
        echo "                            <i class=\"nav-icon fa fa-archive\"></i>
                            <p>
                                الاوزان
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 351
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.weights.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الاوزان</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 357
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.weights.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview ";
        // line 364
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 364, $this->source); })()), 1, [], "array", false, false, false, 364), "products")) ? ("menu-open") : (""));
        echo "\"> ";
        // line 365
        echo "                        <a href=\"#\" class=\"nav-link\">
";
        // line 367
        echo "                            <i class=\"nav-icon fa fa-tag\"></i>
                            <p>
                                المنتجات
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 375
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.index");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المنتجات</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"";
        // line 381
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.products.create");
        echo "\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item ";
        // line 388
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 388, $this->source); })()), 1, [], "array", false, false, false, 388), "orders")) ? ("menu-open") : (""));
        echo "\">
                        <a href=\"";
        // line 389
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.settings");
        echo "\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-cart-plus\"></i>
                            <p>
                                الطلبات
                            </p>
                        </a>
                    </li>
                    <li class=\"nav-item ";
        // line 396
        echo ((0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["router"]) || array_key_exists("router", $context) ? $context["router"] : (function () { throw new RuntimeError('Variable "router" does not exist.', 396, $this->source); })()), 1, [], "array", false, false, false, 396), "settings")) ? ("menu-open") : (""));
        echo "\">
                        <a href=\"";
        // line 397
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.settings");
        echo "\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-gears\"></i>
                            <p>
                                الاعدادات
                            </p>
                        </a>
                    </li>
                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
    </div>
    <!-- /.sidebar -->
</aside>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "dashboard/layouts/aside.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  627 => 397,  623 => 396,  613 => 389,  609 => 388,  599 => 381,  590 => 375,  580 => 367,  577 => 365,  574 => 364,  564 => 357,  555 => 351,  545 => 343,  542 => 341,  539 => 340,  529 => 333,  520 => 327,  510 => 319,  507 => 317,  504 => 316,  494 => 309,  485 => 303,  475 => 295,  472 => 293,  469 => 292,  459 => 285,  450 => 279,  440 => 271,  437 => 269,  434 => 268,  424 => 261,  415 => 255,  405 => 247,  402 => 245,  399 => 244,  389 => 237,  380 => 231,  370 => 223,  367 => 221,  364 => 220,  354 => 213,  345 => 207,  335 => 199,  332 => 197,  329 => 196,  319 => 189,  310 => 183,  300 => 175,  297 => 173,  294 => 172,  284 => 165,  275 => 159,  265 => 151,  262 => 149,  259 => 148,  249 => 141,  240 => 135,  230 => 127,  227 => 125,  224 => 124,  214 => 117,  205 => 111,  194 => 102,  191 => 101,  181 => 94,  172 => 88,  163 => 82,  154 => 76,  145 => 70,  134 => 61,  131 => 60,  121 => 53,  112 => 47,  99 => 37,  89 => 30,  85 => 29,  73 => 20,  61 => 10,  59 => 9,  51 => 4,  47 => 3,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<aside class=\"main-sidebar sidebar-dark-primary elevation-4\">
    <!-- Brand Logo -->
    <a href=\"{{ path('dashboard.index') }}\" class=\"brand-link\">
        <img src=\"{{ asset('dashboard') }}/dist/img/AdminLTELogo.png\" alt=\"AdminLTE Logo\" class=\"brand-image img-circle elevation-3\"
             style=\"opacity: .8\">
        <span class=\"brand-text font-weight-light\">لوحة التحكم</span>
    </a>

    {% set router = app.request.attributes.get('_route')|split('.') %}

    <!-- Sidebar -->
    <div class=\"sidebar\" style=\"direction: ltr\">
        <div style=\"direction: rtl\">
            <!-- Sidebar user panel (optional) -->
            <div class=\"user-panel mt-3 pb-3 mb-3 d-flex\">
                <div class=\"image\">
                    <img src=\"https://secure.gravatar.com/avatar/5ffa2a1ffeb767c60ab7e1052e385d5c?s=52&d=mm&r=g\" class=\"img-circle elevation-2\" alt=\"User Image\">
                </div>
                <div class=\"info\">
                    <a href=\"#\" class=\"d-block\">{{ app.user.name }}</a>
                </div>
            </div>

            <!-- Sidebar Menu -->
            <nav class=\"mt-2\">
                <ul class=\"nav nav-pills nav-sidebar flex-column\" data-widget=\"treeview\" role=\"menu\" data-accordion=\"false\">
                    <!-- Add icons to the links using the .nav-icon class
                         with font-awesome or any other icon font library -->
                    <li class=\"nav-item {{ router[1] == 'index' ? 'menu-open' : '' }}\">
                        <a href=\"{{ path('dashboard.index') }}\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-dashboard\"></i>
                            <p>
                                الرئيسية
                            </p>
                        </a>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'admins' ? 'menu-open' : '' }}\">
                        <a href=\"#\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-user-secret\"></i>
                            <p>
                                المشرفين
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.admins.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المشرفين</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.admins.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'users' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-user\"></i>
                            <p>
                                المستخدمين
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.users.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>جميع المستخدمين</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.users.index',{\"type\":1}) }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الاعضاء</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.users.index',{\"type\":2}) }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المتاجر</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.users.index',{\"type\":3}) }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الشركات</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.users.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'countries' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-flag\"></i>
                            <p>
                                الدول
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.countries.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الدول</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.countries.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'cities' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-flag-checkered\"></i>
                            <p>
                                المحافظات / المدن
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.cities.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المحافظات / المدن</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.cities.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'states' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-flag\"></i>
                            <p>
                                المناطق / الاحياء
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.states.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المناطق / الاحياء</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.states.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'departments' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-list-ol\"></i>
                            <p>
                                الاقسام
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.departments.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الاقسام</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.departments.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'trademarks' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-trademark\"></i>
                            <p>
                                العلامات التجارية
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.trademarks.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>العلامات التجارية</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.trademarks.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'manufacts' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-rocket\"></i>
                            <p>
                                المصنعين
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.manufacts.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المصنعين</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.manufacts.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'shippings' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-truck\"></i>
                            <p>
                                شركات الشحن
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.shippings.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>شركات الشحن</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.shippings.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'malls' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-building\"></i>
                            <p>
                                المجمعات التجارية
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.malls.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المجمعات التجارية</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.malls.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'colors' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-paint-brush\"></i>
                            <p>
                                الالوان
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.colors.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الالوان</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.colors.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'sizes' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-sliders\"></i>
                            <p>
                                المقاسات
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.sizes.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المقاسات</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.sizes.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'weights' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-archive\"></i>
                            <p>
                                الاوزان
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.weights.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>الاوزان</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.weights.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item has-treeview {{ router[1] == 'products' ? 'menu-open' : '' }}\"> {# menu-open #}
                        <a href=\"#\" class=\"nav-link\">
{#                            <i class=\"nav-icon fa fa-canadian-maple-leaf\"></i>#}
                            <i class=\"nav-icon fa fa-tag\"></i>
                            <p>
                                المنتجات
                                <i class=\"right fa fa-angle-left\"></i>
                            </p>
                        </a>
                        <ul class=\"nav nav-treeview\">
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.products.index') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>المنتجات</p>
                                </a>
                            </li>
                            <li class=\"nav-item\">
                                <a href=\"{{ path('dashboard.products.create') }}\" class=\"nav-link\">
                                    <i class=\"fa fa-circle-o nav-icon\"></i>
                                    <p>اضف</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class=\"nav-item {{ router[1] == 'orders' ? 'menu-open' : '' }}\">
                        <a href=\"{{ path('dashboard.settings') }}\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-cart-plus\"></i>
                            <p>
                                الطلبات
                            </p>
                        </a>
                    </li>
                    <li class=\"nav-item {{ router[1] == 'settings' ? 'menu-open' : '' }}\">
                        <a href=\"{{ path('dashboard.settings') }}\" class=\"nav-link\">
                            <i class=\"nav-icon fa fa-gears\"></i>
                            <p>
                                الاعدادات
                            </p>
                        </a>
                    </li>
                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
    </div>
    <!-- /.sidebar -->
</aside>", "dashboard/layouts/aside.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/layouts/aside.html.twig");
    }
}
