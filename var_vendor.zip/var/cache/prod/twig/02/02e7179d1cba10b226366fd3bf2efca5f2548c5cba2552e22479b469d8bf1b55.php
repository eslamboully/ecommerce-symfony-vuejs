<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dashboard/users/index.html.twig */
class __TwigTemplate_93a1f7a9167fc70e6b5b02f92387e3b1a61d6213b9aaeec71e57b9cac44cec49 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "dashboard/layouts/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("dashboard/layouts/base.html.twig", "dashboard/users/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    <div class=\"content-header\">
        <div class=\"container-fluid\">
            <div class=\"row mb-2\">
                <div class=\"col-sm-6\">
                    <h1 class=\"m-0 text-dark\">جدول المستخدمين</h1>
                </div><!-- /.col -->
                <div class=\"col-sm-6\">
                    <ol class=\"breadcrumb float-sm-left\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.index");
        echo "\">الرئيسية</a></li>
                        <li class=\"breadcrumb-item active\">المستخدمين</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class=\"content\">
        <div class=\"container-fluid\">
            <div class=\"row\">
                <div class=\"col-md-12\">
                    <div class=\"card\">
                        <div class=\"card-header\">
";
        // line 29
        echo "                            <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.create");
        echo "\" class=\"btn btn-success btn-md\"><i class=\"fa fa-plus\"></i> اضف جديد </a>
                            <a href=\"\" class=\"btn btn-info btn-md\" onclick=\"window.print()\"><i class=\"fa fa-print\"></i> طباعة </a>
                            <a href=\"\" class=\"btn btn-primary btn-md\"><i class=\"fa fa-plus\"></i> استيراد اكسل </a>
                            <a href=\"\" class=\"btn btn-default btn-md\"><i class=\"fa fa-refresh\"></i></a>
                            <a href=\"\" class=\"btn btn-danger btn-md\"><i class=\"fa fa-trash\"></i> حذف الكل </a>
                        </div>
                        <!-- /.card-header -->
                        <div class=\"card-body\">
                            ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "flashes", [0 => "success"], "method", false, false, false, 37));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 38
            echo "                                <div class=\"row\">
                                    <div class=\"col-md-12\">
                                        <div class=\"card\">
                                            <div class=\"card-body label label-success\">
                                                <div style=\"font-size: 18px;\">";
            // line 42
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "
                            ";
        // line 49
        if (1 === twig_compare(twig_length_filter($this->env, ($context["users"] ?? null)), 0)) {
            // line 50
            echo "                                <table id=\"table-user\" class=\"table table-bordered\">
                                    <tr>
                                        <th>#</th>
                                        <th>الاسم</th>
                                        <th>البريد الالكتروني</th>
                                        <th>نوع الحساب</th>
                                        <th>العمليات</th>
                                    </tr>

                                    ";
            // line 59
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["users"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                // line 60
                echo "                                        <tr>
                                            <td>";
                // line 61
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 61), "html", null, true);
                echo "</td>
                                            <td>";
                // line 62
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "name", [], "any", false, false, false, 62), "html", null, true);
                echo "</td>
                                            <td>";
                // line 63
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "email", [], "any", false, false, false, 63), "html", null, true);
                echo "</td>
                                            <td>
                                                ";
                // line 65
                if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["user"], "type", [], "any", false, false, false, 65), 1)) {
                    // line 66
                    echo "                                                    <span class=\"label label-success\">عضو</span>
                                                ";
                } elseif (0 === twig_compare(twig_get_attribute($this->env, $this->source,                 // line 67
$context["user"], "type", [], "any", false, false, false, 67), 2)) {
                    // line 68
                    echo "                                                    <span class=\"label label-info\">متجر</span>
                                                ";
                } elseif (0 === twig_compare(twig_get_attribute($this->env, $this->source,                 // line 69
$context["user"], "type", [], "any", false, false, false, 69), 3)) {
                    // line 70
                    echo "                                                    <span class=\"label label-primary\">شركة</span>
                                                ";
                }
                // line 72
                echo "                                            </td>
                                            <td>
                                                <a href=\"";
                // line 74
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.edit", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 74)]), "html", null, true);
                echo "\" class=\"btn btn-success btn-sm\"><i class=\"fa fa-edit\"></i> تعديل </a>
                                                <a href=\"";
                // line 75
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("dashboard.users.destroy", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 75)]), "html", null, true);
                echo "\" onclick=\"return confirm('هل انت متأكد من عملية الحذف ؟')\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\"></i> حذف </a>
                                            </td>
                                        </tr>
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 79
            echo "                                </table>
                            ";
        } else {
            // line 81
            echo "                                <h1>للأسف لا يوجد مستخدمين حتي الان</h1>
                            ";
        }
        // line 83
        echo "                        </div>
                        <!-- /.card-body -->
";
        // line 94
        echo "                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
        </div><!-- /.container-fluid -->
    </section>

";
    }

    public function getTemplateName()
    {
        return "dashboard/users/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  195 => 94,  191 => 83,  187 => 81,  183 => 79,  173 => 75,  169 => 74,  165 => 72,  161 => 70,  159 => 69,  156 => 68,  154 => 67,  151 => 66,  149 => 65,  144 => 63,  140 => 62,  136 => 61,  133 => 60,  129 => 59,  118 => 50,  116 => 49,  113 => 48,  101 => 42,  95 => 38,  91 => 37,  79 => 29,  60 => 12,  50 => 4,  46 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dashboard/users/index.html.twig", "/opt/lampp/htdocs/ecommerce/templates/dashboard/users/index.html.twig");
    }
}
